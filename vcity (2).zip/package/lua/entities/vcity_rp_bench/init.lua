AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")
function ENT:Initialize()
    self:SetModel("models/props_canal/winch02.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    local phys=self:GetPhysicsObject()
    if IsValid(phys) then phys:EnableMotion(false) end
end
function ENT:Use(activator)
    if VCityRP and VCityRP.OpenBench and IsValid(activator) and activator:IsPlayer() then VCityRP.OpenBench(activator,self) end
end
