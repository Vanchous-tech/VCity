ENT.Type="anim"
ENT.Base="base_anim"
ENT.PrintName="RP / Станок"
ENT.Category="V-City RP"
ENT.Spawnable=false
ENT.AdminOnly=true
ENT.RenderGroup=RENDERGROUP_OPAQUE
