-- meow

AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Clothes base"
ENT.Category = "ZCity Clothes"
ENT.Spawnable = false
ENT.Model = "models/props_junk/cardboard_box003a.mdl"
ENT.IconOverride = ""

ENT.SlotOccupation = {
    --[ZC_CLOTHES_SLOT_TORSO] = true,
    --[ZC_CLOTHES_SLOT_PANTS] = true,
    --[ZC_CLOTHES_SLOT_BOOTS] = true,
}

ENT.Male = {}
ENT.Male.Model = ""
ENT.Male.HideSubMaterails = {}
ENT.Male.Skin = 0
ENT.Male.Bodygroups = "0000000000000"

ENT.FeMale = {}
ENT.FeMale.Model = ""
ENT.FeMale.HideSubMaterails = {}
ENT.FeMale.Skin = 0
ENT.FeMale.Bodygroups = "0000000000000"

ENT.PhysicsSounds = true

ENT.NamePos = Vector(12,1.5,4.6)
ENT.NameAng = Angle(0,-90,0)

local textcolor = Color(0, 0, 0)

function ENT:Draw()
    if self:GetMoveType() == MOVETYPE_NONE or self.GetEquiped and self:GetEquiped() then self:DrawShadow(false) return end
    self:DrawModel()

    local pos, ang = LocalToWorld(self.NamePos * self:GetModelScale(), self.NameAng, self:GetPos(), self:GetAngles())
    cam.Start3D2D(pos,ang, 0.10 * self:GetModelScale())
        local light1 = render.ComputeLighting(pos, ang:Up() * 1)
        local light2 = render.ComputeDynamicLighting(pos, ang:Up() * 1)

        local light = (light1 + light2) * 2
        textcolor.r = 255 * light[1]
        textcolor.g = 55 * light[2]
        textcolor.b = 55 * light[3]
        draw.SimpleText(self.PrintName, "HomigradFontSmall", 1, 1, color_black, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        draw.SimpleText(self.PrintName, "HomigradFontSmall", 0, 0, textcolor, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

function ENT:SetupDataTables()
    self:NetworkVar( "Bool", "Equiped" )
    if SERVER then
        self:SetEquiped(false)
    end
end

function ENT:Initialize()
    self:SetModel(self.Model)

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
    self:DrawShadow(true)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
    	phys:SetMass(15)
    	phys:Wake()
    	phys:EnableMotion(true)
    end

    if SERVER then
        self:SetUseType(SIMPLE_USE)
    end
end

--\\ CanWear
    function ENT:CanWear(entUser)
        local Clothes = entUser:GetNetVar("zc_clothes", {})
        if IsValid(self.WearOwner) then return false end

        for _,v in pairs(Clothes) do
            local cloth = Entity(v)
            if !IsValid(cloth) then continue end
            --PrintTable(v.SlotOccupation)
            --PrintTable(self.SlotOccupation)
            for slot, _ in pairs(cloth.SlotOccupation) do
                if isnumber(slot) and self.SlotOccupation[slot] then return false end
            end

            for slot, _ in pairs(self.SlotOccupation) do
                if isnumber(slot) and cloth.SlotOccupation[slot] then return false end
            end
        end

        return true
    end
--//
--\\ Use function
    function ENT:Use(entUser)
        if !self:CanWear(entUser) then return end

        self:Wear(entUser)
    end
--//
--\\ Wear Unwear functions
    function ENT:Wear(entUser, bDontChangeMaterials, noChange)
        if !self.Respawned then -- I'M VERRY SORRY FOR THIS SILLY SHIT, BUT GMOD IS BULLSHIT I CAN'T REMOVE ENT FROM PLAYERS CLEANUP ACTUALY I CAN BUT IS MORE JANKY THAN THAT!!!
            local class = self:GetClass()
            local ent = ents.Create(class)
            if !IsValid(ent) then return end
            ent.Respawned = true
            ent:Spawn()
            ent:Wear(entUser, bDontChangeMaterials, noChange)

            SafeRemoveEntity(self)
            return
        end

        if !noChange then
            local Clothes = entUser:GetNetVar("zc_clothes", {})
            Clothes[#Clothes + 1] = self:EntIndex()
            entUser:SetNetVar("zc_clothes", Clothes)
        end

        local fem = ThatPlyIsFemale(entUser)
        local data = fem and self.FeMale or self.Male
        if !bDontChangeMaterials then
            for k,v in ipairs(data.HideSubMaterails) do
                local mat = entUser:GetSubMaterialIdByName(v)
                if !mat then continue end
                self.OldSubMaterials = self.OldSubMaterials or {}
                self.OldSubMaterials[mat] = entUser:GetSubMaterial(mat)

                entUser:SetSubMaterial(mat,"NULL")
                local curchar = hg.GetCurrentCharacter(entUser)
                if IsValid(curchar) and curchar:IsRagdoll() then
                    curchar:SetSubMaterial(mat,"NULL")
                end
            end
        end

        self:SetPos(entUser:GetPos())
        self:SetParent(entUser, 0)
        self.WearOwner = entUser

        self:SetNoDraw(false)
        self:SetMoveType(MOVETYPE_NONE)
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
        self:AddSolidFlags(FSOLID_NOT_SOLID)
        self:SetSolid(SOLID_NONE)
        self:AddEFlags(EFL_KEEP_ON_RECREATE_ENTITIES)
        self:DrawShadow(false)
        self:SetEquiped(true)

        self:OnWear(entUser)
    end

    function ENT:OnWear(entUser)
		--// Write your code here
	end
---------------------------------------------------------------
    function ENT:Unwear(entUser, bDontChangeMaterials, noChange)
        if !noChange then
            local Clothes = entUser:GetNetVar("zc_clothes", {})
            table.RemoveByValue(Clothes, self:EntIndex())
            entUser:SetNetVar("zc_clothes", Clothes)
        end

        if !bDontChangeMaterials and self.OldSubMaterials then
            for k,v in pairs(self.OldSubMaterials) do
                entUser:SetSubMaterial(k,v)
                local curchar = hg.GetCurrentCharacter(entUser)
                if IsValid(curchar) and curchar:IsRagdoll() then
                    curchar:SetSubMaterial(k,v)
                end
            end
            table.Empty(self.OldSubMaterials)
        end

        self:SetParent(nil)
        self:SetNoDraw(false)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
        self:RemoveSolidFlags(FSOLID_NOT_SOLID)
        self:SetSolid(SOLID_VPHYSICS)
        self:RemoveEFlags(EFL_KEEP_ON_RECREATE_ENTITIES)
        self:DrawShadow(true)
        self:SetEquiped(false)

        timer.Simple(0,function()
            if !IsValid(self) or !IsValid(entUser) then return end
            self:SetPos(entUser:IsPlayer() and hg.eyeTrace(entUser).StartPos or entUser:GetPos())
        end)
        if !noChange then
            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:AddVelocity(entUser:IsPlayer() and hg.eyeTrace(entUser).Normal * 65 or vector_origin)
            end

            self:SetAngles(entUser:EyeAngles())
        end

        self.WearOwner = nil

        self:OnUnwear(entUser)
    end

    function ENT:OnUnwear(entUser)
		--// Write your code here
	end
--//

--\\
    function ENT:OnRemove()
        if !IsValid(self.WearOwner) then return end

        self:Unwear(self.WearOwner)
    end
--//

--\\ Render clothes
    local vec = Vector(1,1,1)
    function ENT:RenderOnBody(entDrawOn)
        local fem = ThatPlyIsFemale(entDrawOn)

        if !IsValid(self.renderModel) then
            local data = fem and self.FeMale or self.Male
            self.renderModel = ClientsideModel(data.Model, RENDERGROUP_BOTH)

            local model = self.renderModel
            model:SetNoDraw(true)
            model:SetSkin(data.Skin)
            model:SetBodyGroups(data.Bodygroups)
            model:SetParent(entDrawOn)
            model:AddEffects(EF_BONEMERGE)

            if data.ModelSubMaterials then
                for k,v in pairs(data.ModelSubMaterials) do
                    local id = isnumber(k) and k or model:GetSubMaterialIdByName(k)
                    if !id then continue end
                    model:SetSubMaterial(id, v)
                end
            end

            self:CallOnRemove("RemoveCloth",function()
                if IsValid(self.renderModel) then
                    model:Remove()
                    model = nil
                end
            end)
        end

        local model = self.renderModel

        local mdl = string.Split(string.sub(entDrawOn:GetModel(),1,-5),"/")[#string.Split(string.sub(entDrawOn:GetModel(),1,-5),"/")]
        if mdl and model:GetFlexIDByName(mdl) then
            model:SetFlexWeight(model:GetFlexIDByName(mdl),1)
        end

        if model:GetParent() != entDrawOn then model:SetParent(entDrawOn) end

        model:DrawModel()
    end
--//

--\\ Render hook
    hook.Add("CoolPostDrawAppearance", "ZC_ClothesDraw",function(ent, ply)
        local Clothes = ply:GetNetVar("zc_clothes", {})
        if #Clothes < 1 then return end

        for i = 1, #Clothes do
            local Cloth = Entity(Clothes[i])
            if !IsValid(Cloth) then continue end
            Cloth:RenderOnBody(ent)
        end
    end)
--//

--\\ Transfer items
    hook.Add("ItemsTransfered", "TransferClothes", function(ply, ragdoll)
        local Clothes = ply:GetNetVar("zc_clothes", {})
        if #Clothes < 1 then return end

        for i = 1, #Clothes do
            local Cloth = Entity(Clothes[i])
            if !IsValid(Cloth) then continue end
            Cloth:Unwear(ply, true, true)
            Cloth:Wear(ragdoll, true, true)
        end
        ragdoll:SetNetVar("zc_clothes",Clothes)
        ply:SetNetVar("zc_clothes", {})
    end)
--//

--\\ Temperature system
    hook.Add("ZC_BodyTemperature", "ClothesSaveTemp", function(ply, org, timeValue, changeRate, MaxWarmMul, warmLoseMul)
        local Clothes = ply:GetNetVar("zc_clothes", {})
        if #Clothes < 1 then return end

        for i = 1, #Clothes do
            local Cloth = Entity(Clothes[i])
            if !IsValid(Cloth) then continue end
            if !Cloth.WarmSave then continue end
            MaxWarmMul = MaxWarmMul + (Cloth.WarmSave / 1.5)
            changeRate = changeRate * math.max(1 - Cloth.WarmSave, 0.1)
            --warmLoseMul = warmLoseMul * math.max(1 - Cloth.WarmSave / 2.5, 0.1)
        end

        return changeRate, MaxWarmMul, warmLoseMul
    end)
--//

--\\ Clothes drop command
    if SERVER then
        concommand.Add("hg_drop_clothes", function(ply, cmd, args)
            if !IsValid(ply) then return end
            if !ply:Alive() or !ply.organism or ply.organism.otrub then return end
            if !args[1] or !tonumber(args[1]) then return end
            local Clothes = ply:GetNetVar("zc_clothes", {})

            for i = 1, #Clothes do
                local Cloth = Entity(Clothes[i])

                for slot, _ in pairs(Cloth.SlotOccupation) do
                    if isnumber(slot) and tonumber(args[1]) == slot then
                        Cloth:Unwear(ply)
                        return
                    end
                end
            end
        end)
    end

    hook.Add("radialOptions", "zc_clothes", function()
        local ply = LocalPlayer()
        local organism = ply.organism or {}

        if ply:Alive() and !organism.otrub and hg.GetCurrentCharacter(ply) == ply then
            local Clothes = ply:GetNetVar("zc_clothes", {})
            if !Clothes or #Clothes < 1 then return end
            local tbl = {function()
                local commands = {}
                for i = 1, #Clothes do
                    local Cloth = Entity(Clothes[i])

                    for slot, _ in pairs(Cloth.SlotOccupation) do
                        commands[i] = {
                            [1] = function()
                                local id = next(Cloth.SlotOccupation)
                                RunConsoleCommand("hg_drop_clothes", id)
                                return 0
                            end,
                            [2] = "Drop:" .. " " .. Cloth.PrintName
                        }
                    end
                end
                hg.CreateRadialMenu(commands)
                return -1
            end, "Drop clothes"}
            hg.radialOptions[#hg.radialOptions + 1] = tbl
        end
    end)
--//