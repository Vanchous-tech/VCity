-- ================================================================
-- Окно IQ-теста для sv_fury_iqtest.lua. Чисто отрисовка — всю логику
-- и правильные ответы хранит сервер, клиент только шлёт номер кнопки.
-- ================================================================

local frame

local function closeFrame()
	if IsValid(frame) then frame:Remove() end
	frame = nil
end

net.Receive("fury_iq_question", function()
	local intro = net.ReadString()
	local idx = net.ReadUInt(8)
	local total = net.ReadUInt(8)
	local question = net.ReadString()
	local optCount = net.ReadUInt(8)
	local options = {}
	for i = 1, optCount do options[i] = net.ReadString() end

	closeFrame()

	frame = vgui.Create("DFrame")
	frame:SetSize(420, 320)
	frame:Center()
	frame:SetTitle("IQ-тест")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)

	local introLbl = vgui.Create("DLabel", frame)
	introLbl:SetPos(15, 30)
	introLbl:SetSize(390, 55)
	introLbl:SetWrap(true)
	introLbl:SetAutoStretchVertical(true)
	introLbl:SetFont("DermaDefaultBold")
	introLbl:SetText(intro)

	local progressLbl = vgui.Create("DLabel", frame)
	progressLbl:SetPos(15, 90)
	progressLbl:SetSize(390, 20)
	progressLbl:SetText(string.format("Вопрос %d из %d", idx, total))

	local qLbl = vgui.Create("DLabel", frame)
	qLbl:SetPos(15, 115)
	qLbl:SetSize(390, 40)
	qLbl:SetWrap(true)
	qLbl:SetFont("DermaDefaultBold")
	qLbl:SetText(question)

	local y = 160
	for i, opt in ipairs(options) do
		local btn = vgui.Create("DButton", frame)
		btn:SetPos(15, y)
		btn:SetSize(390, 30)
		btn:SetText(opt)
		btn.DoClick = function()
			net.Start("fury_iq_answer")
				net.WriteUInt(i, 8)
			net.SendToServer()
		end
		y = y + 36
	end
end)

net.Receive("fury_iq_result", function()
	local success = net.ReadBool()
	local msg = net.ReadString()
	closeFrame()

	local notif = vgui.Create("DFrame")
	notif:SetSize(360, 110)
	notif:Center()
	notif:SetTitle(success and "Тест пройден" or "Тест провален")
	notif:MakePopup()
	notif:SetDraggable(false)

	local lbl = vgui.Create("DLabel", notif)
	lbl:SetPos(15, 30)
	lbl:SetSize(330, 60)
	lbl:SetWrap(true)
	lbl:SetText(msg)

	timer.Simple(3, function() if IsValid(notif) then notif:Remove() end end)
end)
