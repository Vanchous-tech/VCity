-- V-City RP prototype loader. Replaces only the mode-loading layer.
-- Retains the original mechanics; only a small appearance guard is added separately.
VCityRP = VCityRP or {}
zb = zb or {}
hg = hg or {}

local shared = {"rp/sh_config.lua", "rp/sh_profession.lua", "rp/sh_compat.lua", "rp/sh_rpchat.lua", "rp/sh_restart.lua"}
for _, path in ipairs(shared) do
    if SERVER then AddCSLuaFile(path) end
    include(path)
end
if SERVER then
    AddCSLuaFile("rp/cl_menu.lua")
    AddCSLuaFile("rp/cl_admin.lua")
    AddCSLuaFile("rp/cl_services.lua")
    AddCSLuaFile("rp/cl_radial.lua")
    AddCSLuaFile("rp/cl_restart.lua")
    AddCSLuaFile("rp/cl_patches.lua")
    AddCSLuaFile("rp/cl_points.lua")
    AddCSLuaFile("rp/cl_vehicles.lua")
    include("rp/sv_config.lua")
end

local excluded = {
    ["sv_roundsystem.lua"] = true,
    ["sv_antiafk.lua"] = true, -- no AFK spectator/kick subsystem
    ["cl_modeselect_menu.lua"] = true,
    ["sh_ulxcommands.lua"] = true -- this file contains the old mode-voting command
}

local function includeLibrary(path, name)
    if excluded[name] then return end
    if name:sub(1, 3) == "sv_" then
        if SERVER then include(path) end
    elseif name:sub(1, 3) == "cl_" then
        if SERVER then AddCSLuaFile(path) else include(path) end
    elseif name == "shared.lua" or name:sub(1, 3) == "sh_" then
        if SERVER then AddCSLuaFile(path) end
        include(path)
    end
end

local function loadLibraries(directory)
    local files, folders = file.Find(directory .. "/*", "LUA")
    table.sort(files)
    table.sort(folders)
    for _, folder in ipairs(folders) do
        -- rtv and the karma subsystem (guilt) belong to the removed modes; rp/sv_guilt_stub.lua
        -- keeps the retained gameplay reading the fields it still expects.
        if folder ~= "rtv" and folder ~= "guilt" then loadLibraries(directory .. "/" .. folder) end
    end
    for _, name in ipairs(files) do includeLibrary(directory .. "/" .. name, name) end
end

loadLibraries("zcity/gamemode/libraries")
-- Deliberately do not scan or include zcity/gamemode/modes/.
if SERVER then
    include("rp/sv_runtime.lua")
    include("rp/sv_progress.lua") -- playtime per role and chained unlocks
    include("rp/sv_subclass.lua") -- subclasses of military ranks
    include("rp/sv_profession.lua")
    include("rp/sv_roleadmin.lua")
    include("rp/sv_money.lua")
    include("rp/sv_interaction.lua")
    include("rp/sv_workshop.lua")
    include("rp/sv_attachments.lua")
    include("rp/sv_guilt_stub.lua") -- karma-free replacement for the excluded guilt folder
    include("rp/sv_restart.lua") -- daily restart countdown and night reminder
    include("rp/sv_armband.lua") -- красные повязки для ВС РФ и «Дрины»
    include("rp/sv_comms.lua") -- связист, шифр, метки отряда, деньги по SMS, опыт за разведку
    include("rp/sv_factionlock.lua") -- лимит смены фракции: 15 мин / раз в сутки для лейтенантов
    include("rp/sv_log.lua") -- журнал событий по дням
    include("rp/sv_rewards.lua") -- выдача денег, награды за звания и подклассы
    include("rp/sv_stats.lua") -- статистика игроков и сторон за 14 дней
    include("rp/sv_points.lua") -- захват точек
    include("rp/sv_vehicles.lua") -- спавнеры транспорта (JSON на карту, респавн по таймеру)
    include("rp/sv_heavy.lua") -- тяжёлая техника только для подкласса «Член экипажа»
else
    include("rp/cl_menu.lua")
    include("rp/cl_admin.lua")
    include("rp/cl_services.lua")
    include("rp/cl_radial.lua")
    include("rp/cl_restart.lua")
    include("rp/cl_patches.lua")
    include("rp/cl_points.lua")
    include("rp/cl_vehicles.lua")
end
print("[V-City RP] " .. VCityRP.Version .. " loaded.")
