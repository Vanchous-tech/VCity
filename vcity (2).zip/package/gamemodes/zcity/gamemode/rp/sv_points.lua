-- V-City RP 0.6.0 — SERVER ONLY. Захват точек.
-- Точка — круг на карте. Сторона (usa / ru = ВС РФ + Дрина), оставшаяся в круге в одиночку, набирает
-- прогресс 0–100; если в круге обе стороны — захват стоит. Захватил — владеешь, пока не отобьют.
-- Награда: деньги всем захватившим в круге + периодический доход всем игрокам стороны за каждую точку.
-- Конфиг точек: data/vcity_rp/points_<карта>.json (владельцы сохраняются между рестартами).
-- Админ (суперадмин): vcity_rp_point_add <имя> [радиус] [here]
--   (точка ставится ТУДА, КУДА ВЫ СМОТРИТЕ; третьим аргументом here — под ногами)
--   vcity_rp_point_move <id> [радиус] · vcity_rp_point_radius <id> <радиус>
--   vcity_rp_point_remove <id> · vcity_rp_point_list · vcity_rp_point_owner <id> usa|ru|none
--   vcity_rp_point_reset (все нейтральны) · vcity_rp_points_reload
-- Конвары: vcity_rp_point_time (секунд на захват одним игроком, 60), vcity_rp_point_reward (150),
--   vcity_rp_point_income (за точку за интервал, 40), vcity_rp_point_income_every (секунд, 300).
local RP = VCityRP

RP.Points = RP.Points or {}
RP.PointMax = 16
local cvTime = CreateConVar("vcity_rp_point_time", "60", FCVAR_ARCHIVE, "Секунд на захват точки одним игроком")
local cvReward = CreateConVar("vcity_rp_point_reward", "150", FCVAR_ARCHIVE, "Награда каждому захватившему")
local cvIncome = CreateConVar("vcity_rp_point_income", "40", FCVAR_ARCHIVE, "Доход игроку стороны за каждую точку за интервал")
local cvEvery = CreateConVar("vcity_rp_point_income_every", "300", FCVAR_ARCHIVE, "Интервал дохода с точек, секунд")

util.AddNetworkString("vcity_rp_points")

local SIDE_NAMES = { usa = "США", ru = "РФ и Дрина" }

local function File() return "vcity_rp/points_" .. string.lower(game.GetMap()) .. ".json" end

-- Чистая логика одного шага (тестируется без движка).
-- p = {owner="", cap="", prog=0}; usaN/ruN — число игроков сторон в круге; speed — прогресс/сек.
-- Возвращает сторону, захватившую точку на этом шаге, или nil.
function RP.PointStep(p, usaN, ruN, speed)
    p.contested = usaN > 0 and ruN > 0
    local side = (usaN > 0 and ruN == 0) and "usa" or ((ruN > 0 and usaN == 0) and "ru" or nil)

    if p.contested then return nil end

    if not side then
        p.prog = math.max(0, (p.prog or 0) - 1)
        if p.prog == 0 then p.cap = "" end
        return nil
    end

    if side == p.owner then
        if (p.prog or 0) > 0 then
            p.prog = math.max(0, p.prog - speed * 2)
            if p.prog == 0 then p.cap = "" end
        end
        return nil
    end

    if p.cap == side or (p.prog or 0) <= 0 then
        p.cap = side
        p.prog = (p.prog or 0) + speed
        if p.prog >= 100 then
            p.owner, p.prog, p.cap = side, 0, ""
            return side
        end
    else
        p.prog = math.max(0, p.prog - speed * 1.5)
    end
    return nil
end

-- ================= сохранение =================
local function Save()
    file.CreateDir("vcity_rp")
    local out = {}
    for _, p in ipairs(RP.Points) do
        out[#out + 1] = { id = p.id, name = p.name, x = p.x, y = p.y, z = p.z, r = p.r, owner = p.owner }
    end
    local old = file.Read(File(), "DATA")
    if old and old ~= "" then file.Write(string.gsub(File(), "%.json$", ".previous.json"), old) end
    file.Write(File(), util.TableToJSON(out, true))
end

local function Load()
    RP.Points = {}
    local raw = file.Read(File(), "DATA")
    local parsed = raw and raw ~= "" and util.JSONToTable(raw) or nil
    if not istable(parsed) then return end
    for _, p in ipairs(parsed) do
        if #RP.Points >= RP.PointMax then break end
        local x, y, z, r = tonumber(p.x), tonumber(p.y), tonumber(p.z), tonumber(p.r)
        if x and y and z and r and isstring(p.name) then
            RP.Points[#RP.Points + 1] = {
                id = #RP.Points + 1, name = string.sub(string.gsub(p.name, "[|;%c]", ""), 1, 24),
                x = x, y = y, z = z, r = math.Clamp(r, 100, 1500),
                owner = (p.owner == "usa" or p.owner == "ru") and p.owner or "", cap = "", prog = 0,
            }
        end
    end
end

-- ================= сеть =================
local lastSig = ""
local function Signature()
    local parts = {}
    for _, p in ipairs(RP.Points) do
        parts[#parts + 1] = p.id .. p.owner .. (p.cap or "") .. math.floor(p.prog or 0) .. (p.contested and "c" or "")
    end
    return table.concat(parts, ",")
end

local function Send(target)
    net.Start("vcity_rp_points")
    net.WriteUInt(#RP.Points, 5)
    for _, p in ipairs(RP.Points) do
        net.WriteString(p.name)
        net.WriteFloat(p.x) net.WriteFloat(p.y) net.WriteFloat(p.z)
        net.WriteUInt(math.floor(p.r), 12)
        net.WriteString(p.owner)
        net.WriteString(p.cap or "")
        net.WriteUInt(math.Clamp(math.floor(p.prog or 0), 0, 100), 7)
        net.WriteBool(p.contested == true)
    end
    if target then net.Send(target) else net.Broadcast() end
end

hook.Add("PlayerInitialSpawn", "VCityRP.PointsSync", function(ply)
    timer.Simple(4, function() if IsValid(ply) then Send(ply) end end)
end)

-- ================= игроки в круге =================
local function InCircle(ply, p)
    local pos = ply:GetPos()
    local dx, dy = pos.x - p.x, pos.y - p.y
    return dx * dx + dy * dy <= p.r * p.r and math.abs(pos.z - p.z) <= 300
end

local function Present(p)
    local list = { usa = {}, ru = {} }
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() then
            local side = RP.SideOfPlayer and RP.SideOfPlayer(ply)
            if list[side] and InCircle(ply, p) then list[side][#list[side] + 1] = ply end
        end
    end
    return list
end

local function Announce(text)
    PrintMessage(HUD_PRINTTALK, text)
end

timer.Create("VCityRP.Points", 1, 0, function()
    if #RP.Points == 0 then return end
    local base = 100 / math.max(cvTime:GetFloat(), 5)

    for _, p in ipairs(RP.Points) do
        local present = Present(p)
        local n = math.max(#present.usa, #present.ru)
        local speed = base * math.min(1 + 0.4 * math.max(n - 1, 0), 2.2)
        local was = p.owner
        local captured = RP.PointStep(p, #present.usa, #present.ru, speed)
        if captured then
            local players = present[captured]
            Announce("[Фронт] " .. SIDE_NAMES[captured] .. " захватили «" .. p.name .. "»" .. (was ~= "" and (" у " .. SIDE_NAMES[was]) or ""))
            if RP.Log then
                local names = {}
                for _, ply in ipairs(players) do names[#names + 1] = RP.Who(ply) end
                RP.Log("point", "«" .. p.name .. "» -> " .. captured .. " (было: " .. (was ~= "" and was or "нейтр.") .. "), участники: " .. table.concat(names, ", "))
            end
            local reward = cvReward:GetInt()
            if reward > 0 and RP.GrantMoneyBatch then
                local list = {}
                for _, ply in ipairs(players) do list[#list + 1] = { ply = ply, amount = reward } end
                local ok = RP.GrantMoneyBatch(list, "захват «" .. p.name .. "»")
                if ok then for _, ply in ipairs(players) do ply:ChatPrint("Награда за захват: +" .. RP.MoneyText(reward)) end end
            end
            hook.Run("VCityRP.PointCaptured", p, captured, players)
            Save()
        end
    end

    local sig = Signature()
    if sig ~= lastSig then
        lastSig = sig
        Send()
    end
end)

-- Доход: за каждую удерживаемую точку — деньги всем игрокам стороны
timer.Create("VCityRP.PointsIncome", 10, 0, function()
    local every = math.max(cvEvery:GetInt(), 30)
    if CurTime() < (RP.PointNextIncome or 0) then return end
    RP.PointNextIncome = CurTime() + every

    local count = { usa = 0, ru = 0 }
    for _, p in ipairs(RP.Points) do
        if count[p.owner] then count[p.owner] = count[p.owner] + 1 end
    end
    local per = cvIncome:GetInt()
    if per <= 0 or (count.usa == 0 and count.ru == 0) or not RP.GrantMoneyBatch then return end

    local list = {}
    for _, ply in ipairs(player.GetAll()) do
        local side = IsValid(ply) and ply:Alive() and RP.SideOfPlayer(ply)
        if side and count[side] and count[side] > 0 then
            list[#list + 1] = { ply = ply, amount = count[side] * per, k = count[side] }
        end
    end
    if #list == 0 then return end
    local ok = RP.GrantMoneyBatch(list, "доход с точек")
    if ok then
        for _, e in ipairs(list) do e.ply:ChatPrint("Доход с точек (" .. e.k .. "): +" .. RP.MoneyText(e.amount)) end
    end
end)

-- сброс владельцев по окончании периода статистики
hook.Add("VCityRP.StatsPeriodEnded", "VCityRP.PointsPeriodReset", function()
    for _, p in ipairs(RP.Points) do p.owner, p.cap, p.prog = "", "", 0 end
    Save()
    Announce("[Фронт] Новый период: все точки снова нейтральны.")
end)

-- ================= админ =================
local function Say(ply, msg)
    if IsValid(ply) then ply:ChatPrint("[V-City RP] " .. msg) else print("[V-City RP] " .. msg) end
end
local function Admin(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then Say(ply, "Только суперадмин.") return false end
    return true
end

-- Позиция по прицелу (до 20000 юнитов); here = под ногами
local function AimPos(ply, here)
    if here then return ply:GetPos() end
    local tr = util.TraceLine({ start = ply:EyePos(), endpos = ply:EyePos() + ply:GetAimVector() * 20000, filter = ply, mask = MASK_SOLID_BRUSHONLY })
    if tr.Hit then return tr.HitPos end
end

concommand.Add("vcity_rp_point_add", function(ply, _, args)
    if not Admin(ply) then return end
    if not IsValid(ply) then return Say(ply, "Команда из игры: встаньте в центр точки.") end
    if #RP.Points >= RP.PointMax then return Say(ply, "Лимит точек: " .. RP.PointMax) end
    local name = string.sub(string.gsub(tostring(args[1] or ("Точка " .. (#RP.Points + 1))), "[|;%c]", ""), 1, 24)
    local pos = AimPos(ply, args[3] == "here")
    if not pos then return Say(ply, "Не вижу куда ставить: наведите прицел на землю (или добавьте here третьим аргументом — тогда в вашу позицию).") end
    RP.Points[#RP.Points + 1] = {
        id = #RP.Points + 1, name = name, x = pos.x, y = pos.y, z = pos.z,
        r = math.Clamp(tonumber(args[2]) or 250, 100, 1500), owner = "", cap = "", prog = 0,
    }
    Save()
    lastSig = ""
    Say(ply, "Точка #" .. #RP.Points .. " «" .. name .. "» добавлена, радиус " .. RP.Points[#RP.Points].r)
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " добавил точку «" .. name .. "»") end
end)

concommand.Add("vcity_rp_point_remove", function(ply, _, args)
    if not Admin(ply) then return end
    local id = tonumber(args[1])
    if not id or not RP.Points[id] then return Say(ply, "usage: vcity_rp_point_remove <id> (список: vcity_rp_point_list)") end
    local name = RP.Points[id].name
    table.remove(RP.Points, id)
    for i, p in ipairs(RP.Points) do p.id = i end
    Save()
    lastSig = ""
    Say(ply, "Точка «" .. name .. "» удалена. Номера точек перенумерованы.")
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " удалил точку «" .. name .. "»") end
end)

-- Перенести точку на место, куда смотрите: vcity_rp_point_move <id> [радиус]
concommand.Add("vcity_rp_point_move", function(ply, _, args)
    if not Admin(ply) or not IsValid(ply) then return end
    local p = RP.Points[tonumber(args[1]) or 0]
    if not p then return Say(ply, "usage: vcity_rp_point_move <id> [радиус] — смотрите туда, куда перенести") end
    local pos = AimPos(ply)
    if not pos then return Say(ply, "Наведите прицел на землю.") end
    p.x, p.y, p.z = pos.x, pos.y, pos.z
    if tonumber(args[2]) then p.r = math.Clamp(tonumber(args[2]), 100, 1500) end
    p.owner, p.cap, p.prog = "", "", 0
    Save()
    Say(ply, "«" .. p.name .. "» перенесена, радиус " .. p.r)
end)

-- Только радиус: vcity_rp_point_radius <id> <радиус>
concommand.Add("vcity_rp_point_radius", function(ply, _, args)
    if not Admin(ply) then return end
    local p, r = RP.Points[tonumber(args[1]) or 0], tonumber(args[2])
    if not p or not r then return Say(ply, "usage: vcity_rp_point_radius <id> <100-1500>") end
    p.r = math.Clamp(r, 100, 1500)
    Save()
    Say(ply, "«" .. p.name .. "» радиус " .. p.r)
end)

concommand.Add("vcity_rp_point_list", function(ply)
    if not Admin(ply) then return end
    if #RP.Points == 0 then return Say(ply, "Точек нет. Встаньте в центр и: vcity_rp_point_add <имя> [радиус]") end
    for _, p in ipairs(RP.Points) do
        Say(ply, string.format("#%d «%s» (%.0f, %.0f, %.0f) r=%d владелец: %s", p.id, p.name, p.x, p.y, p.z, p.r, p.owner ~= "" and p.owner or "нейтр."))
    end
end)

concommand.Add("vcity_rp_point_owner", function(ply, _, args)
    if not Admin(ply) then return end
    local p = RP.Points[tonumber(args[1]) or 0]
    local owner = args[2] == "none" and "" or args[2]
    if not p or not (owner == "" or owner == "usa" or owner == "ru") then return Say(ply, "usage: vcity_rp_point_owner <id> usa|ru|none") end
    p.owner, p.cap, p.prog = owner, "", 0
    Save()
    Say(ply, "«" .. p.name .. "» -> " .. (owner == "" and "нейтрально" or owner))
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " задал владельца «" .. p.name .. "»: " .. (owner == "" and "нейтр." or owner)) end
end)

concommand.Add("vcity_rp_point_reset", function(ply)
    if not Admin(ply) then return end
    for _, p in ipairs(RP.Points) do p.owner, p.cap, p.prog = "", "", 0 end
    Save()
    Say(ply, "Все точки нейтральны.")
end)

concommand.Add("vcity_rp_points_reload", function(ply)
    if not Admin(ply) then return end
    Load()
    lastSig = ""
    Say(ply, "Точек загружено: " .. #RP.Points)
end)

Load()
print("[V-City RP] Захват точек: точек на карте — " .. #RP.Points)
