-- V-City RP — связь: подкласс «Связист», шифр, сканер, ремонт вышек, SMS-переводы,
-- метки отряда на карте и опыт за разведку. Работает вместе с аддонами zc_phone и zc_map;
-- без них хуки просто не вызываются.
local RP=VCityRP

-- Опыт за разведку: минуты прогресса на текущей роли. Кулдаун защищает от накрутки.
RP.IntelMinutes={lock=2,loot=2,repair=3}
RP.IntelCooldown={lock=90,loot=60,repair=120}
RP.IntelTargetCooldown=300 -- один и тот же противник для lock не чаще раза в N секунд

-- Какие фракции играют на одной стороне (метки отряда видит вся сторона).
RP.SideOf={usa="usa",rf="ru",drina="ru"}

local function role(ply) return IsValid(ply) and RP.RoleByID(RP.GetRole(ply).ID) or nil end
local function isSignaller(ply)
    local r=role(ply)
    return r~=nil and RP.SubclassAllowed(r) and ply:GetNW2String(RP.SubNWKey,"")=="signaller"
end
local function isCommander(ply)
    local r=role(ply)
    if not r or not RP.SideOf[r.Faction] then return false end
    return string.match(r.ID,"_sergeant$")~=nil or string.match(r.ID,"_junior_lieutenant$")~=nil or r.ID=="delta_leader"
end
RP.IsSignaller,RP.IsCommander=isSignaller,isCommander

-- Права телефонной системы
hook.Add("ZCPhone_CanScan","VCityRP.Comms",function(ply) if not (isSignaller(ply) or ply:IsSuperAdmin()) then return false end end)
hook.Add("ZCPhone_CanRepairTower","VCityRP.Comms",function(ply) if not (isSignaller(ply) or ply:IsSuperAdmin()) then return false end end)
hook.Add("ZCPhone_CanEncrypt","VCityRP.Comms",function(ply) if not (isSignaller(ply) or isCommander(ply)) then return false end end)

-- Деньги по SMS: «перевод 500» получателю. Работает через общий кошелёк.
hook.Add("ZCPhone_Transfer","VCityRP.Comms",function(from,to,amount)
    if (from.VCityRPNextPay or 0)>CurTime() then return false,"Подождите перед следующим переводом" end
    local ok,err=RP.TransferMoney(from,to,amount)
    if not ok then return false,err end
    from.VCityRPNextPay=CurTime()+3
    from:ChatPrint("Перевод: -"..RP.MoneyText(amount))
    to:ChatPrint("Перевод: +"..RP.MoneyText(amount))
    return true
end)

-- Метки отряда: команда = сторона конфликта; ставят сержанты, офицеры и связисты.
hook.Add("ZCMap_Team","VCityRP.Comms",function(ply)
    local r=role(ply)
    return r and RP.SideOf[r.Faction] or nil
end)
hook.Add("ZCMap_CanMark","VCityRP.Comms",function(ply)
    if not (isCommander(ply) or isSignaller(ply)) then return false end
end)

-- Связист получает сканер вместе с экипировкой роли (после StripWeapons).
hook.Add("RP_RoleLoadout","VCityRP.Signaller",function(ply)
    if not isSignaller(ply) or not weapons.GetStored("weapon_zc_scanner") then return end
    if not ply:HasWeapon("weapon_zc_scanner") then ply:Give("weapon_zc_scanner",true) end
end)

-- Опыт за разведку
local function grant(ply,kind)
    if not IsValid(ply) or ply:IsBot() then return end
    ply.VCityRPIntelAt=ply.VCityRPIntelAt or {}
    if (ply.VCityRPIntelAt[kind] or 0)>CurTime() then return end
    ply.VCityRPIntelAt[kind]=CurTime()+(RP.IntelCooldown[kind] or 60)
    local minutes=RP.IntelMinutes[kind] or 0
    if minutes<=0 or not RP.AddRoleSeconds then return end
    if RP.AddRoleSeconds(ply,RP.GetRole(ply).ID,minutes*60) then
        ply:ChatPrint("Разведка: +"..minutes.." мин к прогрессу роли")
    end
end
hook.Add("ZCPhone_Intel","VCityRP.Intel",function(ply,kind,data)
    if kind=="lock" and IsValid(data) then
        ply.VCityRPIntelTargets=ply.VCityRPIntelTargets or {}
        local id=data:SteamID64() or tostring(data)
        if (ply.VCityRPIntelTargets[id] or 0)>CurTime() then return end
        ply.VCityRPIntelTargets[id]=CurTime()+RP.IntelTargetCooldown
    end
    grant(ply,kind)
end)

-- Оператор БПЛА: единственный, кто управляет FPV-дронами (аддон zcity_fpv_port v4).
-- Роль одна на сервер (RP.UAVLimit), экипировка выдаётся кодом и не зависит от config.json.
RP.UAVRole="drina_uav"
RP.UAVLimit=1
hook.Add("ZCFPV_CanOperate","VCityRP.UAV",function(ply)
    if ply:IsSuperAdmin() then return end
    local r=role(ply)
    if not r or r.ID~=RP.UAVRole then return false end
end)
hook.Add("VCityRP.CanChooseRole","VCityRP.UAV",function(ply,newRole)
    if not newRole or newRole.ID~=RP.UAVRole then return end
    local taken=0
    for _,other in ipairs(player.GetAll()) do
        if other~=ply and RP.GetRole(other).ID==RP.UAVRole then taken=taken+1 end
    end
    if taken>=RP.UAVLimit then return false,"Оператор БПЛА уже занят." end
end)
hook.Add("RP_RoleLoadout","VCityRP.UAV",function(ply)
    local r=role(ply)
    if not r or r.ID~=RP.UAVRole or not weapons.GetStored("weapon_zc_fpv_goggles") then return end
    if not ply:HasWeapon("weapon_zc_fpv_goggles") then ply:Give("weapon_zc_fpv_goggles",true) end
end)

-- Связист в ранге сержанта и выше получает в телефоне номера всех игроков своей стороны.
-- Контакты служебные: не занимают книгу, не сохраняются, пропадают вместе с правом.
hook.Add("ZCPhone_ExtraContacts","VCityRP.Comms",function(ply)
    if not (isSignaller(ply) and isCommander(ply)) then return end
    local side=RP.SideOf[role(ply).Faction]
    local out={}
    for _,other in ipairs(player.GetAll()) do
        if other~=ply and other.zcPhoneNumber and not other:IsBot() then
            local r=role(other)
            if r and RP.SideOf[r.Faction]==side then out[#out+1]={num=other.zcPhoneNumber,name=other:Nick()} end
        end
    end
    return out
end)

-- Строки курса «Штаба» про механики V-City (вставляются перед финальным сообщением).
hook.Add("ZCPhone_CourseExtra","VCityRP.Comms",function()
    local sw=RP.FactionSwitch or {}
    local newbie=math.floor((sw.newbieSeconds or 900)/60)
    local vet=math.floor((sw.veteranSeconds or 86400)/3600)
    return {
        "Связист в ранге сержанта и выше видит в телефоне номера всех своих автоматически :)",
        "F4 - выбор фракции, роли и подкласса. Подкласс выезжает лесенкой под выбранным званием :)",
        string.format("Смена фракции: новичку раз в %d мин, а после звания лейтенанта раз в %d ч. Выбирай с умом :0",newbie,vet),
    }
end)
