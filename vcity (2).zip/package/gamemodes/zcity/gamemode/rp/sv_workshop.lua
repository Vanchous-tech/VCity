-- Fictional in-game SWEP workshop; no real-world weapon construction content.
local RP=VCityRP
RP.WorkshopPath="vcity_rp/workshop.json"
RP.Workshop={version=1,revision=1,recipes={},stations={}}
RP.CraftSessions={};RP.CraftCooldowns={};RP.BenchEntities={}
for _,name in ipairs({RP.NetServices,RP.NetServicesResult,RP.NetBenchOpen,RP.NetCraftStart,RP.NetCraftAction,RP.NetCraftState}) do util.AddNetworkString(name) end
local function finite(n) return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge end
function RP.NormalizeWorkshop(input)
    if type(input)~="table" or (input.version and input.version~=1) then return nil,"Неверный workshop JSON." end
    local out={version=1,revision=input.revision or 1,recipes={},stations={}}
    if not finite(out.revision) or out.revision<1 or out.revision~=math.floor(out.revision) then return nil,"Неверная ревизия." end
    if type(input.recipes or {})~="table" or type(input.stations or {})~="table" then return nil,"Неверные списки." end
    local total=0
    for id,recipe in pairs(input.recipes or {}) do
        total=total+1;if total>48 then return nil,"Максимум 48 рецептов." end
        if type(id)~="string" or #id>40 or not id:match("^[a-z][a-z0-9_]*$") or type(recipe)~="table" then return nil,"Неверный ID рецепта." end
        local name,err=RP.ValidateProfession(recipe.name or id);if not name then return nil,err end
        if type(recipe.class)~="string" or #recipe.class>64 or not recipe.class:match("^weapon_[a-z0-9_]+$") then return nil,"Неверный SWEP." end
        local kind=recipe.kind or "pistol"
        if kind~="pistol" and kind~="automatic" and kind~="rifle" then return nil,"Тип: pistol / automatic / rifle." end
        local difficulty=recipe.difficulty or 2;local cooldown=recipe.cooldown or 60
        if not finite(difficulty) or difficulty<1 or difficulty>5 or difficulty~=math.floor(difficulty) then return nil,"Сложность: 1–5." end
        if not finite(cooldown) or cooldown<10 or cooldown>3600 then return nil,"Cooldown: 10–3600 секунд." end
        local attachments={}
        if recipe.attachments~=nil then
            if type(recipe.attachments)~="table" or #recipe.attachments>6 then return nil,"Рецепт: до 6 обвесов." end
            for _,item in ipairs(recipe.attachments) do
                if type(item)~="string" or #item>48 or not item:match("^[%a_][%w_]*$") then return nil,"Неверный ID обвеса в рецепте." end
                if hg and type(hg.attachments)=="table" and not RP.AttachmentPlacementOf(item) then return nil,"Неизвестный обвес в рецепте: "..item end
                attachments[#attachments+1]=item
            end
        end
        out.recipes[id]={name=name,class=recipe.class,kind=kind,difficulty=difficulty,cooldown=cooldown,enabled=recipe.enabled~=false,attachments=attachments}
    end
    local maps=0
    for map,points in pairs(input.stations or {}) do
        maps=maps+1;if maps>32 or type(map)~="string" or not map:match("^[%w_%-]+$") or #map>80 or type(points)~="table" or #points>16 then return nil,"Неверная карта/станки." end
        local count=0;for key in pairs(points) do count=count+1;if type(key)~="number" or key<1 or key~=math.floor(key) then return nil,"Точки должны быть массивом." end end
        if count~=#points then return nil,"Массив точек с пропусками." end
        out.stations[map]={}
        for i,point in ipairs(points) do
            if type(point)~="table" or not finite(point.x) or not finite(point.y) or not finite(point.z) or math.abs(point.x)>32768 or math.abs(point.y)>32768 or math.abs(point.z)>32768 or not finite(point.yaw or 0) then return nil,"Неверная точка станка." end
            out.stations[map][i]={x=point.x,y=point.y,z=point.z,yaw=point.yaw or 0}
        end
    end
    out.prices={}
    if type(input.prices or {})~="table" then return nil,"prices должен быть объектом класс=цена." end
    local priced=0
    for class,cost in pairs(input.prices or {}) do
        priced=priced+1;if priced>64 then return nil,"Максимум 64 цены закупки." end
        if type(class)~="string" or #class>64 or not class:match("^weapon_[%w_]+$") then return nil,"Неверный класс в цене закупки." end
        if type(cost)~="number" or cost~=math.floor(cost) or cost<0 or cost>1000000000 then return nil,"Закупочная цена: целое от 0 до 1 000 000 000." end
        out.prices[class]=cost
    end
    return out
end
function RP.WholesalePrice(class)
    if type(class)~="string" then return nil end
    return RP.Workshop.prices and RP.Workshop.prices[class]
end
function RP.SaveWorkshop(config)
    local raw=util.TableToJSON(config,true)
    if not raw or #raw>45000 then return false,"Слишком большой конфиг." end
    local ok,err=pcall(function()
        file.CreateDir("vcity_rp")
        local old=file.Read(RP.WorkshopPath,"DATA")
        if old then file.Write("vcity_rp/workshop.previous.json",old);if file.Read("vcity_rp/workshop.previous.json","DATA")~=old then error("Backup failed") end end
        file.Write(RP.WorkshopPath,raw)
        if file.Read(RP.WorkshopPath,"DATA")~=raw then if old then file.Write(RP.WorkshopPath,old) end;error("Write failed") end
    end)
    return ok,ok and "" or tostring(err)
end
local existing=file.Read(RP.WorkshopPath,"DATA")
if existing then
    local config,err=RP.NormalizeWorkshop(util.JSONToTable(existing,false,true))
    if config then RP.Workshop=config else ErrorNoHalt("[V-City RP] Workshop file preserved; empty defaults active: "..tostring(err).."\n") end
else RP.SaveWorkshop(RP.Workshop) end
function RP.RespawnBenches()
    for _,entity in ipairs(RP.BenchEntities) do if IsValid(entity) then entity:Remove() end end
    RP.BenchEntities={}
    for _,point in ipairs(RP.Workshop.stations[game.GetMap()] or {}) do
        local pos=Vector(point.x,point.y,point.z)
        if util.IsInWorld(pos) then
            local entity=ents.Create("vcity_rp_bench")
            if IsValid(entity) then entity:SetPos(pos);entity:SetAngles(Angle(0,point.yaw,0));entity:Spawn();RP.BenchEntities[#RP.BenchEntities+1]=entity end
        end
    end
end
hook.Add("InitPostEntity","VCityRP.Benches",RP.RespawnBenches)
hook.Add("PostCleanupMap","VCityRP.Benches",function() timer.Simple(0,RP.RespawnBenches) end)
function RP.CanUseBench(ply,bench)
    if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() or IsValid(ply.FakeRagdoll) or ply:InVehicle() then return false end
    if not IsValid(bench) or bench:GetClass()~="vcity_rp_bench" or ply:GetPos():DistToSqr(bench:GetPos())>150*150 then return false end
    if not RP.GetRoleSettings(RP.GetRole(ply).ID).craftAccess then return false end
    local tr=util.TraceLine({start=ply:EyePos(),endpos=bench:WorldSpaceCenter(),filter=ply,mask=MASK_SOLID})
    return not tr.Hit or tr.Entity==bench
end
function RP.OpenBench(ply,bench)
    if not RP.CanUseBench(ply,bench) then
        ply:ChatPrint("Станок доступен роли «Оружейник»: подойди ближе или проверь роль.")
        return
    end
    if (ply.VCityRPNextBench or 0)>CurTime() then return end
    ply.VCityRPNextBench=CurTime()+0.3
    net.Start(RP.NetBenchOpen)
    if RP.WriteJSON({bench=bench:EntIndex(),recipes=RP.Workshop.recipes,cooldown=math.max((RP.CraftCooldowns[ply:SteamID64()] or 0)-CurTime(),0)}) then net.Send(ply) end
end
local function sendState(ply,session,kind,message)
    net.Start(RP.NetCraftState)
    local data={kind=kind or "state",message=message,serverTime=CurTime()}
    if session then
        for _,key in ipairs({"token","type","phase","total","startAt","deadline","pattern","inputAt","index","bits","target","moves","name","difficulty"}) do data[key]=session[key] end
    end
    if RP.WriteJSON(data) then net.Send(ply) end
end
function RP.StartCraft(ply,bench,id)
    if not RP.CanUseBench(ply,bench) then return false,"Станок доступен роли «Оружейник»: подойди ближе или проверь роль." end
    if RP.CraftSessions[ply] then return false,"У тебя уже идёт изготовление." end
    local recipe=RP.Workshop.recipes[id]
    if not recipe or not recipe.enabled then return false,"Рецепт выключен." end
    if not weapons.GetStored(recipe.class) and not ({weapon_pistol=true,weapon_smg1=true,weapon_crossbow=true})[recipe.class] then return false,"SWEP не установлен на сервере." end
    if ply:HasWeapon(recipe.class) then return false,"Такое оружие уже есть." end
    local steam=ply:SteamID64()
    if (RP.CraftCooldowns[steam] or 0)>CurTime() then return false,"Станок ещё на cooldown." end
    RP.CraftCooldowns[steam]=CurTime()+recipe.cooldown
    local s={token=math.random(1,2147483647),bench=bench,recipeID=id,type=recipe.kind,name=recipe.name,difficulty=recipe.difficulty,
        phase=1,total=recipe.difficulty+2,startAt=CurTime()+0.5,deadline=CurTime()+90,earliest=CurTime()+5,index=1,moves=0}
    if s.type=="automatic" then
        s.pattern={};for i=1,recipe.difficulty+4 do s.pattern[i]=math.random(1,4) end
        s.inputAt=s.startAt+#s.pattern*0.7+0.5;s.earliest=s.inputAt+0.15*#s.pattern
    elseif s.type=="rifle" then
        s.target={1,1,1,1,1,1};s.bits={1,1,1,1,1,1}
        -- Scramble a solved switch grid using legal moves: every puzzle is solvable.
        for i=1,recipe.difficulty+3 do
            local key=math.random(1,6)
            for _,j in ipairs({key,key%6+1,(key+4)%6+1}) do s.bits[j]=1-s.bits[j] end
        end
        if table.concat(s.bits)==table.concat(s.target) then s.bits[1]=0;s.bits[2]=0;s.bits[6]=0 end
    end
    RP.CraftSessions[ply]=s;sendState(ply,s,"start")
    return true
end
function RP.FinishCraft(ply,s)
    local recipe=RP.Workshop.recipes[s.recipeID]
    if not recipe or not recipe.enabled or not RP.CanUseBench(ply,s.bench) or ply:HasWeapon(recipe.class) then return false end
    RP.CraftSessions[ply]=nil -- consume before granting; replays cannot create another weapon
    local weapon=ply:Give(recipe.class,true)
    if not IsValid(weapon) then sendState(ply,nil,"end","Не удалось выдать SWEP.");return false end
    if weapon:GetMaxClip1()>0 then weapon:SetClip1(weapon:GetMaxClip1()) end
    if RP.ApplyWeaponAttachments and recipe.attachments and #recipe.attachments>0 then
        local applied,skipped=RP.ApplyWeaponAttachments(ply,weapon,recipe.attachments)
        if applied>0 then ply:ChatPrint("Обвесы установлены: "..applied) end
        if #skipped>0 then ply:ChatPrint("Не подошли: "..table.concat(skipped,", ")) end
    end
    if hg.RenewInv then hg.RenewInv(ply,false) end
    sendState(ply,nil,"complete","Готово: "..recipe.name);return true
end
function RP.CraftAction(ply,data)
    local s=RP.CraftSessions[ply]
    if not s or data.token~=s.token then return false end
    if data.action=="cancel" then RP.CraftSessions[ply]=nil;sendState(ply,nil,"end","Изготовление отменено.");return false end
    if CurTime()>s.deadline or not RP.CanUseBench(ply,s.bench) then RP.CraftSessions[ply]=nil;sendState(ply,nil,"end","Ты отошёл от станка.");return false end
    if (s.nextAction or 0)>CurTime() then return false end
    s.nextAction=CurTime()+0.12
    local solved=false
    if s.type=="pistol" then
        if data.action~="hit" or CurTime()<s.startAt then return false end
        local t=CurTime()-s.startAt-math.min((ply:Ping() or 0)/2000,0.08)
        local cursor=(math.sin(t*(1.6+s.difficulty*0.15))+1)/2
        local width=0.28-s.difficulty*0.025
        if math.abs(cursor-0.5)>width/2+0.045 then RP.CraftSessions[ply]=nil;sendState(ply,nil,"end","Промах. Попробуй после cooldown.");return false end
        s.phase=s.phase+1;s.startAt=CurTime()+0.3
        solved=s.phase>s.total
    elseif s.type=="automatic" then
        if data.action~="key" or CurTime()<s.inputAt or data.key~=s.pattern[s.index] then
            RP.CraftSessions[ply]=nil;sendState(ply,nil,"end","Последовательность нарушена.");return false
        end
        s.index=s.index+1;solved=s.index>#s.pattern
    elseif s.type=="rifle" then
        local key=data.key
        if data.action~="switch" or type(key)~="number" or key~=math.floor(key) or key<1 or key>6 or CurTime()<s.startAt then return false end
        for _,j in ipairs({key,key%6+1,(key+4)%6+1}) do s.bits[j]=1-s.bits[j] end
        s.moves=s.moves+1
        if s.moves>60 then RP.CraftSessions[ply]=nil;sendState(ply,nil,"end","Лимит переключений.");return false end
        solved=table.concat(s.bits)==table.concat(s.target)
    end
    if solved and CurTime()>=s.earliest then return RP.FinishCraft(ply,s) end
    if solved then s.waiting=true end
    sendState(ply,s);return true
end
net.Receive(RP.NetCraftStart,function(bits,ply)
    if not IsValid(ply) or not ply:IsPlayer() or bits>8192 or (ply.VCityRPNextCraftPacket or 0)>CurTime() then return end
    ply.VCityRPNextCraftPacket=CurTime()+0.3
    local d=RP.ReadJSON(bits);if not d or type(d.bench)~="number" then return end
    local ok,err=RP.StartCraft(ply,Entity(d.bench),d.recipe)
    if not ok then sendState(ply,nil,"end",err) end
end)
net.Receive(RP.NetCraftAction,function(bits,ply)
    if not IsValid(ply) or not ply:IsPlayer() or bits>4096 then return end
    if (ply.VCityRPNextCraftActionPacket or 0)>CurTime() then return end
    ply.VCityRPNextCraftActionPacket=CurTime()+0.08
    local d=RP.ReadJSON(bits);if d then RP.CraftAction(ply,d) end
end)
timer.Create("VCityRP.CraftWatch",0.25,0,function()
    for ply,s in pairs(RP.CraftSessions) do
        if not IsValid(ply) or not RP.CanUseBench(ply,s.bench) or CurTime()>s.deadline then
            RP.CraftSessions[ply]=nil;if IsValid(ply) then sendState(ply,nil,"end","Изготовление прервано.") end
        elseif s.waiting and CurTime()>=s.earliest then RP.FinishCraft(ply,s) end
    end
end)
net.Receive(RP.NetServices,function(bits,ply)
    if not RP.AdminGate(ply,bits,RP.MaxNetJSON*8+16,0.5,"services") then return end
    local d,err=RP.ReadJSON(bits);if not d then return end
    local response={kind="services"}
    if d.action=="save" then
        if d.revision~=RP.Workshop.revision then response={kind="error",message="Обнови мастерскую: другая ревизия."}
        else
            local config,message=RP.NormalizeWorkshop(d.config)
            if not config then response={kind="error",message=message}
            else
                local assets=true
                for _,recipe in pairs(config.recipes) do
                    if not weapons.GetStored(recipe.class) and not ({weapon_pistol=true,weapon_smg1=true,weapon_crossbow=true})[recipe.class] then assets=false;message="SWEP не найден: "..recipe.class;break end
                end
                if assets then
                    config.revision=RP.Workshop.revision+1
                    local ok,e=RP.SaveWorkshop(config)
                    if ok then RP.Workshop=config;RP.RespawnBenches() else response={kind="error",message=e} end
                else response={kind="error",message=message} end
            end
        end
    elseif d.action=="place" then
        local copy=table.Copy(RP.Workshop);local map=game.GetMap();copy.stations[map]=copy.stations[map] or {}
        if #copy.stations[map]>=16 then response={kind="error",message="На карте максимум 16 станков."}
        else
            local trace=ply:GetEyeTrace();local pos=trace.HitPos
            if not util.IsInWorld(pos) or ply:GetPos():DistToSqr(pos)>300*300 then response={kind="error",message="Посмотри на пол рядом с собой."}
            else
                copy.stations[map][#copy.stations[map]+1]={x=pos.x,y=pos.y,z=pos.z+3,yaw=ply:EyeAngles().y}
                copy.revision=copy.revision+1
                local ok,e=RP.SaveWorkshop(copy)
                if ok then RP.Workshop=copy;RP.RespawnBenches() else response={kind="error",message=e} end
            end
        end
    end
    if response.kind=="services" then response.config=RP.Workshop;response.revision=RP.Workshop.revision;response.map=game.GetMap() end
    net.Start(RP.NetServicesResult);if RP.WriteJSON(response) then net.Send(ply) end
end)
