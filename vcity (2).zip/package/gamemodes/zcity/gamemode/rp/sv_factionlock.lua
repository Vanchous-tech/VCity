-- V-City RP — ограничение смены военной фракции.
-- Новички: между сменами фракции 15 минут. Игроки, открывшие звание лейтенанта: раз в сутки.
-- Смена роли внутри своей фракции, переход в гражданские и обратно в ту же фракцию не ограничиваются.
-- Суперадмин не ограничен. Отметки хранятся в data/vcity_rp/factionlock.json по SteamID64.
local RP=VCityRP
RP.FactionSwitch={
    newbieSeconds=900,       -- 15 минут
    veteranSeconds=86400,    -- сутки
    veteranRoles={"rf_junior_lieutenant","drina_junior_lieutenant","delta_leader"}, -- открыта любая из них = «наигрался»
}
RP.FactionLockFile="vcity_rp/factionlock.json"
local store={}
do
    local raw=file.Read(RP.FactionLockFile,"DATA")
    -- ignoreConversions=true: store is keyed by SteamID64 strings
    local parsed=raw and raw~="" and util.JSONToTable(raw,false,true) or nil
    if istable(parsed) then store=parsed end
end
local function save()
    file.CreateDir("vcity_rp")
    file.Write(RP.FactionLockFile,util.TableToJSON(store,true))
end
local function military(faction) return RP.SubclassFactions and RP.SubclassFactions[faction]==true end
function RP.IsFactionVeteran(ply)
    for _,id in ipairs(RP.FactionSwitch.veteranRoles) do
        if RP.Roles[id] and RP.IsRoleUnlocked and RP.IsRoleUnlocked(ply,id) then return true end
    end
    return false
end
local function duration(seconds)
    seconds=math.ceil(seconds)
    if seconds>=3600 then return string.format("%d ч %02d мин",math.floor(seconds/3600),math.floor(seconds%3600/60)) end
    if seconds>=60 then return string.format("%d мин",math.ceil(seconds/60)) end
    return seconds.." с"
end
hook.Add("VCityRP.CanChooseRole","VCityRP.FactionLock",function(ply,newRole)
    if ply:IsSuperAdmin() or not newRole or not military(newRole.Faction) then return end
    local steam=ply:SteamID64()
    local rec=steam and store[steam]
    if not rec or rec.faction==newRole.Faction then return end
    local veteran=RP.IsFactionVeteran(ply)
    local wait=veteran and RP.FactionSwitch.veteranSeconds or RP.FactionSwitch.newbieSeconds
    local left=(tonumber(rec.at) or 0)+wait-os.time()
    if left>0 then
        return false,"Сменить фракцию можно через "..duration(left)..(veteran and " (для лейтенантов — раз в сутки)." or ".")
    end
end)
hook.Add("VCityRP.RoleChanged","VCityRP.FactionLock",function(ply,role)
    if not IsValid(ply) or ply:IsBot() or not role or not military(role.Faction) then return end
    local steam=ply:SteamID64()
    if not steam then return end
    local rec=store[steam]
    if rec and rec.faction==role.Faction then return end
    store[steam]={faction=role.Faction,at=os.time()}
    save()
end)
concommand.Add("vcity_rp_factionlock_reset",function(ply,_,args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local steam=args[1]
    if not steam then print("usage: vcity_rp_factionlock_reset <steam64>") return end
    store[steam]=nil;save()
    print("[V-City RP] Лимит смены фракции сброшен для "..steam)
end)
