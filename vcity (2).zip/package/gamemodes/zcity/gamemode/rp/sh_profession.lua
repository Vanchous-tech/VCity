-- UTF-8-safe cosmetic profession titles. This never grants a faction, gear or permissions.
local RP=VCityRP
RP.ProfessionNWKey="vcity_rp_profession"
RP.ProfessionMaxLength=32
RP.ProfessionChangeCooldown=2

-- Strict UTF-8 codepoint counter, independent of byte length and platform utf8 extensions.
-- Rejects malformed, overlong, surrogate and out-of-range sequences.
function RP.UTF8Length(value)
    if type(value)~="string" then return nil end
    local i,count=1,0
    while i<=#value do
        local first=value:byte(i)
        local width
        if first<128 then width=1
        elseif first>=194 and first<=223 then width=2
        elseif first>=224 and first<=239 then width=3
        elseif first>=240 and first<=244 then width=4
        else return nil end
        if i+width-1>#value then return nil end
        for offset=1,width-1 do
            local byte=value:byte(i+offset)
            if byte<128 or byte>191 then return nil end
        end
        local second=value:byte(i+1)
        if width==3 and ((first==224 and second<160) or (first==237 and second>159)) then return nil end
        if width==4 and ((first==240 and second<144) or (first==244 and second>143)) then return nil end
        count=count+1;i=i+width
    end
    return count
end
function RP.ValidateProfession(value)
    if type(value)~="string" or #value>512 then return nil,"Профессия: не больше 32 символов." end
    if value:find("[%z\1-\31\127]") then return nil,"Профессия должна быть одной строкой без управляющих символов." end
    -- Keep display order stable; reject invisible/bidi controls and Unicode line separators.
    for _,sequence in ipairs({"\194\173","\226\128\139","\226\128\140","\226\128\141","\226\128\142","\226\128\143",
        "\226\128\168","\226\128\169","\226\128\170","\226\128\171","\226\128\172","\226\128\173","\226\128\174",
        "\226\129\160","\226\129\166","\226\129\167","\226\129\168","\226\129\169","\239\187\191"}) do
        if value:find(sequence,1,true) then return nil,"Убери невидимые и управляющие символы из профессии." end
    end
    value=value:match("^%s*(.-)%s*$"):gsub(" +"," ")
    local length=RP.UTF8Length(value)
    if not length then return nil,"Некорректный UTF-8 в названии профессии." end
    if length==0 then return nil,"Использование: /rp Медик" end
    if length>RP.ProfessionMaxLength then return nil,"Профессия: не больше 32 символов (с пробелами)." end
    return value
end
-- Reads the role net var directly: RP.GetRole already calls this function, so
-- a second GetRole call here would recurse until the stack overflows.
local function factionOf(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return RP.DefaultRole end
    local id=ply:GetNW2String(RP.RoleNWKey,RP.DefaultRole)
    local base=RP.Roles[id]
    return base and base.Faction or RP.Roles[RP.DefaultRole].Faction
end
function RP.GetProfession(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return "" end
    if factionOf(ply)~=RP.CivilianFaction then return "" end
    local value=ply:GetNW2String(RP.ProfessionNWKey,"")
    if value=="" then return "" end
    return RP.ValidateProfession(value) or ""
end
