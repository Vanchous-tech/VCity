-- V-City RP 0.4.2 — SERVER ONLY. Подклассы военных званий (снайпер, штурмовик, …).
-- Подкласс накладывается на экипировку звания при спавне. Выбор применяется при следующем спавне.
-- Значения: data/vcity_rp/subclasses.json, ключ «фракция_подкласс». Неверные поля отбрасываются.
local RP = VCityRP

RP.SubclassFile = "vcity_rp/subclasses.json"
RP.SubclassOverrides = RP.SubclassOverrides or {}

util.AddNetworkString(RP.NetSubclass)
util.AddNetworkString(RP.NetSubResult)
for _, name in ipairs({ RP.NetSubAdminGet, RP.NetSubAdminSave, RP.NetSubAdminResult }) do util.AddNetworkString(name) end

local CLASS_PATTERN = "^[%w_]+$"
local WEAPON_PATTERN = "^weapon_[%w_]+$"

local function cleanList(src, limit, pattern)
    local out = {}
    if not istable(src) then return out end
    for _, value in ipairs(src) do
        if isstring(value) and #value <= 64 and string.match(value, pattern) then
            out[#out + 1] = value
            if #out >= limit then break end
        end
    end
    return out
end

-- Чистит одну запись подкласса: только известные поля и проверенные значения
function RP.CleanSubclassLoadout(src)
    local out = {}
    if not istable(src) then return out end

    if istable(src.weapons) then out.weapons = cleanList(src.weapons, 24, WEAPON_PATTERN) end
    if istable(src.armorItems) then out.armorItems = cleanList(src.armorItems, 24, CLASS_PATTERN) end
    if istable(src.attachments) then out.attachments = cleanList(src.attachments, 8, CLASS_PATTERN) end

    if istable(src.ammo) then
        local ammo = {}
        for name, amount in pairs(src.ammo) do
            local n = tonumber(amount)
            if isstring(name) and string.match(name, CLASS_PATTERN) and n and n >= 0 and n <= 999 then
                ammo[name] = math.floor(n)
            end
        end
        out.ammo = ammo
    end

    if isstring(src.model) and (src.model == "" or (#src.model <= 128 and string.match(src.model, "^models/[%w_/%.%-]+%.mdl$"))) then
        out.model = src.model
    end
    local skin = tonumber(src.skin)
    if skin and skin >= 0 and skin <= 32 and skin == math.floor(skin) then out.skin = skin end

    for _, key in ipairs({ "clearWeapons", "clearAmmo", "fillClips", "additive" }) do
        if isbool(src[key]) then out[key] = src[key] end
    end

    return out
end

local function LoadSubclasses()
    RP.SubclassOverrides = {}
    file.CreateDir("vcity_rp")
    local raw = file.Read(RP.SubclassFile, "DATA")
    if not raw or raw == "" then return end

    local parsed = util.JSONToTable(raw, false, true)
    if not istable(parsed) then
        print("[V-City RP] Ошибка чтения data/" .. RP.SubclassFile .. " — подклассы без переопределений.")
        return
    end

    for key, loadout in pairs(parsed) do
        local faction, sub = string.match(tostring(key), "^(%w+)_(%w+)$")
        if istable(loadout) and faction and RP.SubclassFactions[faction] and RP.SubclassByID(sub) then
            RP.SubclassOverrides[faction .. "_" .. sub] = RP.CleanSubclassLoadout(loadout)
        end
    end
end

-- Подкласс игрока (по его фракции) и его переопределения
function RP.SubclassOverrideFor(ply)
    if not IsValid(ply) then return nil end
    local sub = ply:GetNW2String(RP.SubNWKey, "")
    if sub == "" then return nil end
    local role = RP.GetRole(ply)
    if not RP.SubclassAllowed(role) then return nil end
    return RP.SubclassOverrides[role.Faction .. "_" .. sub]
end

-- Накладывает переопределения подкласса на копию конфига звания
-- additive = true: списки оружия, брони и обвесов и патроны ДОБАВЛЯЮТСЯ к экипировке звания,
-- остальные поля (модель, skin, флаги очистки) по-прежнему заменяются.
local MERGE_LISTS = { weapons = true, armorItems = true, attachments = true }
function RP.ApplySubclassLoadout(ply, cfg)
    local override = RP.SubclassOverrideFor(ply)
    if not override then return cfg end
    for key, value in pairs(override) do
        if key == "additive" then
            -- служебный флаг, в экипировку не копируется
        elseif override.additive and MERGE_LISTS[key] then
            local seen, merged = {}, {}
            for _, id in ipairs(cfg[key] or {}) do
                if not seen[id] then seen[id] = true merged[#merged + 1] = id end
            end
            for _, id in ipairs(value) do
                if not seen[id] then seen[id] = true merged[#merged + 1] = id end
            end
            cfg[key] = merged
        elseif override.additive and key == "ammo" then
            local merged = table.Copy(cfg.ammo or {})
            for name, amount in pairs(value) do merged[name] = (merged[name] or 0) + amount end
            cfg.ammo = merged
        else
            cfg[key] = table.Copy(value)
        end
    end
    return cfg
end

function RP.SetSubclass(ply, id)
    if not IsValid(ply) or not ply:IsPlayer() then return false, "Игрок не найден." end
    if id == "" then
        ply:SetNW2String(RP.SubNWKey, "")
        return true, "Подкласс снят. Применится при следующем спавне."
    end

    local sub = RP.SubclassByID(id)
    if not sub then return false, "Нет такого подкласса." end
    if not RP.SubclassAllowed(RP.GetRole(ply)) then return false, "Подклассы только у военных званий." end

    ply:SetNW2String(RP.SubNWKey, id)
    return true, "Подкласс: " .. sub.Name .. ". Применится при следующем спавне."
end

net.Receive(RP.NetSubclass, function(bits, ply)
    if not IsValid(ply) or not ply:IsPlayer() or bits > 512 then return end
    if (ply.VCityRPNextSub or 0) > CurTime() then return end
    ply.VCityRPNextSub = CurTime() + 0.25

    local id = net.ReadString()
    if #id > 40 then return end
    local ok, message = RP.SetSubclass(ply, id)
    net.Start(RP.NetSubResult)
    net.WriteBool(ok)
    net.WriteString(message or "")
    net.Send(ply)
end)

-- Смена фракции сбрасывает подкласс: он относится к фракции
hook.Add("VCityRP.RoleChanged", "VCityRP.SubclassReset", function(ply, role, previous)
    if not IsValid(ply) or not role then return end
    local sameFaction = previous and previous.Faction == role.Faction
    if not sameFaction or not RP.SubclassAllowed(role) then
        ply:SetNW2String(RP.SubNWKey, "")
    end
end)

LoadSubclasses()

-- ================= редактор подклассов (суперадмин) =================
-- Клиент: rp/cl_admin.lua (RP.OpenSubclassEditor, команда vcity_rp_subclass_editor).
-- Протокол:
--   NetSubAdminGet : string faction, string sub
--       -> NetSubAdminResult {kind="loaded", faction, sub, key, exists, loadout, ammoTypes}
--   NetSubAdminSave: JSON {faction, sub, loadout={…}}   сохранить переопределения подкласса
--                    JSON {faction, sub, reset=true}    убрать переопределения
--       -> NetSubAdminResult {kind="saved", …} (после проверки записи на диске) или {kind="error", message}
local function subReply(ply, data)
    net.Start(RP.NetSubAdminResult)
    if not RP.WriteJSON(data) then
        RP.WriteJSON({ kind = "error", message = "Ответ слишком большой для редактора." })
    end
    net.Send(ply)
end

local function subAmmoTypes()
    local out = {}
    for _, record in pairs(game.GetAmmoTypes() or {}) do
        local name = isstring(record) and record or (istable(record) and record.name)
        if isstring(name) and name ~= "" then out[#out + 1] = name end
    end
    table.sort(out)
    return out
end

local function subValidKey(faction, sub)
    if not isstring(faction) or not isstring(sub) then return nil end
    if not RP.SubclassFactions[faction] or not RP.SubclassByID(sub) then return nil end
    return faction .. "_" .. sub
end

local function subPayload(kind, faction, sub)
    local key = faction .. "_" .. sub
    local override = RP.SubclassOverrides[key]
    return { kind = kind, faction = faction, sub = sub, key = key, exists = override ~= nil,
        loadout = override and table.Copy(override) or {}, ammoTypes = subAmmoTypes() }
end

-- Пишет весь набор переопределений: файл-копия, запись, проверка чтением, откат при неудаче.
local function PersistSubclasses(overrides)
    local raw = util.TableToJSON(overrides, true)
    if not raw or #raw > 524288 then return false, "Файл подклассов слишком большой." end
    local ok, err = pcall(function()
        file.CreateDir("vcity_rp")
        local previous = file.Read(RP.SubclassFile, "DATA")
        if previous and previous ~= "" then
            file.Write("vcity_rp/subclasses.previous.json", previous)
            if file.Read("vcity_rp/subclasses.previous.json", "DATA") ~= previous then error("Не удалось сохранить резервную копию.", 0) end
        end
        file.Write(RP.SubclassFile, raw)
        if file.Read(RP.SubclassFile, "DATA") ~= raw then
            if previous then file.Write(RP.SubclassFile, previous) end
            error("Запись не подтверждена. Проверь права на DATA и свободное место.", 0)
        end
    end)
    if not ok then return false, tostring(err) end
    return true
end

net.Receive(RP.NetSubAdminGet, function(bits, ply)
    if not RP.AdminGate(ply, bits, 1024, 0.15, "subget") then return end
    local faction, sub = net.ReadString(), net.ReadString()
    if #faction > 24 or #sub > 24 or not subValidKey(faction, sub) then
        subReply(ply, { kind = "error", message = "Неизвестная фракция или подкласс." })
        return
    end
    subReply(ply, subPayload("loaded", faction, sub))
end)

net.Receive(RP.NetSubAdminSave, function(bits, ply)
    if not RP.AdminGate(ply, bits, RP.MaxNetJSON * 8 + 16, 0.5, "subsave") then return end
    local request, err = RP.ReadJSON(bits)
    if not request then subReply(ply, { kind = "error", message = err or "Некорректный запрос." }) return end
    local faction, sub = request.faction, request.sub
    local key = subValidKey(faction, sub)
    if not key then subReply(ply, { kind = "error", message = "Неизвестная фракция или подкласс." }) return end

    local nextOverrides = table.Copy(RP.SubclassOverrides)
    if request.reset == true then
        nextOverrides[key] = nil
    elseif istable(request.loadout) then
        local clean = RP.CleanSubclassLoadout(request.loadout)
        if next(clean) == nil then nextOverrides[key] = nil else nextOverrides[key] = clean end
    else
        subReply(ply, { kind = "error", message = "Нет данных экипировки." })
        return
    end

    local saved, message = PersistSubclasses(nextOverrides)
    if not saved then subReply(ply, { kind = "error", message = message }) return end
    RP.SubclassOverrides = nextOverrides
    if RP.Log and RP.Who then RP.Log("admin", RP.Who(ply) .. (request.reset == true and " сбросил подкласс " or " сохранил подкласс ") .. key) end
    subReply(ply, subPayload("saved", faction, sub))
end)

concommand.Add("vcity_rp_subclasses_reload", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    LoadSubclasses()
    print("[V-City RP] Подклассы перечитаны.")
end)
