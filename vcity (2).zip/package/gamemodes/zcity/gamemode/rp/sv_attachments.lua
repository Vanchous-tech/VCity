-- SERVER ONLY. Applies configured attachments through the addon's own hg.AddAttachmentForce.
local RP=VCityRP
function RP.ApplyWeaponAttachments(ply,weapon,ids)
    local applied,skipped=0,{}
    if not IsValid(weapon) or type(weapon.attachments)~="table" or type(weapon.availableAttachments)~="table" then
        for _,id in ipairs(ids or {}) do skipped[#skipped+1]=id end
        return applied,skipped
    end
    for _,id in ipairs(ids or {}) do
        local placement=RP.AttachmentPlacementOf(id)
        -- Guard the original helper: it indexes both tables without checking placement support.
        if not placement or weapon.attachments[placement]==nil or weapon.availableAttachments[placement]==nil then
            skipped[#skipped+1]=id
        else
            local ok=pcall(hg.AddAttachmentForce,ply,weapon,id)
            local entry=weapon.attachments[placement]
            if ok and type(entry)=="table" and entry[1]==id then applied=applied+1 else skipped[#skipped+1]=id end
        end
    end
    if applied>0 then pcall(function() weapon:SyncAtts() end) end
    return applied,skipped
end
function RP.ApplyAttachmentsToLoadout(ply,ids)
    if not IsValid(ply) or type(ids)~="table" or #ids==0 then return 0 end
    local total=0
    for _,weapon in ipairs(ply:GetWeapons()) do
        local applied=RP.ApplyWeaponAttachments(ply,weapon,ids)
        total=total+applied
    end
    return total
end
-- The admin editor receives a bounded preview of what actually exists on the server.
function RP.AttachmentOptionsJSON()
    local catalog=RP.AttachmentCatalog();local total=0
    for _,entry in pairs(catalog) do total=total+entry.count end
    return catalog,total
end
