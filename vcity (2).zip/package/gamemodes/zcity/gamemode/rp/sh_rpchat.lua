-- V-City RP 0.3.4 — roleplay chat: /me, /do, /try.
--
-- Why this file exists: the addon does ship these commands in
-- lua/homigrad/libraries/sh_rpchatcommands.lua, but that whole file is wrapped in
-- `if engine.ActiveGamemode() == "sandbox"`. On a zcity server the branch never runs, so
-- no roleplay command existed at all and the server rules could not be followed.
--
-- How the chat actually works here (lua/homigrad/zchat/sh_chat.lua):
--   net.Receive("zChatMessage") -> hook.Run("PlayerSay", ply, text) -- return value discarded
--   hook.Add("PlayerSay","ZChat") collects text into txtTbl, calls
--   hook.Run("HG_PlayerSay", ply, txtTbl, text), then broadcasts txtTbl[1] (and stops when it
--   is an empty string). HG_PlayerSay is therefore the supported place to rewrite or cancel a
--   chat line: the same hook also lets us stop /rp from leaking into public chat, because the
--   return value of a PlayerSay hook is thrown away by zChat.
local RP = VCityRP
RP.EmoteMaxLength = 160     -- codepoints, not bytes: «Привет» is 6
RP.EmoteCooldown = 1        -- seconds between two roleplay lines by the same player
RP.EmoteTryChance = 50      -- percent, /try
RP.EmoteRadiusDefault = 512 -- units, what /me and /do are visible at
RP.EmoteCommands = {["/me"] = true, ["/do"] = true, ["/try"] = true}
-- Black-and-orange UI, so /me uses the brand orange; /do stays neutral grey-blue like the
-- classic "(( ))" bracket; /try answers in green or red.
RP.EmoteColors = {
    me = {255, 128, 40},
    doLine = {176, 186, 198},
    tryOk = {126, 205, 126},
    tryFail = {224, 110, 96}
}

-- Returns command, argument or nil when the line is not a roleplay command.
function RP.ParseEmoteCommand(text)
    if type(text) ~= "string" then return nil end
    local command, tail = text:match("^%s*(/[%a]+)%s*(.*)$")
    if not command then return nil end
    command = command:lower()
    if not RP.EmoteCommands[command] then return nil end
    return command, (tail:match("^%s*(.-)%s*$"))
end

-- Rejects empty lines, control characters and anything longer than 160 codepoints.
function RP.SanitizeEmote(argument)
    if type(argument) ~= "string" then return nil, "Пустая реплика." end
    if argument:find("[%z\1-\31\127]") then return nil, "Реплика должна быть одной строкой." end
    argument = argument:match("^%s*(.-)%s*$")
    local length = RP.UTF8Length and RP.UTF8Length(argument)
    if not length or length == 0 then return nil, "Пустая реплика." end
    if length > RP.EmoteMaxLength then
        return nil, "Слишком длинная реплика: не больше " .. RP.EmoteMaxLength .. " символов."
    end
    return argument
end

-- Pure formatter: rgb table plus the final chat line. `roll` makes /try deterministic in tests.
function RP.FormatEmote(command, name, argument, roll)
    if type(name) ~= "string" or name == "" then name = "Игрок" end
    if type(argument) ~= "string" then argument = "" end
    if command == "/me" then
        return RP.EmoteColors.me, "* " .. name .. " " .. argument
    elseif command == "/do" then
        return RP.EmoteColors.doLine, "((" .. argument .. "))"
    elseif command == "/try" then
        if type(roll) ~= "number" then roll = math.random(1, 100) end
        local success = roll <= RP.EmoteTryChance
        return success and RP.EmoteColors.tryOk or RP.EmoteColors.tryFail,
            "* " .. name .. " пытается: " .. argument .. " — " .. (success and "удачно" or "неудачно")
    end
    return nil
end

if SERVER then
    local flags = FCVAR_ARCHIVE and {FCVAR_ARCHIVE} or {}
    local radiusConVar
    do
        local ok, result = pcall(CreateConVar, "vcity_rp_chatradius", tostring(RP.EmoteRadiusDefault), flags,
            "Радиус видимости /me и /do в юнитах", 64, 8192)
        if ok and result ~= nil then radiusConVar = result end
    end

    function RP.GetEmoteRadius()
        if not radiusConVar then return RP.EmoteRadiusDefault end
        local value = radiusConVar:GetFloat()
        if type(value) ~= "number" or value ~= value or value < 64 then return RP.EmoteRadiusDefault end
        return value
    end

    function RP.GetCharacterName(ply)
        if not IsValid(ply) then return "Игрок" end
        local name = ply.GetNWString and ply:GetNWString("PlayerName", nil) or nil
        if type(name) ~= "string" or name == "" then
            name = (ply.Nick and ply:Nick()) or nil
        end
        if type(name) ~= "string" or name == "" then name = "Игрок" end
        return name
    end

    -- Speaker plus everyone inside the radius: roleplay lines are local, not map-wide.
    -- Two filters are copied from the zChat broadcast loop so roleplay lines follow the same
    -- rules as normal chat: a muted player receives nothing, and a dead speaker cannot reach
    -- living players (the dead keep talking to the dead).
    function RP.GetEmoteRecipients(ply)
        local list = {}
        local origin = IsValid(ply) and ply:GetPos() or nil
        if not origin then return list end
        local radius = RP.GetEmoteRadius()
        local limit = radius * radius
        local speakerAlive = (ply.Alive and ply:Alive()) and true or false
        for _, target in ipairs(player.GetAll()) do
            if IsValid(target) then
                local position = target.GetPos and target:GetPos() or nil
                local inside = target == ply
                    or (position and origin.DistToSqr and origin:DistToSqr(position) <= limit)
                if inside then
                    local targetAlive = (target.Alive and target:Alive()) and true or false
                    local muted = targetAlive and target.organism and target.organism.otrub
                    local unreachable = targetAlive and not speakerAlive
                    if target == ply or (not muted and not unreachable) then
                        list[#list + 1] = target
                    end
                end
            end
        end
        return list
    end

    -- zChat prints raw coloured parts through zChatGlobalMessage (the addon itself calls
    -- zChatPrint with a Color object the same way). Without zChat the text still reaches the
    -- audience, just as a plain chat line.
    local function sendLine(list, rgb, message)
        local zchat = net and net.WriteTable and util and util.NetworkStringToID
            and util.NetworkStringToID("zChatGlobalMessage") or 0
        if zchat ~= 0 and zchat ~= nil then
            local filter = RecipientFilter and RecipientFilter() or nil
            if filter and filter.AddPlayer then
                for _, target in ipairs(list) do filter:AddPlayer(target) end
                net.Start("zChatGlobalMessage")
                net.WriteTable({Color(rgb[1], rgb[2], rgb[3]), message})
                net.Send(filter)
                return true
            end
        end
        local printed = false
        for _, target in ipairs(list) do
            if target.ChatPrint then
                target:ChatPrint(message)
                printed = true
            end
        end
        return printed
    end

    function RP.BroadcastEmote(ply, command, argument, roll)
        local rgb, message = RP.FormatEmote(command, RP.GetCharacterName(ply), argument, roll)
        if not rgb then return false end
        local list = RP.GetEmoteRecipients(ply)
        if #list == 0 then return false, "Рядом никого нет." end
        sendLine(list, rgb, message)
        hook.Run("VCityRP.Emote", ply, command, argument, message)
        return true, message
    end

    -- zChat reads txtTbl[1] right after HG_PlayerSay, so an empty string cancels the broadcast
    -- of the raw command while our own coloured line keeps the audience filter.
    local function cancelBroadcast(txtTbl)
        if type(txtTbl) == "table" then txtTbl[1] = "" end
    end

    -- One entry point for both ingest paths. zChat calls PlayerSay and HG_PlayerSay inside the
    -- same tick, so the (text, time) stamp keeps a single /me from being printed twice when
    -- someone swaps the chat resource.
    local function handleEmote(ply, text)
        local command, argument = RP.ParseEmoteCommand(text)
        if not command then return false end
        if not IsValid(ply) or not ply.IsPlayer or not ply:IsPlayer() then return true end
        if ply.VCityRPEmoteText == text and ply.VCityRPEmoteTime == CurTime() then return true end
        ply.VCityRPEmoteText, ply.VCityRPEmoteTime = text, CurTime()
        if (ply.VCityRPNextEmote or 0) > CurTime() then
            ply:ChatPrint("Подожди секунду перед следующей репликой.")
            return true
        end
        ply.VCityRPNextEmote = CurTime() + RP.EmoteCooldown
        local clean, reason = RP.SanitizeEmote(argument)
        if not clean then
            ply:ChatPrint("Использование: " .. command .. " <текст> — " .. reason)
            return true
        end
        RP.BroadcastEmote(ply, command, clean)
        return true
    end

    hook.Add("HG_PlayerSay", "VCityRP.RoleplayChat", function(ply, txtTbl, text)
        if not RP.Enabled or type(text) ~= "string" then return end
        local consumed = false
        -- /rp <профессия> lives in sv_profession.lua; consumed here as well so the raw command
        -- never reaches other players on the zChat ingress.
        if RP.HandleProfessionChat and RP.HandleProfessionChat(ply, text) then
            consumed = true
        elseif handleEmote(ply, text) then
            consumed = true
        end
        if consumed then cancelBroadcast(txtTbl) end
    end)

    -- Fallback for a plain say/say_team path, where the returned string replaces the message.
    hook.Add("PlayerSay", "VCityRP.RoleplayChat", function(ply, text)
        if not RP.Enabled or type(text) ~= "string" then return end
        if handleEmote(ply, text) then return "" end
        if RP.HandleProfessionChat and RP.HandleProfessionChat(ply, text) then return "" end
    end)
end
