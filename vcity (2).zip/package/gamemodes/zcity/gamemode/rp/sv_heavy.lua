-- V-City RP 0.6.0 — SERVER ONLY. Лимит тяжёлой техники: управлять ею (водитель и места с оружием)
-- могут только игроки с подклассом «Член экипажа» (F4). Обычным транспортом — все. Пассажиром
-- в тяжёлой технике (место без оружия) могут ехать все. Суперадмины проходят (vcity_rp_heavy_admin 1).
-- Тяжёлая техника определяется по:
--   * типу LVS-машины (GetVehicleType): tank, plane, helicopter … (heavy.json → types)
--   * подстрокам класса (heavy.json → classes), исключения — light (приоритет выше)
-- Конфиг: data/vcity_rp/heavy.json {"types":[…],"classes":[…],"light":[…]}
-- Команды (суперадмин, наведите прицел на машину или сядьте в неё):
--   vcity_rp_heavy_add · vcity_rp_heavy_remove (запись по классу) · vcity_rp_heavy_list · vcity_rp_heavy_reload
-- Проверка работает на трёх путях: вход (CanPlayerEnterVehicle), страховка после входа
-- (PlayerEnteredVehicle → выход) и пересадка на ходу LVS (LVS.OnPlayerRequestSeatSwitch).
local RP = VCityRP

RP.HeavyFile = "vcity_rp/heavy.json"
RP.HeavyDefaults = { types = { "tank", "plane", "heli", "gunship" }, classes = {}, light = {} }
RP.Heavy = table.Copy(RP.HeavyDefaults)

local cvAdmin = CreateConVar("vcity_rp_heavy_admin", "1", FCVAR_ARCHIVE, "Суперадмины могут управлять тяжёлой техникой без подкласса")
local cvOn = CreateConVar("vcity_rp_heavy", "1", FCVAR_ARCHIVE, "Включить лимит тяжёлой техники (1/0)")

local function cleanList(src)
    local out = {}
    if istable(src) then
        for _, v in ipairs(src) do
            if isstring(v) and #v >= 2 and #v <= 64 and #out < 200 then out[#out + 1] = string.lower(v) end
        end
    end
    return out
end

local function Load()
    RP.Heavy = table.Copy(RP.HeavyDefaults)
    local raw = file.Read(RP.HeavyFile, "DATA")
    if not raw or raw == "" then return end
    local parsed = util.JSONToTable(raw)
    if not istable(parsed) then print("[V-City RP] Ошибка чтения data/" .. RP.HeavyFile .. " — значения по умолчанию.") return end
    for _, k in ipairs({ "types", "classes", "light" }) do
        if parsed[k] ~= nil then RP.Heavy[k] = cleanList(parsed[k]) end
    end
end

local function Save()
    file.CreateDir("vcity_rp")
    file.Write(RP.HeavyFile, util.TableToJSON(RP.Heavy, true))
end

local function Has(list, text)
    text = string.lower(text or "")
    for _, p in ipairs(list) do
        if string.find(text, p, 1, true) then return true end
    end
    return false
end

-- Чистая логика (тестируется): тяжёлая ли машина по классу и типу
function RP.IsHeavyClass(cfg, class, vtype)
    if Has(cfg.light, class) then return false end
    if Has(cfg.classes, class) then return true end
    if isstring(vtype) and vtype ~= "" and Has(cfg.types, vtype) then return true end
    return false
end

-- Машина и признак «место управления»: водитель или место с оружием
local function SeatInfo(pod)
    if not IsValid(pod) then return end
    local host = pod:GetParent()
    if not IsValid(host) then host = pod end

    local vtype
    if host.GetVehicleType then
        local ok, v = pcall(host.GetVehicleType, host)
        if ok then vtype = v end
    end
    vtype = vtype or host.VehicleType

    local heavy = RP.IsHeavyClass(RP.Heavy, host:GetClass(), vtype)
    if not heavy then return host, false, false end

    local controls = true
    if host.GetDriverSeat then -- LVS
        local index = pod.lvsGetPodIndex and pod:lvsGetPodIndex() or 1
        local driver = host:GetDriverSeat()
        controls = (IsValid(driver) and driver == pod) or index == 1
        if not controls and istable(host.WEAPONS) and istable(host.WEAPONS[index]) and next(host.WEAPONS[index]) ~= nil then
            controls = true
        end
    elseif istable(host.seats) then -- Glide и подобные: первое место — водитель
        controls = host.seats[1] == pod
    end

    return host, true, controls
end

local function IsCrew(ply)
    if cvAdmin:GetBool() and ply:IsSuperAdmin() then return true end
    local role = RP.GetRole and RP.GetRole(ply)
    if not role or not (RP.SubclassAllowed and RP.SubclassAllowed(role)) then return false end
    return ply:GetNW2String(RP.SubNWKey, "") == "crew"
end

-- Можно ли игроку занять это место
local function CanSit(ply, pod)
    if not cvOn:GetBool() then return true end
    local host, heavy, controls = SeatInfo(pod)
    if not heavy or not controls then return true end
    if IsCrew(ply) then return true end
    return false, host
end

local function Deny(ply, host)
    if (ply.VCityRPHeavyNotify or 0) < CurTime() then
        ply.VCityRPHeavyNotify = CurTime() + 3
        ply:ChatPrint("Тяжёлой техникой управляют только члены экипажа: выберите подкласс «Член экипажа» (F4).")
        if RP.Log then RP.Log("heavy", RP.Who(ply) .. " отказано: " .. (IsValid(host) and host:GetClass() or "?")) end
    end
end

hook.Add("CanPlayerEnterVehicle", "VCityRP.HeavyEnter", function(ply, pod)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    local ok, host = CanSit(ply, pod)
    if ok then return end
    Deny(ply, host)
    return false
end)

-- страховка: вошёл другим путём (LVS сажает через EnterVehicle)
hook.Add("PlayerEnteredVehicle", "VCityRP.HeavyEntered", function(ply, pod)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    local ok, host = CanSit(ply, pod)
    if ok then return end
    Deny(ply, host)
    timer.Simple(0, function() if IsValid(ply) and ply:InVehicle() then ply:ExitVehicle() end end)
end)

-- пересадка на ходу в LVS (хук определён в LVS; false запрещает)
hook.Add("LVS.OnPlayerRequestSeatSwitch", "VCityRP.HeavySwitch", function(ply, vehicle, curPod, pod)
    if not IsValid(ply) or not IsValid(pod) then return end
    local ok, host = CanSit(ply, pod)
    if ok then return end
    Deny(ply, host)
    return false
end)

-- ================= админ =================
local function Say(ply, msg)
    if IsValid(ply) then ply:ChatPrint("[V-City RP] " .. msg) else print("[V-City RP] " .. msg) end
end

local function TargetClass(ply)
    if not IsValid(ply) then return end
    local ent
    if ply:InVehicle() then ent = ply:GetVehicle() else ent = ply:GetEyeTrace().Entity end
    if not IsValid(ent) then return end
    local parent = ent:GetParent()
    if IsValid(parent) then ent = parent end
    return ent:GetClass(), ent
end

local function Admin(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then Say(ply, "Только суперадмин.") return false end
    return true
end

local function Remove(list, value)
    for i = #list, 1, -1 do if list[i] == value then table.remove(list, i) end end
end

concommand.Add("vcity_rp_heavy_add", function(ply)
    if not Admin(ply) then return end
    local class = TargetClass(ply)
    if not class then return Say(ply, "Наведите прицел на машину или сядьте в неё.") end
    class = string.lower(class)
    Remove(RP.Heavy.light, class)
    if not table.HasValue(RP.Heavy.classes, class) then RP.Heavy.classes[#RP.Heavy.classes + 1] = class end
    Save()
    Say(ply, class .. " теперь ТЯЖЁЛАЯ (нужен подкласс «Член экипажа»).")
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " heavy+ " .. class) end
end)

concommand.Add("vcity_rp_heavy_remove", function(ply)
    if not Admin(ply) then return end
    local class = TargetClass(ply)
    if not class then return Say(ply, "Наведите прицел на машину или сядьте в неё.") end
    class = string.lower(class)
    Remove(RP.Heavy.classes, class)
    if not table.HasValue(RP.Heavy.light, class) then RP.Heavy.light[#RP.Heavy.light + 1] = class end
    Save()
    Say(ply, class .. " теперь ОБЫЧНАЯ (доступна всем), даже если её тип тяжёлый.")
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " heavy- " .. class) end
end)

concommand.Add("vcity_rp_heavy_list", function(ply)
    if not Admin(ply) then return end
    Say(ply, "Типы LVS: " .. table.concat(RP.Heavy.types, ", "))
    Say(ply, "Тяжёлые классы: " .. (#RP.Heavy.classes > 0 and table.concat(RP.Heavy.classes, ", ") or "—"))
    Say(ply, "Обычные (исключения): " .. (#RP.Heavy.light > 0 and table.concat(RP.Heavy.light, ", ") or "—"))
    local class, ent = TargetClass(ply)
    if class then
        local vtype = ent.GetVehicleType and ent:GetVehicleType() or ent.VehicleType
        Say(ply, class .. " (тип: " .. tostring(vtype) .. ") — " .. (RP.IsHeavyClass(RP.Heavy, class, vtype) and "ТЯЖЁЛАЯ" or "обычная"))
    end
end)

concommand.Add("vcity_rp_heavy_reload", function(ply)
    if not Admin(ply) then return end
    Load()
    Say(ply, "Конфиг тяжёлой техники перечитан.")
end)

Load()
