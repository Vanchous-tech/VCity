-- V-City RP 0.6.1 — SERVER ONLY. Спавнеры транспорта.
-- Спавнер = место на карте + класс машины. Машина появляется при старте сервера и после уничтожения
-- (или брошенности) возрождается через заданное время. Всё хранится в JSON и подгружается само:
--   data/vcity_rp/vehicles_<карта>.json
-- Поля спавнера: class, label, pos, yaw, delay (сек до возрождения после уничтожения),
--   abandon (сек: пустая машина дальше 300 юнитов от места возвращается; 0 = не возвращать),
--   side ("" все / usa / ru — кто может сесть), enabled, onstart (появиться при старте).
-- Меню (суперадмин): vcity_rp_veh_menu. Консоль: vcity_rp_veh_add <класс> [delay] [abandon] [название…],
--   _list · _remove <id> · _respawn <id> · _move <id> · _yaw <id> <градусы> · _set <id> <поле> <значение> · _reload
-- Конвары: vcity_rp_veh (1/0 весь модуль), vcity_rp_veh_wreck (сек до уборки обломков, 30),
--   vcity_rp_veh_clear (радиус свободного места для возрождения, 150).
local RP = VCityRP

RP.Spawners = RP.Spawners or {}
RP.SpawnerMax = 64
local cvOn = CreateConVar("vcity_rp_veh", "1", FCVAR_ARCHIVE, "Спавнеры транспорта (1/0)")
local cvWreck = CreateConVar("vcity_rp_veh_wreck", "30", FCVAR_ARCHIVE, "Секунд до уборки обломков уничтоженной машины")
local cvClear = CreateConVar("vcity_rp_veh_clear", "150", FCVAR_ARCHIVE, "Радиус, в котором не должно быть игроков при возрождении")

util.AddNetworkString("vcity_rp_veh_open")
util.AddNetworkString("vcity_rp_veh_act")

local runtime = {} -- [id] = { ent=, goneAt=, destroyedAt=, emptySince= }

local function File() return "vcity_rp/vehicles_" .. string.lower(game.GetMap()) .. ".json" end

-- ================= проверка данных (чистая логика, тестируется) =================
local CLASS_PATTERN = "^[%w_%.%-]+$"

function RP.CleanSpawner(src)
    if not istable(src) then return nil end
    local class = isstring(src.class) and src.class or nil
    if not class or #class > 64 or not string.match(class, CLASS_PATTERN) then return nil end
    local x, y, z = tonumber(src.x), tonumber(src.y), tonumber(src.z)
    if not x or not y or not z then return nil end

    local label = isstring(src.label) and string.sub(string.gsub(src.label, "[%c|]", ""), 1, 32) or ""
    local side = (src.side == "usa" or src.side == "ru") and src.side or ""

    return {
        class = class, label = label, x = x, y = y, z = z,
        yaw = math.NormalizeAngle and math.NormalizeAngle(tonumber(src.yaw) or 0) or (tonumber(src.yaw) or 0),
        delay = math.Clamp(math.floor(tonumber(src.delay) or 300), 5, 86400),
        abandon = math.Clamp(math.floor(tonumber(src.abandon) or 0), 0, 86400),
        side = side,
        enabled = src.enabled ~= false,
        onstart = src.onstart ~= false,
    }
end

-- ================= сохранение / загрузка =================
local function Save()
    file.CreateDir("vcity_rp")
    local out = {}
    for _, s in ipairs(RP.Spawners) do
        out[#out + 1] = { class = s.class, label = s.label, x = s.x, y = s.y, z = s.z, yaw = s.yaw,
            delay = s.delay, abandon = s.abandon, side = s.side, enabled = s.enabled, onstart = s.onstart }
    end
    local data = util.TableToJSON(out, true)
    local old = file.Read(File(), "DATA")
    if old and old ~= "" then file.Write("vcity_rp/vehicles_" .. string.lower(game.GetMap()) .. ".previous.json", old) end
    file.Write(File(), data)
end

local function Load()
    RP.Spawners = {}
    local raw = file.Read(File(), "DATA")
    local parsed = raw and raw ~= "" and util.JSONToTable(raw) or nil
    if not istable(parsed) then return end
    for _, src in ipairs(parsed) do
        if #RP.Spawners >= RP.SpawnerMax then break end
        local s = RP.CleanSpawner(src)
        if s then
            s.id = #RP.Spawners + 1
            RP.Spawners[#RP.Spawners + 1] = s
        end
    end
end

-- ================= спавн =================
local function ClassOK(class)
    if not isstring(class) or not string.match(class, CLASS_PATTERN) then return false end
    return scripted_ents.GetStored(class) ~= nil or list.Get("Vehicles")[class] ~= nil
end

local function PlayersNear(s)
    local pos, r = Vector(s.x, s.y, s.z), cvClear:GetFloat()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() and ply:GetPos():DistToSqr(pos) < r * r then return true end
    end
    return false
end

local function Destroyed(ent)
    if not IsValid(ent) then return true end
    if ent.GetDestroyed and ent:GetDestroyed() then return true end
    if ent.GetHP and ent.GetMaxHP then
        local ok, hp, max = pcall(function() return ent:GetHP(), ent:GetMaxHP() end)
        if ok and tonumber(max) and max > 0 and tonumber(hp) and hp <= 0 then return true end
    end
    return false
end

local function Occupied(ent)
    if not IsValid(ent) then return false end
    if ent.GetDriver and IsValid(ent:GetDriver()) then return true end
    if istable(ent.pSeats) then
        for _, pod in ipairs(ent.pSeats) do
            if IsValid(pod) and IsValid(pod:GetDriver()) then return true end
        end
    end
    local driverSeat = ent.GetDriverSeat and ent:GetDriverSeat()
    if IsValid(driverSeat) and IsValid(driverSeat:GetDriver()) then return true end
    for _, child in ipairs(ent:GetChildren() or {}) do
        if child.GetDriver and IsValid(child:GetDriver()) then return true end
    end
    return false
end

local function Remove(id)
    local rt = runtime[id]
    if rt and IsValid(rt.ent) then rt.ent:Remove() end
end

local function Spawn(s)
    if not ClassOK(s.class) then
        if RP.Log and not s.missingLogged then RP.Log("vehicle", "класс не найден: " .. s.class .. " (спавнер #" .. s.id .. "), повтор раз в минуту") end
        s.missingLogged = true
        return false
    end
    s.missingLogged = nil
    local ent = ents.Create(s.class)
    if not IsValid(ent) then return false end
    ent:SetPos(Vector(s.x, s.y, s.z + 12))
    ent:SetAngles(Angle(0, s.yaw, 0))
    ent:Spawn()
    ent:Activate()
    ent.VCitySpawnerID = s.id
    ent.VCitySpawnerSide = s.side
    runtime[s.id] = { ent = ent, spawnedAt = CurTime() }
    if RP.Log then RP.Log("vehicle", "возрождён «" .. (s.label ~= "" and s.label or s.class) .. "» (спавнер #" .. s.id .. ")") end
    return true
end

function RP.RespawnSpawner(id, force)
    local s = RP.Spawners[id]
    if not s then return false end
    if force then Remove(id) end
    runtime[id] = nil
    return Spawn(s)
end

-- Периодическая проверка: уничтожена / исчезла / брошена
timer.Create("VCityRP.Vehicles", 2, 0, function()
    if not cvOn:GetBool() then return end
    local now = CurTime()

    for _, s in ipairs(RP.Spawners) do
        local rt = runtime[s.id]
        if not s.enabled then
            if rt and IsValid(rt.ent) then rt.ent:Remove() end
            runtime[s.id] = nil
        elseif not rt then
            -- ещё не появлялась (после старта или перезагрузки конфига)
            if (s.onstart or RP.VehiclesStarted) and now >= (s.retryAt or 0) then
                if not PlayersNear(s) and not Spawn(s) then s.retryAt = now + 60 end
            end
        elseif IsValid(rt.ent) then
            if Destroyed(rt.ent) then
                rt.destroyedAt = rt.destroyedAt or now
                if now - rt.destroyedAt >= math.min(cvWreck:GetFloat(), s.delay) then
                    rt.ent:Remove()
                end
            elseif s.abandon > 0 then
                local away = rt.ent:GetPos():DistToSqr(Vector(s.x, s.y, s.z)) > 300 * 300
                if away and not Occupied(rt.ent) then
                    rt.emptySince = rt.emptySince or now
                    if now - rt.emptySince >= s.abandon then
                        if RP.Log then RP.Log("vehicle", "брошена, возвращена на место: " .. s.class .. " (#" .. s.id .. ")") end
                        rt.returned = true
                        rt.ent:Remove()
                    end
                else
                    rt.emptySince = nil
                end
            end
        else
            -- машины нет: ждём delay от момента уничтожения/удаления, потом возрождаем
            rt.goneAt = rt.goneAt or (rt.returned and (now - s.delay + 10)) or rt.destroyedAt or now
            if now - rt.goneAt >= s.delay and not PlayersNear(s) then
                runtime[s.id] = nil
                Spawn(s)
            end
        end
    end
end)

-- старт: даём LVS и остальным аддонам загрузиться
hook.Add("InitPostEntity", "VCityRP.VehiclesStart", function()
    timer.Simple(6, function() RP.VehiclesStarted = true end)
end)
hook.Add("PostCleanupMap", "VCityRP.VehiclesCleanup", function()
    runtime = {}
end)

-- ограничение «кто может сесть»
hook.Add("CanPlayerEnterVehicle", "VCityRP.VehicleSide", function(ply, pod)
    if not IsValid(ply) or not IsValid(pod) then return end
    local host = pod:GetParent()
    if not IsValid(host) or not host.VCitySpawnerSide then host = pod end
    local side = host.VCitySpawnerSide
    if not side or side == "" then return end
    if ply:IsSuperAdmin() then return end
    if RP.SideOfPlayer and RP.SideOfPlayer(ply) == side then return end
    if (ply.VCityRPVehNotify or 0) < CurTime() then
        ply.VCityRPVehNotify = CurTime() + 3
        ply:ChatPrint("Эта техника закреплена за другой стороной.")
    end
    return false
end)

-- ================= админ-действия =================
local function Say(ply, msg)
    if IsValid(ply) then ply:ChatPrint("[V-City RP] " .. msg) else print("[V-City RP] " .. msg) end
end
local function Admin(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then Say(ply, "Только суперадмин.") return false end
    return true
end

local function AimPos(ply)
    local tr = util.TraceLine({ start = ply:EyePos(), endpos = ply:EyePos() + ply:GetAimVector() * 20000, filter = ply, mask = MASK_SOLID_BRUSHONLY })
    if tr.Hit then return tr.HitPos end
end

function RP.AddSpawner(ply, data)
    if #RP.Spawners >= RP.SpawnerMax then return false, "Лимит спавнеров: " .. RP.SpawnerMax end
    local pos = AimPos(ply)
    if not pos then return false, "Наведите прицел на землю." end
    data.x, data.y, data.z = pos.x, pos.y, pos.z
    data.yaw = ply:EyeAngles().y
    local s = RP.CleanSpawner(data)
    if not s then return false, "Некорректные данные (класс?)." end
    if not ClassOK(s.class) then return false, "Класс «" .. s.class .. "» не найден на сервере." end
    s.id = #RP.Spawners + 1
    RP.Spawners[s.id] = s
    Save()
    Spawn(s)
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " спавнер #" .. s.id .. " " .. s.class) end
    return true, "Спавнер #" .. s.id .. " создан: " .. (s.label ~= "" and s.label or s.class)
end

local EDIT_FIELDS = { label = "string", delay = "number", abandon = "number", side = "string", enabled = "bool", onstart = "bool", yaw = "number" }

function RP.EditSpawner(id, field, value)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    local kind = EDIT_FIELDS[field]
    if not kind then return false, "Поле: label, delay, abandon, side, enabled, onstart, yaw" end
    local data = {}
    for k, v in pairs(s) do data[k] = v end
    if kind == "bool" then
        data[field] = (value == true or value == "1" or value == "true" or value == "on")
    else
        data[field] = value
    end
    local clean = RP.CleanSpawner(data)
    if not clean then return false, "Некорректное значение." end
    for k, v in pairs(clean) do s[k] = v end
    local rt = runtime[id]
    if rt and IsValid(rt.ent) then rt.ent.VCitySpawnerSide = s.side end
    Save()
    return true, "Спавнер #" .. id .. ": " .. field .. " = " .. tostring(s[field])
end

function RP.RemoveSpawner(id)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    Remove(id)
    table.remove(RP.Spawners, id)
    -- перенумерация вместе с рантаймом
    local newRuntime = {}
    for i, sp in ipairs(RP.Spawners) do
        local old = sp.id
        sp.id = i
        newRuntime[i] = runtime[old]
        if newRuntime[i] and IsValid(newRuntime[i].ent) then newRuntime[i].ent.VCitySpawnerID = i end
    end
    runtime = newRuntime
    Save()
    return true, "Спавнер удалён."
end

function RP.MoveSpawner(ply, id)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    local pos = AimPos(ply)
    if not pos then return false, "Наведите прицел на землю." end
    s.x, s.y, s.z, s.yaw = pos.x, pos.y, pos.z, math.NormalizeAngle(ply:EyeAngles().y)
    Save()
    RP.RespawnSpawner(id, true)
    return true, "Спавнер #" .. id .. " перенесён, машина возрождена."
end

-- ---- меню ----
local function Payload()
    local list = {}
    for _, s in ipairs(RP.Spawners) do
        local rt = runtime[s.id]
        local state = "ждёт"
        if rt and IsValid(rt.ent) then state = Destroyed(rt.ent) and "уничтожена" or (Occupied(rt.ent) and "в деле" or "на месте") end
        list[#list + 1] = { id = s.id, class = s.class, label = s.label, delay = s.delay, abandon = s.abandon,
            side = s.side, enabled = s.enabled, onstart = s.onstart, state = state }
    end
    return { spawners = list }
end

local function OpenMenu(ply)
    net.Start("vcity_rp_veh_open")
    RP.WriteJSON(Payload())
    net.Send(ply)
end

net.Receive("vcity_rp_veh_act", function(bits, ply)
    if not RP.AdminGate(ply, bits, 20000, 0.2, "veh") then return end
    local act = net.ReadString()
    if #act > 16 then return end
    local data = RP.ReadJSON(nil) or {}

    local ok, msg
    if act == "add" then
        ok, msg = RP.AddSpawner(ply, { class = data.class, label = data.label, delay = data.delay, abandon = data.abandon, side = data.side })
    elseif act == "remove" then
        ok, msg = RP.RemoveSpawner(tonumber(data.id) or 0)
    elseif act == "respawn" then
        ok = RP.RespawnSpawner(tonumber(data.id) or 0, true)
        msg = ok and "Возрождено." or "Не удалось (класс?)."
    elseif act == "move" then
        ok, msg = RP.MoveSpawner(ply, tonumber(data.id) or 0)
    elseif act == "update" then
        -- несколько полей за один запрос (меню): delay, abandon, label, side
        local id = tonumber(data.id) or 0
        ok, msg = true, "Спавнер #" .. id .. " обновлён."
        for _, f in ipairs({ "delay", "abandon", "label", "side" }) do
            if data[f] ~= nil then
                local fine, m = RP.EditSpawner(id, f, data[f])
                if not fine then ok, msg = false, m break end
            end
        end
    elseif act == "set" then
        ok, msg = RP.EditSpawner(tonumber(data.id) or 0, tostring(data.field), data.value)
    end
    if msg then Say(ply, msg) end
    OpenMenu(ply)
end)

concommand.Add("vcity_rp_veh_menu", function(ply)
    if IsValid(ply) and ply:IsSuperAdmin() then OpenMenu(ply) end
end)

concommand.Add("vcity_rp_veh_add", function(ply, _, args)
    if not Admin(ply) or not IsValid(ply) then return end
    local class = args[1]
    if not class then return Say(ply, "usage: vcity_rp_veh_add <класс> [delay] [abandon] [название…] (смотрите на место). Список: vcity_rp_veh_classes") end
    local label = {}
    for i = 4, #args do label[#label + 1] = args[i] end
    local _, msg = RP.AddSpawner(ply, { class = class, delay = args[2], abandon = args[3], label = table.concat(label, " ") })
    Say(ply, msg)
end)

concommand.Add("vcity_rp_veh_classes", function(ply, _, args)
    if not Admin(ply) then return end
    local filter = string.lower(args[1] or "")
    local out = {}
    for class, ent in pairs(scripted_ents.GetList()) do
        local t = ent.t or ent
        if (t.Spawnable or string.StartWith(class, "lvs_") or string.StartWith(class, "glide")) and (filter == "" or string.find(string.lower(class), filter, 1, true)) then
            out[#out + 1] = class
        end
    end
    table.sort(out)
    Say(ply, #out .. " классов" .. (filter ~= "" and (" по «" .. filter .. "»") or "") .. " (показаны первые 60):")
    for i = 1, math.min(#out, 60) do Say(ply, out[i]) end
end)

concommand.Add("vcity_rp_veh_list", function(ply)
    if not Admin(ply) then return end
    if #RP.Spawners == 0 then return Say(ply, "Спавнеров нет. Откройте vcity_rp_veh_menu.") end
    for _, s in ipairs(Payload().spawners) do
        Say(ply, string.format("#%d %s [%s] delay=%d abandon=%d side=%s %s — %s", s.id, s.label ~= "" and s.label or "-", s.class, s.delay, s.abandon, s.side ~= "" and s.side or "все", s.enabled and "" or "(выкл)", s.state))
    end
end)

concommand.Add("vcity_rp_veh_remove", function(ply, _, args) if Admin(ply) then local _, m = RP.RemoveSpawner(tonumber(args[1]) or 0) Say(ply, m) end end)
concommand.Add("vcity_rp_veh_respawn", function(ply, _, args)
    if Admin(ply) then Say(ply, RP.RespawnSpawner(tonumber(args[1]) or 0, true) and "Возрождено." or "Не удалось.") end
end)
concommand.Add("vcity_rp_veh_move", function(ply, _, args)
    if Admin(ply) and IsValid(ply) then local _, m = RP.MoveSpawner(ply, tonumber(args[1]) or 0) Say(ply, m) end
end)
concommand.Add("vcity_rp_veh_yaw", function(ply, _, args)
    if Admin(ply) then
        local id = tonumber(args[1]) or 0
        local _, m = RP.EditSpawner(id, "yaw", args[2])
        RP.RespawnSpawner(id, true)
        Say(ply, m)
    end
end)
concommand.Add("vcity_rp_veh_set", function(ply, _, args)
    if Admin(ply) then local _, m = RP.EditSpawner(tonumber(args[1]) or 0, tostring(args[2]), args[3]) Say(ply, m) end
end)
concommand.Add("vcity_rp_veh_reload", function(ply)
    if not Admin(ply) then return end
    for id in pairs(runtime) do Remove(id) end
    runtime = {}
    Load()
    Say(ply, "Спавнеров загружено: " .. #RP.Spawners)
end)

Load()
print("[V-City RP] Спавнеры транспорта: " .. #RP.Spawners)
