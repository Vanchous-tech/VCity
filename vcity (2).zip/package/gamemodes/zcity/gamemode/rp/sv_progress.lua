-- V-City RP 0.4.1 — SERVER ONLY. Отыгранные минуты по ролям и цепочка открытия ролей.
-- Прогресс хранится по SteamID64 в data/vcity_rp/progress.json и переживает рестарт и смену карты.
-- Считается время жизни в роли (игрок жив, не бот); переключение роли не сбрасывает накопленное.
local RP = VCityRP

RP.ProgressFile = "vcity_rp/progress.json"
RP.UnlockFile = "vcity_rp/unlocks.json"
RP.ProgressTick = 10 -- секунд между начислениями
RP.ProgressStore = RP.ProgressStore or {} -- [steam64][roleId] = секунды
RP.ProgressDirty = false
RP.ProgressSaveEvery = 60 -- не чаще раза в минуту пишем на диск
local nextSave = 0

-- Серверный файл с правилами (тот же формат, что RP.DefaultUnlockRules)
local function LoadUnlockRules()
    RP.Unlocks = table.Copy(RP.DefaultUnlockRules)
    local raw = file.Read(RP.UnlockFile, "DATA")
    if not raw or raw == "" then return end

    local parsed = util.JSONToTable(raw)
    if not istable(parsed) then
        print("[V-City RP] Ошибка чтения data/" .. RP.UnlockFile .. " — используются правила по умолчанию.")
        return
    end

    local clean = {}
    for id, rule in pairs(parsed) do
        local minutes = istable(rule) and tonumber(rule.minutes)
        local after = istable(rule) and rule.after
        if RP.Roles[id] and isstring(after) and RP.Roles[after] and minutes and minutes >= 0 then
            clean[id] = { after = after, minutes = math.floor(minutes) }
        end
    end
    RP.Unlocks = clean
end

local function LoadProgress()
    file.CreateDir("vcity_rp")
    local raw = file.Read(RP.ProgressFile, "DATA")
    -- ignoreConversions=true: ProgressStore is keyed by SteamID64 strings
    local parsed = raw and raw ~= "" and util.JSONToTable(raw, false, true) or nil
    RP.ProgressStore = istable(parsed) and parsed or {}
end

function RP.SaveProgress()
    file.CreateDir("vcity_rp")
    file.Write(RP.ProgressFile, util.TableToJSON(RP.ProgressStore, true))
    RP.ProgressDirty = false
end

local function Store(steam)
    local s = RP.ProgressStore[steam]
    if not istable(s) then
        s = {}
        RP.ProgressStore[steam] = s
    end
    return s
end

-- Начислить секунды прогресса на роль (разведка, ремонт и т.п.). Ничего не делает для ботов.
function RP.AddRoleSeconds(ply, id, seconds)
    if not IsValid(ply) or ply:IsBot() or not ply.SteamID64 or not RP.Roles[id] then return false end
    local steam = ply:SteamID64()
    if not steam or not (tonumber(seconds) and seconds > 0) then return false end
    local s = Store(steam)
    s[id] = (tonumber(s[id]) or 0) + math.floor(seconds)
    RP.ProgressDirty = true
    return true
end

function RP.RoleSeconds(ply, id)
    if not IsValid(ply) or not ply.SteamID64 then return 0 end
    local steam = ply:SteamID64()
    local s = steam and RP.ProgressStore[steam]
    return istable(s) and tonumber(s[id]) or 0
end

-- Роль открыта, если открыта её предыдущая в цепочке и на ней отыграно нужное время
function RP.IsRoleUnlocked(ply, id, depth)
    depth = (depth or 0) + 1
    if depth > 30 then return false end -- защита от зацикленной цепочки в JSON

    local rule = RP.Unlocks[id]
    if not rule then return true end
    if not RP.IsRoleUnlocked(ply, rule.after, depth) then return false end

    return RP.RoleSeconds(ply, rule.after) >= rule.minutes * 60
end

-- Сообщение для отказа сервера: какую роль надо отыграть
function RP.LockReason(ply, id)
    local rule = RP.Unlocks[id]
    if not rule or RP.IsRoleUnlocked(ply, id) then return nil end

    if not RP.IsRoleUnlocked(ply, rule.after) then
        local prev = RP.Roles[rule.after]
        return "Сначала открой «" .. (prev and prev.Name or rule.after) .. "»."
    end

    local done = math.floor(RP.RoleSeconds(ply, rule.after) / 60)
    return RP.LockMessage(rule.after, math.min(done, rule.minutes), rule.minutes)
end

-- Строка для NW2: «роль|предыдущая|минуты_сделано|минуты_нужно;…» только для закрытых ролей
local function BuildLockString(ply)
    local parts = {}
    for _, id in ipairs(RP.RoleOrder or {}) do
        local rule = RP.Unlocks[id]
        if rule and not RP.IsRoleUnlocked(ply, id) then
            local done = math.floor(RP.RoleSeconds(ply, rule.after) / 60)
            parts[#parts + 1] = id .. "|" .. rule.after .. "|" .. math.min(done, rule.minutes) .. "|" .. rule.minutes
        end
    end
    return table.concat(parts, ";")
end

local function Tick()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and not ply:IsBot() and ply:Alive() and ply.SteamID64 and ply:SteamID64() then
            local id = RP.GetRole(ply).ID
            local s = Store(ply:SteamID64())
            s[id] = (tonumber(s[id]) or 0) + RP.ProgressTick
            RP.ProgressDirty = true
        end
        if IsValid(ply) then
            local str = BuildLockString(ply)
            if ply:GetNW2String(RP.LockNWKey, "") ~= str then
                ply:SetNW2String(RP.LockNWKey, str)
            end
        end
    end

    if RP.ProgressDirty and CurTime() >= nextSave then
        nextSave = CurTime() + RP.ProgressSaveEvery
        RP.SaveProgress()
    end
end

LoadUnlockRules()
LoadProgress()
timer.Create("VCityRP.Progress", RP.ProgressTick, 0, Tick)

hook.Add("PlayerDisconnected", "VCityRP.ProgressSave", function()
    if RP.ProgressDirty then RP.SaveProgress() end
end)
hook.Add("ShutDown", "VCityRP.ProgressShutdown", function()
    if RP.ProgressDirty then RP.SaveProgress() end
end)

concommand.Add("vcity_rp_unlocks_reload", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    LoadUnlockRules()
    print("[V-City RP] Правила открытия ролей перечитаны: " .. table.Count(RP.Unlocks) .. " шт.")
end)

-- superadmin: сбросить или выставить минуты роли игроку по SteamID64
-- vcity_rp_progress_set <steam64> <roleId> <minutes>
concommand.Add("vcity_rp_progress_set", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local steam, id, minutes = args[1], args[2], tonumber(args[3])
    if not steam or not RP.Roles[id or ""] or not minutes or minutes < 0 then
        print("usage: vcity_rp_progress_set <steam64> <roleId> <minutes>")
        return
    end
    Store(steam)[id] = math.floor(minutes * 60)
    RP.ProgressDirty = true
    RP.SaveProgress()
    print("[V-City RP] " .. steam .. " / " .. id .. " = " .. math.floor(minutes) .. " мин")
end)
