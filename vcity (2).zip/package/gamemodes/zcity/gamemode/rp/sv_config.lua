-- SERVER ONLY. Persistent JSON, schema validation and superadmin-only editor RPC.
local RP=VCityRP
local MAX_FILE=524288
local function bad(message) error(message,0) end
local function finite(n) return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge end
local function number(value,default,min,max,label,integer)
    if value==nil then value=default end
    if not finite(value) or value<min or value>max or (integer and value~=math.floor(value)) then bad(label..": недопустимое число.") end
    return value
end
local function text(value,default,max,label)
    if value==nil then value=default end
    if type(value)~="string" or #value>max or value:find("[%z\1-\31]") then bad(label..": недопустимая строка.") end
    return value
end
local function boolean(value,default,label)
    if value==nil then return default end
    if type(value)~="boolean" then bad(label..": нужно true/false.") end
    return value
end
local function list(value,limit,label,convert)
    value=value or {}
    if type(value)~="table" then bad(label..": нужен массив.") end
    local count=0
    for k in pairs(value) do
        if type(k)~="number" or k<1 or k~=math.floor(k) then bad(label..": нужен массив без пропусков.") end
        count=count+1
    end
    if count>limit then bad(label..": слишком много элементов.") end
    local out,seen={},{}
    for i=1,count do
        if value[i]==nil then bad(label..": пропуск в массиве.") end
        local item=convert(value[i])
        if not seen[item] then out[#out+1]=item;seen[item]=true end
    end
    return out
end
local roleFields={faction=true,sortOrder=true,salary=true,craftAccess=true,tradeAccess=true,attachments=true,name=true,enabled=true,model=true,skin=true,bodygroups=true,health=true,armor=true,
    armorItems=true,weapons=true,ammo=true,clearWeapons=true,clearAmmo=true,fillClips=true,
    walkSpeed=true,runSpeed=true,jumpPower=true,allowedGroups=true,maxPlayers=true,spawns=true}
local function normalizeRole(id,input)
    if type(id)~="string" or #id>40 or not id:match("^[a-z][a-z0-9_]*$") or type(input)~="table" then bad("Неизвестная роль или неверные настройки.") end
    for k in pairs(input) do if not roleFields[k] then bad("Неизвестное поле роли: "..tostring(k)) end end
    local base=RP.BaseRoles[id] or RP.Roles[id]
    local d=base and RP.DefaultRoleConfig(id) or {name="Новая роль"}
    local out={}
    out.faction=text(input.faction,base and base.Faction or "",24,"Фракция")
    if (id==RP.DefaultRole and out.faction~="civilian") or (id~=RP.DefaultRole and not RP.FactionsByID[out.faction]) then bad("Неверная фракция.") end
    out.sortOrder=number(input.sortOrder,base and base.SortOrder or 100,0,10000,"Порядок",true)
    out.salary=number(input.salary,200,0,100000,"Зарплата",true)
    out.craftAccess=boolean(input.craftAccess,d.craftAccess or false,"Доступ к станку")
    out.tradeAccess=boolean(input.tradeAccess,d.tradeAccess or false,"Право продажи оружия")
    out.attachments=list(input.attachments,8,"Обвесы",function(v)
        v=text(v,"",48,"Обвес")
        if not v:match("^[%a_][%w_]*$") then bad("Неверный ID обвеса: "..v) end
        if hg and type(hg.attachments)=="table" and not RP.AttachmentPlacementOf(v) then bad("Неизвестный обвес: "..v) end
        return v
    end)
    out.name=text(input.name,d.name,100,"Название")
    if out.name=="" then bad("Название не должно быть пустым.") end
    out.enabled=boolean(input.enabled,true,"enabled")
    out.model=text(input.model,"",200,"Модель")
    if out.model~="" and (out.model:sub(1,7)~="models/" or out.model:sub(-4)~=".mdl" or out.model:find("..",1,true) or not out.model:match("^[%w_/%-%. ]+$")) then bad("Нужен путь models/... .mdl без ..") end
    out.skin=number(input.skin,0,0,255,"skin",true)
    out.health=number(input.health,100,1,500,"Здоровье",true)
    out.armor=number(input.armor,0,0,500,"Броня",true)
    out.walkSpeed=number(input.walkSpeed,100,0,500,"Скорость ходьбы",false)
    out.runSpeed=number(input.runSpeed,350,0,1000,"Скорость бега",false)
    out.jumpPower=number(input.jumpPower,200,0,600,"Прыжок",false)
    out.maxPlayers=number(input.maxPlayers,0,0,256,"Лимит мест",true)
    for _,key in ipairs({"clearWeapons","clearAmmo","fillClips"}) do out[key]=boolean(input[key],true,key) end
    out.weapons=list(input.weapons,24,"Оружие",function(v)
        v=text(v,"",64,"Класс оружия")
        if not v:match("^[a-z][a-z0-9_]*$") or (v:sub(1,7)~="weapon_" and v~="gmod_tool" and v~="gmod_camera") then bad("Неверный класс оружия: "..v) end
        return v
    end)
    out.armorItems=list(input.armorItems,24,"Предметы брони",function(v)
        v=text(v,"",64,"Предмет брони"):gsub("^ent_armor_","")
        if not v:match("^[a-z][a-z0-9_]*$") then bad("Неверный ID брони.") end
        return v
    end)
    out.allowedGroups=list(input.allowedGroups,24,"Группы доступа",function(v)
        v=text(v,"",64,"Группа")
        if v=="" then bad("Пустая группа.") end
        return v
    end)
    out.ammo={}
    if input.ammo~=nil and type(input.ammo)~="table" then bad("ammo должен быть объектом имя=количество.") end
    local count=0
    for key,value in pairs(input.ammo or {}) do
        local ammoName=text(key,"",64,"Название патронов")
        if ammoName=="" then bad("Пустое название патронов.") end
        count=count+1;if count>32 then bad("Слишком много типов патронов.") end
        out.ammo[ammoName]=number(value,0,0,10000,"Количество патронов",true)
    end
    out.bodygroups={}
    if input.bodygroups~=nil and type(input.bodygroups)~="table" then bad("bodygroups должен быть объектом.") end
    for key,value in pairs(input.bodygroups or {}) do
        local index=tonumber(key)
        if not finite(index) then bad("Номер bodygroup должен быть числом.") end
        number(index,0,0,63,"Номер bodygroup",true)
        out.bodygroups[tostring(index)]=number(value,0,0,255,"Значение bodygroup",true)
    end
    out.spawns={}
    if input.spawns~=nil and type(input.spawns)~="table" then bad("spawns должен быть объектом карт.") end
    local maps=0
    for map,points in pairs(input.spawns or {}) do
        local mapName=text(map,"",80,"Карта")
        if not mapName:match("^[%w_%-]+$") then bad("Неверное имя карты.") end
        maps=maps+1;if maps>32 then bad("Слишком много карт в одной роли.") end
        -- Do not deduplicate tables by address: each point is a data record.
        if type(points)~="table" or #points>16 then bad("На карту разрешено до 16 точек.") end
        local total=0;for k in pairs(points) do total=total+1;if type(k)~="number" or k<1 or k~=math.floor(k) then bad("Точки должны быть массивом.") end end
        if total~=#points then bad("Массив точек с пропусками.") end
        out.spawns[mapName]={}
        for _,point in ipairs(points) do
            if type(point)~="table" then bad("Неверная точка.") end
            for key in pairs(point) do if not ({x=true,y=true,z=true,p=true,yaw=true,r=true})[key] then bad("Неизвестное поле точки.") end end
            local p={}
            for _,key in ipairs({"x","y","z"}) do p[key]=number(point[key],nil,-32768,32768,"Координата "..key,false) end
            p.p=number(point.p,0,-89,89,"Pitch",false)
            p.yaw=number(point.yaw,0,-360,360,"Yaw",false)
            p.r=number(point.r,0,-180,180,"Roll",false)
            out.spawns[mapName][#out.spawns[mapName]+1]=p
        end
    end
    if id==RP.DefaultRole and (not out.enabled or #out.allowedGroups>0 or out.maxPlayers~=0) then bad("Гражданский должен оставаться открытым без лимита мест.") end
    return out
end
function RP.NormalizeRoleConfig(id,input)
    local ok,result=pcall(normalizeRole,id,input)
    if not ok then return nil,tostring(result) end
    return result
end
local function normalizeSettings(input)
    input=input or {}
    if type(input)~="table" then bad("settings должен быть объектом.") end
    for k in pairs(input) do if not RP.DefaultSettings[k] then bad("Неизвестная настройка: "..tostring(k)) end end
    return {roleChangeCooldown=number(input.roleChangeCooldown,30,1,600,"Cooldown",false),
        respawnDelay=number(input.respawnDelay,3,0,120,"Задержка спавна",false),
        respawnOnRoleChange=boolean(input.respawnOnRoleChange,true,"Переспавн при смене роли"),
        startingMoney=number(input.startingMoney,1000,0,100000000,"Стартовый баланс",true),
        salaryInterval=number(input.salaryInterval,600,60,86400,"Интервал зарплаты",true),
        currency=text(input.currency,"$",16,"Валюта")}
end
function RP.NormalizeConfig(input)
    local ok,out=pcall(function()
        if type(input)~="table" then bad("Корень JSON должен быть объектом.") end
        for k in pairs(input) do if not ({version=true,revision=true,settings=true,roles=true})[k] then bad("Неизвестное поле конфига: "..tostring(k)) end end
        if input.version~=nil and input.version~=2 and input.version~=3 then bad("Неподдерживаемая версия конфига.") end
        local roles=input.roles or {};if type(roles)~="table" then bad("roles должен быть объектом.") end
        local total=0;for id in pairs(roles) do total=total+1 end
        if total>100 then bad("Максимум 100 ролей.") end
        local result={version=3,revision=number(input.revision,0,0,2147483647,"revision",true),settings=normalizeSettings(input.settings),roles={}}
        for id,base in pairs(RP.BaseRoles) do result.roles[id]=normalizeRole(id,roles[id] or {}) end
        for id,value in pairs(roles) do if not result.roles[id] then result.roles[id]=normalizeRole(id,value) end end
        return result
    end)
    if not ok then return nil,tostring(out) end
    return out
end
local function clone(data) return util.JSONToTable(util.TableToJSON(data),false,true) end
function RP.BuildPublicConfig()
    local public={version=3,revision=RP.Config.revision,settings=clone(RP.Config.settings),roles={}}
    for id,role in pairs(RP.Config.roles) do
        public.roles[id]={name=role.name,faction=role.faction,sortOrder=role.sortOrder,salary=role.salary,
            craftAccess=role.craftAccess,tradeAccess=role.tradeAccess,attachmentCount=#role.attachments,enabled=role.enabled,model=role.model,armor=role.armor,
            armorCount=#role.armorItems,weaponCount=#role.weapons,restricted=#role.allowedGroups>0,maxPlayers=role.maxPlayers}
    end
    return public
end
util.AddNetworkString(RP.NetPublic)
for _,name in ipairs({RP.NetAdminGet,RP.NetAdminSave,RP.NetAdminReload,RP.NetAdminCapture,RP.NetAdminResult}) do util.AddNetworkString(name) end
function RP.SendPublicConfig(ply)
    net.Start(RP.NetPublic)
    if not RP.WriteJSON(RP.BuildPublicConfig()) then return false end
    if IsValid(ply) then net.Send(ply) else net.Broadcast() end
    return true
end
local function install(config)
    RP.Config=config
    RP.ConfigRevision=config.revision
    RP.InstallRoleCatalog(config.roles)
    RP.SendPublicConfig()
    hook.Run("VCityRP.ConfigChanged",config)
end
function RP.PersistConfig(config)
    local raw=util.TableToJSON(config,true)
    if not raw or #raw>MAX_FILE then return false,"Конфиг слишком большой." end
    if type(util.JSONToTable(raw,false,true))~="table" then return false,"Слишком сложный JSON для загрузки движком." end
    file.CreateDir("vcity_rp")
    local tmp="vcity_rp/config.pending.json"
    local ok,err=pcall(function()
        file.Write(tmp,raw)
        if file.Read(tmp,"DATA")~=raw then bad("Не удалось проверить временный файл.") end
        local previous=file.Read(RP.ConfigPath,"DATA")
        if previous then
            file.Write(RP.ConfigBackupPath,previous)
            if file.Read(RP.ConfigBackupPath,"DATA")~=previous then bad("Не удалось сохранить резервную копию.") end
        end
        file.Write(RP.ConfigPath,raw)
        if file.Read(RP.ConfigPath,"DATA")~=raw then
            if previous then file.Write(RP.ConfigPath,previous) end
            bad("Запись не подтверждена. Проверь права на DATA и свободное место.")
        end
    end)
    if file.Exists(tmp,"DATA") then file.Delete(tmp) end
    if not ok then return false,tostring(err) end
    return true
end
function RP.ReloadDiskConfig(boot)
    if file.Exists(RP.ConfigPath,"DATA") then
        if file.Size(RP.ConfigPath,"DATA")>MAX_FILE then return false,"Конфиг больше 512 КБ." end
        local raw=file.Read(RP.ConfigPath,"DATA")
        local decoded=type(raw)=="string" and util.JSONToTable(raw,false,true)
        local config,err=RP.NormalizeConfig(decoded)
        if not config then return false,err end
        config.revision=math.max(config.revision,(RP.ConfigRevision or 0)+1)
        if decoded.version~=3 then
            local migrated,message=RP.PersistConfig(config)
            if not migrated then return false,message end
        end
        install(config)
        return true
    end
    local config=RP.NormalizeConfig({version=3})
    config.revision=(RP.ConfigRevision or 0)+1
    local ok,err=RP.PersistConfig(config)
    if not ok then return false,err end
    install(config)
    return true
end

local builtins={weapon_pistol=true,weapon_357=true,weapon_smg1=true,weapon_ar2=true,weapon_shotgun=true,
    weapon_crossbow=true,weapon_rpg=true,weapon_frag=true,weapon_crowbar=true,weapon_stunstick=true,
    weapon_physgun=true,weapon_physcannon=true,gmod_tool=true,gmod_camera=true}
function RP.ValidateRoleAssets(role)
    if role.model~="" and not util.IsValidModel(role.model) then return false,"Модель не найдена на сервере: "..role.model end
    for _,class in ipairs(role.weapons) do if not weapons.GetStored(class) and not builtins[class] then return false,"Не найден SWEP: "..class end end
    for name in pairs(role.ammo) do if game.GetAmmoID(name)<0 then return false,"Не найден тип патронов: "..name end end
    for _,id in ipairs(role.armorItems) do
        local found=false
        for _,part in pairs(hg.armor or {}) do if part[id] then found=true;break end end
        if not found then return false,"Не найден предмет брони: "..id end
    end
    return true
end
function RP.SaveRoleConfig(id,input,settings,expectedRevision)
    if expectedRevision~=RP.ConfigRevision then return false,"Конфиг изменился. Загрузи свежую версию." end
    if not RP.Config.roles[id] then return false,"Роль не найдена. Используй создание новой роли." end
    local role,err=RP.NormalizeRoleConfig(id,input)
    if not role then return false,err end
    local ok,reason=RP.ValidateRoleAssets(role)
    if not ok then return false,reason end
    local copy=clone(RP.Config)
    copy.roles[id]=role
    if settings~=nil then
        local valid,value=pcall(normalizeSettings,settings)
        if not valid then return false,tostring(value) end
        copy.settings=value
    end
    copy.revision=RP.ConfigRevision+1
    local saved,message=RP.PersistConfig(copy)
    if not saved then return false,message end
    install(copy)
    return true
end
function RP.AdminReply(ply,data)
    net.Start(RP.NetAdminResult)
    -- WriteJSON refuses oversized data BEFORE writing anything, so no second net.Start is needed.
    if not RP.WriteJSON(data) then
        RP.WriteJSON({kind="error",message="Настройки роли слишком велики для редактора; используй JSON на диске."})
    end
    net.Send(ply)
end
function RP.AdminGate(ply,bits,limit,interval,key)
    -- Authorize BEFORE reading any attacker-supplied JSON, ID or coordinates.
    if not IsValid(ply) or not ply:IsPlayer() or not ply:IsSuperAdmin() or bits>limit then return false end
    local field="VCityRPNextAdmin_"..(key or "get")
    if (ply[field] or 0)>CurTime() then return false end
    ply[field]=CurTime()+(interval or 0.15)
    return true
end
function RP.SendAdminRole(ply,id,kind)
    local ammoTypes={}
    -- game.GetAmmoTypes() is { [ammoID] = "name" }; accept records with .name too, just in case.
    for _,record in pairs(game.GetAmmoTypes() or {}) do
        local name=type(record)=="string" and record or (type(record)=="table" and record.name)
        if type(name)=="string" and name~="" then ammoTypes[#ammoTypes+1]=name end
    end
    table.sort(ammoTypes)
    RP.AdminReply(ply,{kind=kind or "loaded",id=id,role=clone(RP.Config.roles[id]),settings=clone(RP.Config.settings),
        revision=RP.ConfigRevision,map=game.GetMap(),ammoTypes=ammoTypes,path="garrysmod/data/"..RP.ConfigPath})
end
net.Receive(RP.NetAdminGet,function(bits,ply)
    if not RP.AdminGate(ply,bits,512) then return end
    local id=net.ReadString()
    if not RP.Roles[id] then RP.AdminReply(ply,{kind="error",message="Неизвестная роль."}) return end
    RP.SendAdminRole(ply,id)
end)
net.Receive(RP.NetAdminSave,function(bits,ply)
    if not RP.AdminGate(ply,bits,RP.MaxNetJSON*8+16,1,"save") then return end
    local request,err=RP.ReadJSON(bits)
    if not request then RP.AdminReply(ply,{kind="error",message=err}) return end
    local ok,reason=RP.SaveRoleConfig(request.id,request.role,request.settings,request.revision)
    if not ok then RP.AdminReply(ply,{kind="error",id=request.id,message=reason}) return end
    RP.SendAdminRole(ply,request.id,"saved")
end)
net.Receive(RP.NetAdminCapture,function(bits,ply)
    if not RP.AdminGate(ply,bits,32,0.15,"capture") then return end
    if not ply:Alive() or ply:InVehicle() then RP.AdminReply(ply,{kind="error",message="Встань на точку вне транспорта."}) return end
    local pos=ply:GetPos();local ang=ply:EyeAngles()
    RP.AdminReply(ply,{kind="capture",map=game.GetMap(),point={x=math.Round(pos.x,2),y=math.Round(pos.y,2),z=math.Round(pos.z+2,2),p=0,yaw=math.Round(ang.y,2),r=0}})
end)
net.Receive(RP.NetAdminReload,function(bits,ply)
    if not RP.AdminGate(ply,bits,32,1,"reload") then return end
    local ok,err=RP.ReloadDiskConfig(false)
    RP.AdminReply(ply,{kind=ok and "reloaded" or "error",message=ok and "JSON перечитан с диска." or err,revision=RP.ConfigRevision})
end)
concommand.Add("vcity_rp_reload",function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local ok,err=RP.ReloadDiskConfig(false)
    local message=ok and "[V-City RP] JSON loaded." or ("[V-City RP] "..tostring(err))
    if IsValid(ply) then ply:ChatPrint(message) else print(message) end
end)

local ok,err=RP.ReloadDiskConfig(true)
if not ok then
    -- Never overwrite a malformed user file on boot.
    RP.Config=RP.NormalizeConfig({version=3})
    RP.Config.revision=1;RP.ConfigRevision=1
    RP.InstallRoleCatalog(RP.Config.roles)
    ErrorNoHalt("[V-City RP] Config error; defaults active, disk file preserved: "..tostring(err).."\n")
end
