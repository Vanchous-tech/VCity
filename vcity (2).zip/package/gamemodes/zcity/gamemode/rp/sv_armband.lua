-- Опознавательные повязки: игрокам ВС РФ и «Дрины» на любой модели надевается красная повязка
-- (аксессуар мода Z-City Armbands, workshop 3775798945). Повязку нельзя снять через редактор внешности:
-- сервер возвращает её на спавне, при смене роли и при любой перезаписи внешности.
local RP=VCityRP
-- фракция -> id аксессуара из мода (armband red/blue/green/yellow/orange/purple/pink/cyan/white/black)
-- или список вариантов: тогда игрок получает случайный из них, цвет выбирается заново на каждом спавне.
RP.ArmbandByFaction={rf={"armband red","armband white"},drina={"armband red","armband white"}}
RP.ArmbandWorkshopID="3775798945"
if RP.ArmbandWorkshopID~="" then resource.AddWorkshop(RP.ArmbandWorkshopID) end

local function wanted(ply)
    local role=RP.RoleByID(RP.GetRole(ply).ID)
    local entry=role and RP.ArmbandByFaction[role.Faction]
    if not entry then ply.VCityRPBandPick=nil return nil end
    if isstring(entry) then return entry end
    for _,id in ipairs(entry) do
        if id==ply.VCityRPBandPick then return id end
    end
    ply.VCityRPBandPick=entry[math.random(#entry)]
    return ply.VCityRPBandPick
end
local function allBands()
    local set={}
    for _,entry in pairs(RP.ArmbandByFaction) do
        if isstring(entry) then set[entry]=true else for _,id in ipairs(entry) do set[id]=true end end
    end
    return set
end

function RP.EnforceArmband(ply)
    if not IsValid(ply) or not ply:IsPlayer() or not ply.SetNetVar then return end
    local current=ply:GetNetVar("Accessories",{})
    if not istable(current) then current={} end
    local band=wanted(ply)
    local ours=allBands()
    local list,changed={},false
    for i,uid in ipairs(current) do list[i]=uid end
    if band then
        if not (hg.Accessories and hg.Accessories[band]) then return end -- мод не установлен
        -- убрать чужие цвета из нашего набора, оставить ровно одну нужную повязку
        local has=false
        for i,uid in ipairs(list) do
            if uid==band then
                if has then list[i]="";changed=true else has=true end
            elseif ours[uid] then list[i]="";changed=true end
        end
        if not has then
            local slot
            for i,uid in ipairs(list) do if uid=="" then slot=i break end end
            list[slot or #list+1]=band;changed=true
        end
        ply.VCityRPBand=band
    elseif ply.VCityRPBand then
        for i,uid in ipairs(list) do
            if uid==ply.VCityRPBand then list[i]="";changed=true end
        end
        ply.VCityRPBand=nil
    end
    if changed then ply:SetNetVar("Accessories",list) end
end

-- Любой путь внешности (настроенная модель, редактор, кэш) перезаписывает Accessories,
-- поэтому повязку проверяет короткий цикл: он дешёвый и ловит все случаи сразу.
timer.Create("VCityRP.ArmbandEnforce",0.5,0,function()
    for _,ply in ipairs(player.GetAll()) do
        if ply:Alive() then RP.EnforceArmband(ply) end
    end
end)
hook.Add("VCityRP.RoleChanged","VCityRP.ArmbandRole",function(ply) ply.VCityRPBandPick=nil timer.Simple(0.2,function() RP.EnforceArmband(ply) end) end)
hook.Add("PlayerSpawn","VCityRP.ArmbandSpawn",function(ply)
    ply.VCityRPBandPick=nil -- новая жизнь: цвет выбирается заново
    for _,delay in ipairs({0.6,2}) do timer.Simple(delay,function() if IsValid(ply) and ply:Alive() then RP.EnforceArmband(ply) end end) end
end)
