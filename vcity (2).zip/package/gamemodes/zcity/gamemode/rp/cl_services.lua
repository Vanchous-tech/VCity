local RP=VCityRP
local function frame(title,w,h)
    local f=vgui.Create("DFrame");f:SetSize(math.min(w,ScrW()-32),math.min(h,ScrH()-32));f:Center();f:SetTitle("");f:ShowCloseButton(false);f:MakePopup()
    f.Paint=function(self,pw,ph)
        draw.RoundedBox(3,0,0,pw,ph,RP.UI.bg)
        surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,pw,ph,1)
        draw.SimpleText("V-CITY / ROLEPLAY","VCityRP.Small",20,15,RP.UI.accent)
        draw.SimpleText(title,"VCityRP.Title",20,37,RP.UI.text)
    end
    local close=RP.UIButton(f,"X",function() f:Close() end);close:SetPos(f:GetWide()-50,15);close:SetSize(30,28)
    return f
end
local function label(parent,text,x,y,w)
    local l=vgui.Create("DLabel",parent);l:SetPos(x,y);l:SetSize(w or 300,20);l:SetFont("VCityRP.Small");l:SetTextColor(RP.UI.muted);l:SetText(text);return l
end
local function input(parent,value,x,y,w,h)
    local e=vgui.Create("DTextEntry",parent);e:SetPos(x,y);e:SetSize(w,h or 28);e:SetFont("VCityRP.Body");e:SetText(tostring(value or ""))
    if (h or 28)>35 then e:SetMultiline(true) end
    e.Paint=function(self,pw,ph) draw.RoundedBox(2,0,0,pw,ph,RP.UI.row);self:DrawTextEntryText(RP.UI.text,RP.UI.selection,RP.UI.text) end
    return e
end
local function send(name,data)
    net.Start(name);if RP.WriteJSON(data) then net.SendToServer() end
end
function RP.OpenRoleCreator()
    if not LocalPlayer():IsSuperAdmin() then return end
    local f=frame("Создать роль",460,260)
    label(f,"Название (до 32 символов)",20,83)
    local name=input(f,"",20,105,420)
    label(f,"Фракция",20,142)
    local combo=vgui.Create("DComboBox",f);combo:SetPos(20,164);combo:SetSize(420,28)
    local faction="usa"
    for _,item in ipairs(RP.Factions) do combo:AddChoice(item.Name,item.ID) end
    combo:SetValue("США");combo.OnSelect=function(self,index,title,id) faction=id end
    local create=RP.UIButton(f,"Создать и настроить",function()
        local value,err=RP.ValidateProfession(name:GetValue())
        if not value then notification.AddLegacy(err,NOTIFY_ERROR,4) return end
        send(RP.NetAdminCreate,{name=value,faction=faction,revision=RP.PublicConfig and RP.PublicConfig.revision or 0});f:Close()
    end);create:SetPos(240,210);create:SetSize(200,32);create.Primary=true
end
function RP.OpenWorkshopAdmin()
    if not LocalPlayer():IsSuperAdmin() then return end
    if IsValid(RP.WorkshopAdmin) then RP.WorkshopAdmin:MakePopup() return end
    local f=frame("Мастерская / станки",880,780);RP.WorkshopAdmin=f
    local config,revision;local selected;local fields={};local kind="pistol";local priceFields={}
    local function trim(value) return (tostring(value or ""):gsub("^%s+",""):gsub("%s+$","")) end
    label(f,"Конфиг: data/vcity_rp/workshop.json · Крафт без цены: мини-игра + cooldown + роль «Оружейник»",20,77,840)
    local list=vgui.Create("DScrollPanel",f);list:SetPos(20,108);list:SetSize(250,300)
    local prices=vgui.Create("DScrollPanel",f);prices:SetPos(20,438);prices:SetSize(250,220)
    local function fill(id)
        selected=id;local recipe=config.recipes[id]
        if not recipe then return end
        fields.name:SetText(recipe.name);fields.class:SetText(recipe.class);fields.difficulty:SetText(recipe.difficulty);fields.cooldown:SetText(recipe.cooldown)
        fields.attachments:SetText(table.concat(recipe.attachments or {},", "))
        kind=recipe.kind;fields.kind:SetValue(({pistol="Пистолет / тайминг",automatic="Автомат / память",rifle="Винтовка / сигнал"})[kind])
    end
    local function rebuild()
        list:GetCanvas():Clear()
        local ids={};for id in pairs(config.recipes) do ids[#ids+1]=id end;table.sort(ids)
        for i,id in ipairs(ids) do
            local key=id
            local b=RP.UIButton(list,config.recipes[id].name,function() fill(key) end);b:Dock(TOP);b:DockMargin(0,0,4,8);b:SetTall(34)
        end
        prices:GetCanvas():Clear();priceFields={}
        local classes={}
        for _,recipe in pairs(config.recipes) do if recipe.class and #recipe.class>0 then classes[recipe.class]=true end end
        for class in pairs(config.prices or {}) do classes[class]=true end
        local rows={};for class in pairs(classes) do rows[#rows+1]=class end;table.sort(rows)
        for _,class in ipairs(rows) do
            local row=vgui.Create("DPanel",prices);row:Dock(TOP);row:DockMargin(0,0,4,6);row:SetTall(30)
            row.Paint=function(self,pw,ph) draw.RoundedBox(2,0,0,pw,ph,RP.UI.row) end
            local title=vgui.Create("DLabel",row);title:SetFont("VCityRP.Small");title:SetText(class);title:SetPos(8,7);title:SetSize(150,18);title:SetTextColor(RP.UI.muted)
            priceFields[class]=input(row,(config.prices and config.prices[class]) or 0,162,3,82,22)
        end
        if #rows==0 then
            local empty=vgui.Create("DLabel",prices);empty:Dock(TOP);empty:SetTall(40);empty:SetFont("VCityRP.Small")
            empty:SetText("Пока нет классов: добавь рецепт с weapon_...");empty:SetTextColor(RP.UI.muted)
        end
    end
    local x=290
    label(f,"Название",x,110);fields.name=input(f,"",x,132,570)
    label(f,"Класс SWEP (weapon_...)",x,170);fields.class=input(f,"",x,192,570)
    label(f,"Тип / мини-игра",x,230)
    fields.kind=vgui.Create("DComboBox",f);fields.kind:SetPos(x,252);fields.kind:SetSize(570,28)
    for _,record in ipairs({{"Пистолет / тайминг","pistol"},{"Автомат / память","automatic"},{"Винтовка / сигнал","rifle"}}) do fields.kind:AddChoice(record[1],record[2]) end
    fields.kind.OnSelect=function(self,index,name,id) kind=id end
    label(f,"Сложность 1–5",x,290);fields.difficulty=input(f,2,x,312,260)
    label(f,"Cooldown, секунды (10–3600)",x+300,290);fields.cooldown=input(f,60,x+300,312,270)
    label(f,"Обвесы, выданные вместе с оружием (до 6 ID через запятую)",x,350);fields.attachments=input(f,"",x,372,570)
    label(f,"ID как в каталоге аддона: optic11, supressor1, laser2 … Пусто — оружие без обвесов.",x,404,570)
    local save=RP.UIButton(f,"Сохранить рецепт",function()
        if not config then return end
        local name,err=RP.ValidateProfession(fields.name:GetValue());if not name then notification.AddLegacy(err,NOTIFY_ERROR,4) return end
        local id=selected or ("recipe_"..tostring(math.floor(RealTime()*1000)))
        local attachments={}
        for piece in string.gmatch(fields.attachments:GetValue()..",","([^,]+)") do
            local trimmed=trim(piece);if #trimmed>0 then attachments[#attachments+1]=trimmed end
        end
        if #attachments>6 then notification.AddLegacy("Обвесов максимум 6 на рецепт.",NOTIFY_ERROR,4) return end
        local recipe=config.recipes[id] or {}
        recipe.name=name;recipe.class=trim(fields.class:GetValue());recipe.kind=kind
        recipe.difficulty=tonumber(fields.difficulty:GetValue());recipe.cooldown=tonumber(fields.cooldown:GetValue())
        if recipe.enabled==nil then recipe.enabled=true end
        recipe.attachments=attachments
        config.recipes[id]=recipe;selected=id
        send(RP.NetServices,{action="save",config=config,revision=revision})
    end);save:SetPos(x,432);save:SetSize(275,34);save.Primary=true
    local new=RP.UIButton(f,"+ Новый рецепт",function()
        selected=nil;fields.name:SetText("");fields.class:SetText("");fields.difficulty:SetText(2);fields.cooldown:SetText(60);fields.attachments:SetText("")
    end);new:SetPos(x+295,432);new:SetSize(275,34)
    local remove=RP.UIButton(f,"Удалить выбранный рецепт",function()
        if not config or not selected then return end;config.recipes[selected]=nil;selected=nil
        send(RP.NetServices,{action="save",config=config,revision=revision})
    end);remove:SetPos(x,476);remove:SetSize(570,30)
    label(f,"Закупка (опт) — 0 = оружие нельзя продавать · прибыль торговца = цена продажи − закупка",20,416,250)
    local savePrices=RP.UIButton(f,"Сохранить цены закупки",function()
        if not config then return end
        local map={}
        for class,entry in pairs(priceFields) do
            local value=math.floor(tonumber(trim(entry:GetValue())) or 0)
            if value<0 then value=0 end
            if value>0 then map[class]=value end
        end
        config.prices=map
        send(RP.NetServices,{action="save",config=config,revision=revision})
    end);savePrices:SetPos(20,666);savePrices:SetSize(250,30)
    label(f,"Станок",x,512)
    local place=RP.UIButton(f,"Поставить станок на точку взгляда",function() send(RP.NetServices,{action="place"}) end);place:SetPos(x,536);place:SetSize(275,34)
    local clear=RP.UIButton(f,"Удалить станки текущей карты",function()
        if not config then return end
        Derma_Query("Удалить сохранённые станки этой карты?","V-City","Удалить",function() config.stations[game.GetMap()]={};send(RP.NetServices,{action="save",config=config,revision=revision}) end,"Отмена")
    end);clear:SetPos(x+295,536);clear:SetSize(275,34)
    label(f,"Для размещения смотри на пол рядом. Станки восстановятся после смены карты / рестарта.",x,578,570)
    label(f,"Модель: models/props_canal/winch02.mdl · Использование: E · Доступ: роль с флагом «Оружейник» (по умолчанию: гражданский Оружейник)",x,600,570)
    f.Receive=function(data)
        config=data.config;revision=data.revision;rebuild()
        if selected and config.recipes[selected] then fill(selected) end
        notification.AddLegacy("Конфиг мастерской загружен / сохранён.",NOTIFY_GENERIC,3)
    end
    send(RP.NetServices,{action="get"})
end
net.Receive(RP.NetServicesResult,function(bits)
    local d=RP.ReadJSON(bits);if not d then return end
    if d.kind=="error" then notification.AddLegacy(d.message,NOTIFY_ERROR,5);send(RP.NetServices,{action="get"}) return end
    if IsValid(RP.WorkshopAdmin) then RP.WorkshopAdmin.Receive(d) end
end)
net.Receive(RP.NetInteraction,function(bits)
    local d=RP.ReadJSON(bits);if not d then return end
    if d.kind=="offer" then
        Derma_Query(d.from.." предлагает: "..d.label..". Принять?","Передача предмета","Принять",function() send(RP.NetInteractionAction,{action="accept",offer=d.offer}) end,"Отказаться",function() send(RP.NetInteractionAction,{action="decline",offer=d.offer}) end)
        return
    end
    if RP.OpenInteractionRadial then RP.OpenInteractionRadial(d) end
end)
local gameFrame,state,offset
local function craftSend(action,key) if state then send(RP.NetCraftAction,{token=state.token,action=action,key=key}) end end
local function now() return CurTime()+(offset or 0) end
local function openChallenge(d)
    if IsValid(gameFrame) then gameFrame:Remove() end
    gameFrame=frame("Станок / "..d.name,650,430)
    local f=gameFrame
    label(f,({pistol="Синхронизация: нажми ПРОБЕЛ в оранжевой зоне",automatic="Память: запомни порядок и повтори",rifle="Сигнал: включи все шесть индикаторов"})[d.type],20,84,610)
    local panel=vgui.Create("DPanel",f);panel:SetPos(22,120);panel:SetSize(606,210)
    panel.Paint=function(self,w,h)
        draw.RoundedBox(3,0,0,w,h,RP.UI.row)
        if not state then return end
        if state.type=="pistol" then
            local t=math.max(now()-state.startAt,0)
            local cursor=(math.sin(t*(1.6+state.difficulty*0.15))+1)/2
            local width=0.28-state.difficulty*0.025
            surface.SetDrawColor(RP.UI.line);surface.DrawRect(25,82,w-50,42)
            surface.SetDrawColor(RP.UI.accent);surface.DrawRect(25+(0.5-width/2)*(w-50),82,width*(w-50),42)
            surface.SetDrawColor(RP.UI.text);surface.DrawRect(25+cursor*(w-50)-2,70,4,67)
            draw.SimpleText("Этап "..math.min(state.phase,state.total).." / "..state.total,"VCityRP.Body",w/2,165,RP.UI.text,TEXT_ALIGN_CENTER)
        elseif state.type=="automatic" then
            local index=math.floor((now()-state.startAt)/0.7)+1
            local showing=now()<state.inputAt
            for key=1,4 do
                local lit=showing and state.pattern[index]==key
                draw.RoundedBox(3,30+(key-1)*143,50,120,90,lit and RP.UI.accent or RP.UI.hover)
                draw.SimpleText(tostring(key),"VCityRP.Title",90+(key-1)*143,95,lit and RP.UI.onAccent or RP.UI.text,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            draw.SimpleText(showing and "Запоминай..." or ("Повтори: "..(state.index-1).." / "..#state.pattern),"VCityRP.Body",w/2,180,RP.UI.text,TEXT_ALIGN_CENTER)
        elseif state.type=="rifle" then
            for key=1,6 do
                local lit=state.bits[key]==1
                draw.RoundedBox(3,18+(key-1)*96,36,80,70,lit and RP.UI.accent or RP.UI.hover)
                draw.SimpleText(lit and "ON" or "OFF","VCityRP.Body",58+(key-1)*96,70,lit and RP.UI.onAccent or RP.UI.text,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            draw.DrawText("Клавиша меняет свой индикатор и два соседних.\nПереключений: "..state.moves,"VCityRP.Body",w/2,142,RP.UI.muted,TEXT_ALIGN_CENTER)
        end
    end
    local hit=RP.UIButton(f,d.type=="pistol" and "ПРОБЕЛ / Зафиксировать" or "Отправляй клавиши 1–"..(d.type=="automatic" and "4" or "6"),function() if state.type=="pistol" then craftSend("hit") end end)
    hit:SetPos(22,350);hit:SetSize(606,38);hit.Primary=true
    if d.type~="pistol" then
        hit:Remove()
        local total=d.type=="automatic" and 4 or 6
        for key=1,total do
            local value=key
            local b=RP.UIButton(f,tostring(key),function() craftSend(state.type=="automatic" and "key" or "switch",value) end)
            b:SetPos(22+(key-1)*(606/total),350);b:SetSize(606/total-8,38)
        end
    end
    f.OnKeyCodePressed=function(self,key)
        if key==KEY_SPACE and state.type=="pistol" then craftSend("hit") end
        for i=1,6 do if key==KEY_1+i-1 then craftSend(state.type=="automatic" and "key" or "switch",i) end end
        if key==KEY_ESCAPE then craftSend("cancel");self:Close() end
    end
    f.OnClose=function() if state then craftSend("cancel") end end
end
net.Receive(RP.NetBenchOpen,function(bits)
    local d=RP.ReadJSON(bits);if not d then return end
    local f=frame("Станок / выбор рецепта",620,460)
    label(f,"Доступ: роль «Оружейник» · Мини-игры вместо цены · Готовое оружие и обвесы выдаёт сервер",20,83,580)
    label(f,"Cooldown: "..math.ceil(d.cooldown).." сек.",20,106,580)
    local list=vgui.Create("DScrollPanel",f);list:SetPos(20,141);list:SetSize(580,280)
    local count=0
    for id,recipe in pairs(d.recipes or {}) do
        if recipe.enabled then
            local rid=id;count=count+1
            local attachments=recipe.attachments or {}
            local suffix=#attachments>0 and (" / обвесы: "..table.concat(attachments,", ")) or ""
            local b=RP.UIButton(list,recipe.name.." / "..recipe.kind.." / сложность "..recipe.difficulty..suffix,function() send(RP.NetCraftStart,{bench=d.bench,recipe=rid});f:Close() end)
            b:Dock(TOP);b:DockMargin(0,0,4,9);b:SetTall(44)
        end
    end
    if count==0 then label(list,"Рецепты ещё не настроены суперадмином.",5,20,560) end
end)
net.Receive(RP.NetCraftState,function(bits)
    local d=RP.ReadJSON(bits);if not d then return end
    if d.kind=="start" or d.kind=="state" then
        state=d;offset=d.serverTime-CurTime()
        if d.kind=="start" then openChallenge(d) end
    else
        state=nil
        if IsValid(gameFrame) then gameFrame:Remove() end
        notification.AddLegacy(d.message or "Завершено",d.kind=="complete" and NOTIFY_GENERIC or NOTIFY_ERROR,5)
    end
end)
concommand.Add("vcity_rp_workshop",RP.OpenWorkshopAdmin)

hook.Add("HUDPaint","VCityRP.UseHint",function()
    local ply=LocalPlayer()
    if not IsValid(ply) or not ply:Alive() or IsValid(RP.InteractionFrame) then return end
    local entity=ply:GetEyeTrace().Entity
    if not IsValid(entity) or ply:GetPos():DistToSqr(entity:GetPos())>120*120 then return end
    local text=entity:IsPlayer() and "E / Взаимодействие" or (entity:GetClass()=="vcity_rp_bench" and "E / Станок (роль «Оружейник»)")
    if text then draw.SimpleText(text,"VCityRP.Body",ScrW()/2,ScrH()/2+65,RP.UI.accent,TEXT_ALIGN_CENTER) end
end)
