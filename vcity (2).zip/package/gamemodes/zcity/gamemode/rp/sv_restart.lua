-- V-City RP 0.3.5 — SERVER ONLY. Restart countdown and night reminder.
--
-- The loop runs once a second, compares the local host clock with the configured restart hour and
-- sends one notice per crossed threshold. The message is shown in the middle of the screen by
-- rp/cl_restart.lua and repeated once in chat.
local RP = VCityRP
util.AddNetworkString(RP.NetRestart)

local warned = {}
local cycleAt = nil
local lastLeft = nil
local lastNightAt = nil
local currentState = nil

local function convarNumber(name, default, text, minimum, maximum)
    local ok, result = pcall(CreateConVar, name, tostring(default), FCVAR_ARCHIVE and {FCVAR_ARCHIVE} or {}, text, minimum, maximum)
    if ok and result ~= nil then return result end
    return nil
end

RP.RestartConVars = {
    enabled = convarNumber("vcity_rp_restart", 1, "Уведомления о плановом рестарте сервера", 0, 1),
    hour = convarNumber("vcity_rp_restart_hour", RP.RestartDefaults.hour, "Час планового рестарта по времени хостинга", 0, 23),
    minute = convarNumber("vcity_rp_restart_minute", RP.RestartDefaults.minute, "Минута планового рестарта", 0, 59),
    warn = convarNumber("vcity_rp_restart_warn", table.concat(RP.RestartDefaults.warnMinutes, ","), "Минуты до рестарта, когда включается отсчёт (через запятую)"),
    nightHours = convarNumber("vcity_rp_restart_night", RP.RestartDefaults.nightHours, "За сколько часов до рестарта начинать ночные напоминания", 0, 12),
    nightEvery = convarNumber("vcity_rp_restart_night_every", RP.RestartDefaults.nightEverySeconds, "Период ночных напоминаний в секундах", 60, 7200)
}

local function number(name, fallback, minimum, maximum)
    local config = RP.RestartConVars[name]
    if not config then return fallback end
    local value = config:GetFloat()
    if type(value) ~= "number" or value ~= value then return fallback end
    if minimum and value < minimum then return fallback end
    if maximum and value > maximum then return fallback end
    return value
end

function RP.RestartEnabled()
    local config = RP.RestartConVars.enabled
    if not config then return true end
    return config:GetFloat() == 1
end

function RP.RestartHour() return math.floor(number("hour", RP.RestartDefaults.hour, 0, 23)) end
function RP.RestartMinute() return math.floor(number("minute", RP.RestartDefaults.minute, 0, 59)) end
function RP.RestartNightHours() return number("nightHours", RP.RestartDefaults.nightHours, 0, 12) end
function RP.RestartNightEvery() return math.floor(number("nightEvery", RP.RestartDefaults.nightEverySeconds, 60, 7200)) end

-- «60, 30, 15» -> {3600, 1800, 900}; also accepts seconds in the last hour.
function RP.RestartWarnThresholds()
    local minutes = {}
    local raw = RP.RestartConVars.warn and RP.RestartConVars.warn:GetString() or table.concat(RP.RestartDefaults.warnMinutes, ",")
    for piece in tostring(raw):gmatch("[^,;%s]+") do
        local value = tonumber(piece)
        if value and value > 0 then minutes[#minutes + 1] = math.floor(value) end
    end
    if #minutes == 0 then minutes = table.copy and table.copy(RP.RestartDefaults.warnMinutes) or RP.RestartDefaults.warnMinutes end
    local seconds = {}
    for _, value in ipairs(minutes) do seconds[#seconds + 1] = value * 60 end
    seconds[#seconds + 1] = RP.RestartDefaults.finalSeconds
    table.sort(seconds, function(a, b) return a > b end)
    return seconds, minutes
end

function RP.RestartSubText()
    return RP.FillRestartText(RP.RestartSub, {time = RP.ClockText(RP.RestartHour(), RP.RestartMinute())})
end

-- Broadcast one notice. `seconds` is how long the on-screen block stays up.
function RP.AnnounceRestart(text, seconds, kind)
    if type(text) ~= "string" or text == "" then return false end
    seconds = math.Clamp(math.floor(tonumber(seconds) or 12), 3, 240)
    net.Start(RP.NetRestart)
    net.WriteString(text)
    net.WriteString(RP.RestartSubText())
    net.WriteUInt(seconds, 8)
    net.Broadcast()
    print("[V-City RP] restart notice (" .. tostring(kind or "info") .. "): " .. text)
    hook.Run("VCityRP.RestartNotice", text, seconds, kind)
    return true
end

-- One tick of the schedule. Takes an explicit timestamp so it can be replayed in tests.
function RP.RestartTick(now)
    now = math.floor(tonumber(now) or RP.GetServerTime())
    if not RP.RestartEnabled() then return nil, {} end
    local state = RP.RestartState(now, RP.RestartHour(), RP.RestartMinute())
    currentState = state
    if state.at ~= cycleAt then
        -- new day of the cycle: forget the thresholds burnt during the previous one
        warned = {}
        cycleAt = state.at
        lastLeft = nil
        lastNightAt = nil
    end
    local thresholds = RP.RestartWarnThresholds()
    local fired = {}
    if lastLeft == nil then
        -- first tick after a start or a restart: do not replay every missed warning at once
        for _, threshold in ipairs(thresholds) do
            if state.left <= threshold then warned[threshold] = true end
        end
    else
        for _, threshold in ipairs(RP.CrossedWarnings(thresholds, state.left, lastLeft)) do
            if not warned[threshold] then
                warned[threshold] = true
                fired[#fired + 1] = threshold
            end
        end
    end
    lastLeft = state.left
    if #fired > 0 then
        for _, threshold in ipairs(fired) do
            local text = threshold <= RP.RestartDefaults.finalSeconds
                and RP.RestartDefaults.finalText
                or RP.FillRestartText(RP.RestartDefaults.warningText, {when = RP.DurationText(threshold)})
            RP.AnnounceRestart(text, threshold <= 30 and 12 or 14, "countdown")
        end
        return state, fired
    end
    -- night reminder: «уже поздно, рестарт в 05:00» every 15 minutes through the small hours
    local nightWindow = RP.RestartNightHours() * 3600
    if nightWindow > 0 and state.left <= nightWindow then
        if lastNightAt == nil then
            lastNightAt = now
            local text = RP.FillRestartText(RP.RestartDefaults.nightText, {time = state.clock})
            RP.AnnounceRestart(text, 16, "night")
            return state, {0}
        end
        if now - lastNightAt >= RP.RestartNightEvery() then
            lastNightAt = now
            local text = RP.FillRestartText(RP.RestartDefaults.nightText, {time = state.clock})
            RP.AnnounceRestart(text, 16, "night")
            return state, {0}
        end
    end
    return state, {}
end

hook.Add("InitPostEntity", "VCityRP.RestartSchedule", function()
    if not timer or not timer.Create then return end
    timer.Create("VCityRP.RestartSchedule", 1, 0, function()
        local ok, error = pcall(RP.RestartTick)
        if not ok and ErrorNoHalt then ErrorNoHalt("[V-City RP] restart tick: " .. tostring(error) .. "\n") end
    end)
end)

-- A player who just joined asks once and gets the current schedule in the same way, so nobody has
-- to learn the restart time only from the next announcement.
util.AddNetworkString(RP.NetRestartAsk)
net.Receive(RP.NetRestartAsk, function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if (ply.VCityRPNextRestartAsk or 0) > CurTime() then return end
    ply.VCityRPNextRestartAsk = CurTime() + 15
    local state = currentState or RP.RestartState()
    net.Start(RP.NetRestart)
    net.WriteString(RP.FillRestartText(RP.RestartDefaults.nightText, {time = state.clock}))
    net.WriteString(RP.RestartSubText())
    net.WriteUInt(10, 8)
    net.Send(ply)
end)

-- Status for admins: next restart and what is configured.
concommand.Add("vcity_rp_restart_status", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local state = currentState or RP.RestartState()
    local message = "[V-City RP] Рестарт: " .. (RP.RestartEnabled() and "включён" or "выключен")
        .. " · следующий в " .. state.clock .. " · осталось " .. RP.DurationText(state.left)
    if IsValid(ply) then ply:ChatPrint(message) else print(message) end
end)

-- Superadmin demo: show the very notice players will see, without waiting for the night.
concommand.Add("vcity_rp_restart_test", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local state = RP.RestartState()
    if IsValid(ply) then ply:ChatPrint("[V-City RP] Показываю демонстрацию уведомления всем игрокам.") end
    RP.AnnounceRestart(RP.FillRestartText(RP.RestartDefaults.nightText, {time = state.clock}), 16, "demo")
    timer.Simple(6, function()
        RP.AnnounceRestart(RP.FillRestartText(RP.RestartDefaults.warningText, {when = RP.DurationText(900)}), 14, "demo")
    end)
end)
