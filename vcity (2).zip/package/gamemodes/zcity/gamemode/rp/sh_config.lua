-- V-City RP 0.2. Shared catalogue; actual settings live on the SERVER in DATA.
VCityRP = VCityRP or {}
local RP = VCityRP
RP.Enabled = true
RP.KarmaDisabled = true
RP.Version = "0.6.4"
RP.DefaultRole = "civilian"
RP.RoleNWKey = "vcity_rp_role"
RP.Title = "V-City RP"
RP.Region = "США"
RP.ConfigPath = "vcity_rp/config.json"
RP.ConfigBackupPath = "vcity_rp/config.previous.json"
RP.MaxNetJSON = 48000
RP.NetSelect = "vcity_rp_select_role"
RP.NetResult = "vcity_rp_role_result"
RP.NetOpen = "vcity_rp_open_f4"
RP.NetPublic = "vcity_rp_public_config"
RP.NetAdminGet = "vcity_rp_admin_get"
RP.NetAdminSave = "vcity_rp_admin_save"
RP.NetAdminReload = "vcity_rp_admin_reload"
RP.NetAdminCapture = "vcity_rp_admin_capture"
RP.NetAdminResult = "vcity_rp_admin_result"
RP.NetRestart = "vcity_rp_restart_notice"
RP.NetRestartAsk = "vcity_rp_restart_ask"
RP.DefaultSettings = {roleChangeCooldown = 30, respawnDelay = 3, respawnOnRoleChange = true, startingMoney = 1000, salaryInterval = 600, currency = "$"}
RP.Sounds = {
    press = "shitty/tap_depress.wav",
    release = "shitty/tap_release.wav",
    hover = "shitty/tap-resonant.wav"
}
RP.Factions = {
    -- First tab: civilian jobs. "civilian" itself stays the open default role.
    {ID="civilian",Name="Гражданские",Subtitle="",RGB={186,188,186},Roles={
        {ID="civilian",Name="Гражданский"},
        {ID="civilian_trader",Name="Торговец оружием"},
        {ID="civilian_medic",Name="Медик"},
        {ID="civilian_mechanic",Name="Автомеханик"},
        {ID="civilian_gunsmith",Name="Оружейник"}}},
    {ID="usa",Name="США",Subtitle="Вооружённые силы США",RGB={160,175,187},Roles={
        {ID="delta_private",Name="Рядовой"},
        {ID="delta_corporal",Name="Капрал"},
        {ID="delta_sergeant",Name="Сержант"},
        {ID="delta_leader",Name="Командир отряда"}}},
    {ID="rf",Name="ВС РФ",Subtitle="",RGB={165,178,164},Roles={
        {ID="rf_private",Name="Рядовой"},{ID="rf_corporal",Name="Ефрейтор"},
        {ID="rf_sergeant",Name="Сержант"},{ID="rf_junior_lieutenant",Name="Мл. Лейтенант"}}},
    -- Сербский добровольческий корпус «Дрина»: подфракция российской стороны, отдельная вкладка.
    {ID="drina",Name="Дрина",Subtitle="Сербский корпус",RGB={170,170,184},Roles={
        {ID="drina_private",Name="Рядовой"},{ID="drina_corporal",Name="Ефрейтор"},
        {ID="drina_sergeant",Name="Сержант"},{ID="drina_junior_lieutenant",Name="Мл. Лейтенант"},
        {ID="drina_uav",Name="Оператор БПЛА"}}}
}
RP.Roles = {}
RP.RoleOrder = {}
RP.FactionsByID = {}
for _, faction in ipairs(RP.Factions) do
    RP.FactionsByID[faction.ID] = faction
    faction.Color = Color(faction.RGB[1],faction.RGB[2],faction.RGB[3])
    for _, role in ipairs(faction.Roles) do
        role.Faction = faction.ID
        role.Color = faction.Color
        role.DefaultName = role.Name
        RP.Roles[role.ID] = role
        RP.RoleOrder[#RP.RoleOrder+1] = role.ID
    end
end
RP.Roles.civilian.DefaultName = "Гражданский"
-- Role flags: who may craft at a bench and who may sell weapons to other players.
-- Defaults keep both abilities exclusive; admins can grant them to any role.
RP.DefaultFlags = {civilian_gunsmith={craftAccess=true}, civilian_trader={tradeAccess=true}}
RP.CivilianFaction = "civilian"

-- Цепочка открытия ролей: роль открыта, когда на роли «after» отыграно `minutes` минут.
-- Роли без правила открыты всегда. Минуты — рабочая заглушка, до согласования значений.
-- Переопределяется серверным файлом data/vcity_rp/unlocks.json (тот же формат).
RP.DefaultUnlockRules = {
    rf_corporal={after="rf_private",minutes=30}, rf_sergeant={after="rf_corporal",minutes=60},
    rf_junior_lieutenant={after="rf_sergeant",minutes=90},
    delta_corporal={after="delta_private",minutes=30}, delta_sergeant={after="delta_corporal",minutes=60},
    delta_leader={after="delta_sergeant",minutes=90},
    drina_corporal={after="drina_private",minutes=30}, drina_sergeant={after="drina_corporal",minutes=60},
    drina_junior_lieutenant={after="drina_sergeant",minutes=90},
}
RP.Unlocks = table.Copy(RP.DefaultUnlockRules)
RP.LockNWKey = "vcity_rp_lock"

-- Подклассы военных званий: выбираются ПОСЛЕ звания, открыты сразу, применяются при следующем спавне.
-- Экипировка: подкласс переопределяет только заданные поля (weapons, ammo, armorItems, attachments,
-- model, skin, clearWeapons, clearAmmo, fillClips). Не заданные поля берутся из звания.
-- Значения лежат в data/vcity_rp/subclasses.json, ключ — «фракция_подкласс», например «rf_sniper».
RP.Subclasses = {
    {ID="sniper",Name="Снайпер"},
    {ID="assault",Name="Штурмовик"},
    {ID="at",Name="Противотанковый стрелок"},
    {ID="machinegunner",Name="Пулемётчик"},
    {ID="signaller",Name="Связист"},
    {ID="crew",Name="Член экипажа"},
}
RP.SubclassFactions = {usa=true, rf=true, drina=true}
RP.SubNWKey = "vcity_rp_sub"
RP.NetSubclass = "vcity_rp_select_sub"
RP.NetSubResult = "vcity_rp_sub_result"
RP.NetSubAdminGet = "vcity_rp_subadmin_get"
RP.NetSubAdminSave = "vcity_rp_subadmin_save"
RP.NetSubAdminResult = "vcity_rp_subadmin_result"
function RP.SubclassByID(id)
    if not isstring(id) then return nil end
    for _,sub in ipairs(RP.Subclasses) do
        if sub.ID==id then return sub end
    end
    return nil
end
function RP.SubclassAllowed(role)
    return role~=nil and RP.SubclassFactions[role.Faction]==true and role.ID~="drina_uav"
end
-- Текст для F4 и отказа сервера (клиент и сервер используют одну функцию)
function RP.LockMessage(afterId,done,need)
    local after=RP.Roles[afterId]
    local faction=after and RP.FactionsByID[after.Faction]
    local name=after and after.Name or afterId
    local where=faction and (" ("..faction.Name..")") or ""
    return string.format("Закрыто: отыграй %d мин на «%s»%s. Сейчас %d/%d.",need,name,where,done,need)
end

RP.BaseRoles=table.Copy(RP.Roles)
for index,id in ipairs(RP.RoleOrder) do RP.BaseRoles[id].SortOrder=index end
function RP.InstallRoleCatalog(roles)
    local nextRoles,nextOrder={},{}
    for _,faction in ipairs(RP.Factions) do faction.Roles={} end
    for id,cfg in pairs(roles) do
        local faction=RP.FactionsByID[cfg.faction]
        if id==RP.DefaultRole or faction then
            local base=RP.BaseRoles[id]
            local item={ID=id,Name=cfg.name,DefaultName=cfg.name,Faction=cfg.faction,
                SortOrder=cfg.sortOrder or (base and base.SortOrder) or 100,
                Color=faction and faction.Color or Color(180,185,180)}
            nextRoles[id]=item;nextOrder[#nextOrder+1]=id
        end
    end
    table.sort(nextOrder,function(a,b)
        if nextRoles[a].SortOrder==nextRoles[b].SortOrder then return a<b end
        return nextRoles[a].SortOrder<nextRoles[b].SortOrder
    end)
    for _,id in ipairs(nextOrder) do
        local item=nextRoles[id];local faction=RP.FactionsByID[item.Faction]
        if faction then faction.Roles[#faction.Roles+1]=item end
    end
    RP.Roles=nextRoles;RP.RoleOrder=nextOrder
end
function RP.DefaultRoleConfig(id)
    return {
        name=RP.Roles[id].DefaultName, faction=RP.Roles[id].Faction, sortOrder=RP.Roles[id].SortOrder or (RP.BaseRoles[id] and RP.BaseRoles[id].SortOrder) or 100, salary=200, enabled=true,
        craftAccess=RP.DefaultFlags[id] and RP.DefaultFlags[id].craftAccess or false,
        tradeAccess=RP.DefaultFlags[id] and RP.DefaultFlags[id].tradeAccess or false,
        attachments={}, model="", skin=0, bodygroups={},
        health=100, armor=0, armorItems={}, weapons={}, ammo={},
        clearWeapons=true, clearAmmo=true, fillClips=true,
        walkSpeed=100, runSpeed=350, jumpPower=200,
        allowedGroups={}, maxPlayers=0, spawns={}
    }
end
function RP.GetRoleSettings(id)
    if not RP.Roles[id] then id=RP.DefaultRole end
    local source = SERVER and RP.Config or RP.PublicConfig
    return source and source.roles and source.roles[id] or RP.DefaultRoleConfig(id)
end
function RP.GetSettings()
    local source = SERVER and RP.Config or RP.PublicConfig
    return source and source.settings or RP.DefaultSettings
end
function RP.GetRole(ply)
    local id = RP.DefaultRole
    if IsValid(ply) and ply:IsPlayer() then id=ply:GetNW2String(RP.RoleNWKey,RP.DefaultRole) end
    local base = RP.Roles[id] or RP.Roles[RP.DefaultRole]
    local cfg = RP.GetRoleSettings(base.ID)
    local profession=RP.GetProfession and RP.GetProfession(ply) or ""
    local baseName=cfg.name or base.DefaultName
    return {ID=base.ID,Name=profession~="" and profession or baseName,BaseName=baseName,
        Profession=profession,Faction=base.Faction,Color=base.Color}
end
function RP.RoleByID(id)
    local base=RP.Roles[id]
    if not base then return end
    local cfg=RP.GetRoleSettings(id)
    return {ID=id,Name=cfg.name or base.DefaultName,Faction=base.Faction,Color=base.Color}
end
function RP.GetRoleLabel(role)
    if not role then return "Гражданский" end
    if role.ID==RP.DefaultRole then
        if role.Profession and role.Profession~="" then return (role.BaseName or "Гражданский").." / "..role.Profession end
        return role.Name
    end
    if role.Faction==RP.CivilianFaction then
        if role.Profession and role.Profession~="" then return role.Name.." / "..role.Profession end
        return role.Name
    end
    local faction=RP.FactionsByID[role.Faction]
    return (faction and faction.Name or "RP").." / "..role.Name
end

-- Bounded JSON transport. This is data only, never RunString/CompileString.
function RP.WriteJSON(data)
    local raw=util.TableToJSON(data)
    if not raw or #raw>RP.MaxNetJSON then return false end
    net.WriteUInt(#raw,16)
    net.WriteData(raw,#raw)
    return true
end
function RP.ReadJSON(bits)
    if bits and (bits<16 or bits>RP.MaxNetJSON*8+16) then return nil,"Размер запроса." end
    local size=net.ReadUInt(16)
    if size<2 or size>RP.MaxNetJSON then return nil,"Размер JSON." end
    if bits and size*8+16>bits then return nil,"Неполный запрос." end
    local raw=net.ReadData(size)
    if type(raw)~="string" or #raw~=size then return nil,"Неполный JSON." end
    local data=util.JSONToTable(raw,false,true)
    if type(data)~="table" then return nil,"Некорректный JSON." end
    return data
end

RP.NetAdminCreate="vcity_rp_admin_create_role"
RP.NetServices="vcity_rp_services"
RP.NetServicesResult="vcity_rp_services_result"
RP.NetInteraction="vcity_rp_interaction"
RP.NetInteractionAction="vcity_rp_interaction_action"
RP.NetBenchOpen="vcity_rp_bench_open"
RP.NetCraftStart="vcity_rp_craft_start"
RP.NetCraftAction="vcity_rp_craft_action"
RP.NetCraftState="vcity_rp_craft_state"
RP.MoneyNWKey="vcity_rp_money"
function RP.MoneyText(amount)
    return tostring(math.floor(tonumber(amount) or 0)).." "..(RP.GetSettings().currency or "$" )
end

RP.AttachmentPlacements={"sight","mount","barrel","grip","underbarrel","magwell","agsmag"}
function RP.AttachmentPlacementOf(id)
    if type(id)~="string" or not hg or type(hg.attachments)~="table" then return nil end
    for placement,list in pairs(hg.attachments) do
        if type(list)=="table" and list[id] then return placement end
    end
end
function RP.AttachmentCatalog()
    local catalog={}
    for _,placement in ipairs(RP.AttachmentPlacements) do
        local list=hg and hg.attachments and hg.attachments[placement]
        if type(list)=="table" then
            local ids={}
            for id in pairs(list) do if id~="empty" then ids[#ids+1]=id end end
            table.sort(ids)
            catalog[placement]={ids=ids,count=#ids}
        end
    end
    return catalog
end
