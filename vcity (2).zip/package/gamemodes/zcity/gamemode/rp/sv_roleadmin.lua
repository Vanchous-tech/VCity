local RP=VCityRP
util.AddNetworkString(RP.NetAdminCreate)
function RP.CreateRole(name,faction,revision)
    if revision~=RP.ConfigRevision then return false,"Обнови конфиг: другая ревизия." end
    local clean,reason=RP.ValidateProfession(name)
    if not clean then return false,reason end
    if not RP.FactionsByID[faction] then return false,"Выбери существующую фракцию." end
    local count=0;for _ in pairs(RP.Config.roles) do count=count+1 end
    if count>=100 then return false,"Лимит: 100 ролей." end
    local id="custom_"..tostring(os.time()).."_"..tostring(math.random(1000,9999))
    while RP.Config.roles[id] do id=id.."x" end
    local role,err=RP.NormalizeRoleConfig(id,{name=clean,faction=faction,sortOrder=count+1,salary=200})
    if not role then return false,err end
    local config=util.JSONToTable(util.TableToJSON(RP.Config),false,true)
    config.roles[id]=role;config.revision=RP.ConfigRevision+1
    local ok,message=RP.PersistConfig(config)
    if not ok then return false,message end
    RP.Config=config;RP.ConfigRevision=config.revision;RP.InstallRoleCatalog(config.roles)
    RP.SendPublicConfig();hook.Run("VCityRP.ConfigChanged",config)
    return true,id
end
net.Receive(RP.NetAdminCreate,function(bits,ply)
    if not RP.AdminGate(ply,bits,8192,0.5,"create") then return end
    local data,err=RP.ReadJSON(bits)
    if not data then RP.AdminReply(ply,{kind="error",message=err}) return end
    local ok,id=RP.CreateRole(data.name,data.faction,data.revision)
    if not ok then RP.AdminReply(ply,{kind="error",message=id}) return end
    RP.SendAdminRole(ply,id,"created")
end)
