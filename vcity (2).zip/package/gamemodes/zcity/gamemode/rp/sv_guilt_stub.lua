-- SERVER ONLY. Karma stays disabled: this module only keeps the retained gameplay
-- reading the fields it expects, so switching a mode off cannot break a raid.
--
-- Replaces the addon's karma subsystem (libraries/guilt/sv_guilt.lua) which cannot run
-- here: it insists on a round table with name "hmcd" (excluded), writes player fields
-- that nothing fills anymore and, in the worst case, kicks or bans players on low
-- "karma". Everything about it was switched off in 0.2.1, so guilt points are simply
-- not accumulated: RP must never punish a player through a counter nobody maintains.
--
-- Non-lethal consequences of sustained fire are kept: hit reactions, blood loss,
-- pain and animations are driven by organism code and work as before.
local RP=VCityRP
zb = zb or {}
hg = hg or {}

zb.MaximumHarm = zb.MaximumHarm or 10
zb.MaxKarma = zb.MaxKarma or 120
zb.HarmDone = zb.HarmDone or {}      -- victim -> attacker -> harm points (read by the experience library)
zb.GuiltTable = zb.GuiltTable or {}  -- kept for compatibility only; never increases
zb.HarmAttacked = zb.HarmAttacked or {}

-- Punishment entry points of the original subsystem now do nothing but answer honestly.
function RP.AddGuilt(ply,amount)
    return false,"Карма отключена на этом сервере."
end
function RP.GetGuilt(ply)
    if not IsValid(ply) then return 0 end
    return 0
end

-- Harm bookkeeping without consequences: the numbers the retained code reads stay
-- truthful, "HarmDone" still fires so kill phrases and hit reactions keep working.
local function clampHarm(value)
    return math.Clamp(value or 0,0,zb.MaximumHarm)
end
function RP.RecordHarm(attacker,victim,harm)
    if not IsValid(attacker) or not attacker:IsPlayer() then return end
    if not IsValid(victim) then return end
    if not isnumber(harm) or harm<=0 then return end
    victim = hg.GetCurrentCharacter and (hg.GetCurrentCharacter(victim) or victim) or victim
    victim = hg.RagdollOwner and (hg.RagdollOwner(victim) or victim) or victim
    if victim==attacker then return end
    zb.HarmDone[victim] = zb.HarmDone[victim] or {}
    local total=clampHarm((zb.HarmDone[victim][attacker] or 0)+harm)
    zb.HarmDone[victim][attacker]=total
    zb.HarmAttacked[attacker]=(zb.HarmAttacked[attacker] or 0)+harm
    hook.Run("HarmDone",attacker,victim,total/zb.MaximumHarm)
end

-- Non-lethal hit consequences (hitgroups, wounds, pain) stay untouched on purpose.
hook.Add("Player Spawn","VCityRP.HarmReset",function(ply)
    zb.HarmDone[ply]={}
    zb.GuiltTable[ply]={}
end)
hook.Add("PlayerDisconnected","VCityRP.HarmReset",function(ply)
    zb.HarmDone[ply]=nil
    zb.GuiltTable[ply]=nil
    zb.HarmAttacked[ply]=nil
end)
