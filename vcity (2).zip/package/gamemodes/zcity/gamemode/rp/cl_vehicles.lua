-- V-City RP 0.6.1 — CLIENT. Меню спавнеров транспорта (vcity_rp_veh_menu, суперадмин).
-- Встаньте/посмотрите на место, откройте меню, выберите машину справа и нажмите «Поставить по прицелу».
local RP = VCityRP
local frame

local SIDES = { { "Все", "" }, { "США", "usa" }, { "РФ и Дрина", "ru" } }
local SIDE_TEXT = { [""] = "все", usa = "США", ru = "РФ+Дрина" }

local function Act(act, data)
    net.Start("vcity_rp_veh_act")
    net.WriteString(act)
    RP.WriteJSON(data or { x = 1 })
    net.SendToServer()
end

local function ClassList()
    local out = {}
    for class, ent in pairs(scripted_ents.GetList()) do
        local t = ent.t or ent
        if t.Spawnable or string.StartWith(class, "lvs_") or string.StartWith(class, "glide") then
            out[#out + 1] = { class = class, name = tostring(t.PrintName or class), cat = tostring(t.Category or "") }
        end
    end
    table.sort(out, function(a, b) return a.class < b.class end)
    return out
end

local function Open(data)
    if IsValid(frame) then frame.Refresh(data) frame:MakePopup() return end

    frame = vgui.Create("DFrame")
    frame:SetSize(math.min(ScrW() - 40, 980), math.min(ScrH() - 40, 560))
    frame:Center()
    frame:SetTitle("Спавнеры транспорта  —  смотрите на место, выберите машину, «Поставить по прицелу»")
    frame:MakePopup()

    local left = vgui.Create("DPanel", frame)
    left:Dock(LEFT)
    left:SetWide(frame:GetWide() * 0.52)
    left:DockMargin(0, 0, 6, 0)
    left.Paint = nil

    local list = vgui.Create("DListView", left)
    list:Dock(FILL)
    list:SetMultiSelect(false)
    for _, c in ipairs({ { "#", 30 }, { "Название / класс", 190 }, { "Респавн", 60 }, { "Брошена", 60 }, { "Сторона", 70 }, { "Состояние", 80 } }) do
        local col = list:AddColumn(c[1])
        col:SetFixedWidth(c[2])
    end

    local edit = vgui.Create("DPanel", left)
    edit:Dock(BOTTOM)
    edit:SetTall(120)
    edit:DockMargin(0, 6, 0, 0)
    edit.Paint = nil

    local function selected()
        local line = list:GetSelectedLine() and list:GetLine(list:GetSelectedLine())
        return line and line.Spawner
    end

    local function field(parent, text, x, y, w, default)
        local l = vgui.Create("DLabel", parent) l:SetPos(x, y) l:SetSize(w, 14) l:SetText(text) l:SetDark(false)
        local e = vgui.Create("DTextEntry", parent) e:SetPos(x, y + 15) e:SetSize(w, 22) e:SetText(default or "")
        return e
    end

    local eDelay = field(edit, "Респавн, сек", 0, 0, 90, "300")
    local eAbandon = field(edit, "Брошена, сек (0 = нет)", 96, 0, 120, "0")
    local eLabel = field(edit, "Название", 222, 0, 150, "")
    local sideBox = vgui.Create("DComboBox", edit)
    sideBox:SetPos(0, 56) sideBox:SetSize(110, 22)
    for _, s in ipairs(SIDES) do sideBox:AddChoice(s[1], s[2]) end
    sideBox:ChooseOptionID(1)
    local sideLabel = vgui.Create("DLabel", edit) sideLabel:SetPos(0, 42) sideLabel:SetSize(110, 14) sideLabel:SetText("Кто может сесть") sideLabel:SetDark(false)

    local function btn(text, x, y, w, fn)
        local b = vgui.Create("DButton", edit)
        b:SetPos(x, y) b:SetSize(w, 24) b:SetText(text) b.DoClick = fn
        return b
    end

    btn("Применить к выбранному", 116, 56, 160, function()
        local s = selected()
        if not s then return end
        local _, side = sideBox:GetSelected()
        Act("update", { id = s.id, delay = tonumber(eDelay:GetValue()) or 300, abandon = tonumber(eAbandon:GetValue()) or 0,
            label = eLabel:GetValue(), side = side or "" })
    end)
    btn("Вкл/выкл", 282, 56, 90, function() local s = selected() if s then Act("set", { id = s.id, field = "enabled", value = not s.enabled }) end end)
    btn("Возродить сейчас", 0, 90, 130, function() local s = selected() if s then Act("respawn", { id = s.id }) end end)
    btn("Перенести (по прицелу)", 136, 90, 150, function() local s = selected() if s then Act("move", { id = s.id }) end end)
    btn("Удалить", 292, 90, 80, function() local s = selected() if s then Act("remove", { id = s.id }) end end)

    list.OnRowSelected = function(_, _, line)
        local s = line.Spawner
        eDelay:SetValue(tostring(s.delay)) eAbandon:SetValue(tostring(s.abandon)) eLabel:SetValue(s.label or "")
        for i, side in ipairs(SIDES) do if side[2] == s.side then sideBox:ChooseOptionID(i) end end
    end

    -- правая часть: каталог
    local right = vgui.Create("DPanel", frame)
    right:Dock(FILL)
    right.Paint = nil

    local search = vgui.Create("DTextEntry", right)
    search:Dock(TOP)
    search:SetPlaceholderText("Поиск машины (класс или название)…")

    local classes = ClassList()
    local cl = vgui.Create("DListView", right)
    cl:Dock(FILL)
    cl:DockMargin(0, 6, 0, 6)
    cl:SetMultiSelect(false)
    cl:AddColumn("Класс") cl:AddColumn("Название") cl:AddColumn("Категория")

    local function fill()
        cl:Clear()
        local q = string.lower(search:GetValue() or "")
        local shown = 0
        for _, c in ipairs(classes) do
            if q == "" or string.find(string.lower(c.class .. " " .. c.name), q, 1, true) then
                cl:AddLine(c.class, c.name, c.cat)
                shown = shown + 1
                if shown >= 400 then break end
            end
        end
    end
    search.OnChange = fill
    fill()

    local manual = vgui.Create("DTextEntry", right)
    manual:Dock(BOTTOM)
    manual:SetPlaceholderText("…или впишите класс вручную")
    manual:DockMargin(0, 0, 0, 6)

    local place = vgui.Create("DButton", right)
    place:Dock(BOTTOM)
    place:SetTall(34)
    place:DockMargin(0, 0, 0, 6)
    place:SetText("Поставить по прицелу")
    place.DoClick = function()
        local line = cl:GetSelectedLine() and cl:GetLine(cl:GetSelectedLine())
        local class = manual:GetValue() ~= "" and manual:GetValue() or (line and line:GetColumnText(1))
        if not class or class == "" then return notification.AddLegacy("Выберите машину справа.", NOTIFY_ERROR, 3) end
        local _, side = sideBox:GetSelected()
        Act("add", { class = class, label = eLabel:GetValue(), delay = tonumber(eDelay:GetValue()) or 300,
            abandon = tonumber(eAbandon:GetValue()) or 0, side = side or "" })
    end

    frame.Refresh = function(d)
        local keep = selected() and selected().id
        list:Clear()
        for _, s in ipairs(d.spawners or {}) do
            local line = list:AddLine(s.id, (s.label ~= "" and s.label or s.class) .. (s.enabled and "" or " (выкл)"), s.delay, s.abandon, SIDE_TEXT[s.side] or "все", s.state)
            line.Spawner = s
            if keep == s.id then list:SelectItem(line) end
        end
    end
    frame.Refresh(data)
end

net.Receive("vcity_rp_veh_open", function()
    local data = RP.ReadJSON(nil)
    if data then Open(data) end
end)
