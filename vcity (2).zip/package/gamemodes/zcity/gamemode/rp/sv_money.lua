-- Durable server-owned wallet ledger. One validated write contains both sides of a transfer.
local RP=VCityRP
RP.WalletPath="vcity_rp/wallets.json"
RP.MaxMoney=2000000000
local function integer(n) return type(n)=="number" and n==n and n==math.floor(n) and n>=0 and n<=RP.MaxMoney end
local raw=file.Read(RP.WalletPath,"DATA")
if raw==nil then
    RP.Wallets={version=1,accounts={}} -- no file yet: a fresh ledger
else
    -- A file that exists but does not parse is NOT an empty ledger: keep the economy off
    -- (otherwise the first new account would overwrite the file and its .previous backup).
    RP.Wallets=util.JSONToTable(raw,false,true)
end
RP.MoneyReady=type(RP.Wallets)=="table" and RP.Wallets.version==1 and type(RP.Wallets.accounts)=="table"
if RP.MoneyReady then
    for id,balance in pairs(RP.Wallets.accounts) do
        if type(id)~="string" or not id:match("^%d+$") or #id>20 or not integer(balance) then RP.MoneyReady=false;break end
    end
end
if not RP.MoneyReady then ErrorNoHalt("[V-City RP] Invalid wallets.json; economy disabled, file preserved. Restore data/vcity_rp/wallets.previous.json over wallets.json and restart.\n") end
local function accountID(ply)
    if not IsValid(ply) or not ply:IsPlayer() or ply:IsBot() then return end
    local id=ply:SteamID64()
    if type(id)~="string" or not id:match("^%d+$") or #id>20 or #id<15 then return end
    return id
end
function RP.PersistWallets(ledger)
    local data=util.TableToJSON(ledger,true)
    if not data or #data>8000000 then return false,"Ledger too large." end
    local ok,err=pcall(function()
        file.CreateDir("vcity_rp")
        file.Write("vcity_rp/wallets.pending.json",data)
        if file.Read("vcity_rp/wallets.pending.json","DATA")~=data then error("Temporary write failed.") end
        local old=file.Read(RP.WalletPath,"DATA")
        if old then
            file.Write("vcity_rp/wallets.previous.json",old)
            if file.Read("vcity_rp/wallets.previous.json","DATA")~=old then error("Backup write failed.") end
        end
        file.Write(RP.WalletPath,data)
        if file.Read(RP.WalletPath,"DATA")~=data then
            if old then file.Write(RP.WalletPath,old) end
            error("Wallet write failed.")
        end
    end)
    file.Delete("vcity_rp/wallets.pending.json")
    return ok,ok and "" or tostring(err)
end
function RP.SyncMoney(ply)
    local id=accountID(ply)
    if id and RP.MoneyReady then ply:SetNW2Int(RP.MoneyNWKey,RP.Wallets.accounts[id] or 0) end
end
function RP.InitWallet(ply)
    local id=accountID(ply)
    if not id or not RP.MoneyReady then return false end
    if RP.Wallets.accounts[id]==nil then
        local copy=table.Copy(RP.Wallets);copy.accounts[id]=RP.GetSettings().startingMoney
        local ok=RP.PersistWallets(copy)
        if not ok then return false end
        RP.Wallets=copy
    end
    RP.SyncMoney(ply)
    ply.VCityRPNextSalary=CurTime()+RP.GetSettings().salaryInterval
    return true
end
function RP.TransferMoney(from,to,amount)
    if not RP.MoneyReady then return false,"Экономика недоступна; проверь ledger на сервере." end
    if from==to or not integer(amount) or amount<1 then return false,"Нужна целая положительная сумма." end
    local a,b=accountID(from),accountID(to)
    if not a or not b or a==b then return false,"Недоступный кошелёк." end
    local balances=RP.Wallets.accounts
    if balances[a]==nil or balances[b]==nil then return false,"Кошелёк ещё загружается." end
    if balances[a]<amount then return false,"Недостаточно денег." end
    if balances[b]>RP.MaxMoney-amount then return false,"Лимит кошелька получателя." end
    local copy=table.Copy(RP.Wallets)
    copy.accounts[a]=copy.accounts[a]-amount;copy.accounts[b]=copy.accounts[b]+amount
    local ok,err=RP.PersistWallets(copy)
    if not ok then return false,"Не удалось сохранить перевод: "..tostring(err) end
    RP.Wallets=copy;RP.SyncMoney(from);RP.SyncMoney(to)
    return true
end
function RP.MarketSale(trader,buyer,price,cost)
    if not RP.MoneyReady then return false,"Экономика недоступна." end
    if not integer(price) or price<1 or not integer(cost) then return false,"Неверная цена." end
    if price<cost then return false,"Цена ниже закупки: продажа в убыток запрещена." end
    local a,b=accountID(trader),accountID(buyer)
    if not a or not b or a==b then return false,"Недоступный кошелёк." end
    local balances=RP.Wallets.accounts
    if balances[a]==nil or balances[b]==nil then return false,"Кошелёк ещё загружается." end
    if balances[b]<price then return false,"У покупателя недостаточно денег." end
    local profit=price-cost
    if balances[a]>RP.MaxMoney-profit then return false,"Лимит кошелька продавца." end
    local copy=table.Copy(RP.Wallets)
    copy.accounts[b]=copy.accounts[b]-price
    copy.accounts[a]=copy.accounts[a]+profit
    local ok,err=RP.PersistWallets(copy)
    if not ok then return false,"Не удалось сохранить сделку: "..tostring(err) end
    RP.Wallets=copy;RP.SyncMoney(trader);RP.SyncMoney(buyer)
    return true,profit
end
function RP.PaySalary(ply)
    local id=accountID(ply)
    if not id or not RP.MoneyReady or not ply:Alive() then return false end
    local amount=RP.GetRoleSettings(RP.GetRole(ply).ID).salary or 0
    local balance=RP.Wallets.accounts[id]
    if not balance or amount<=0 or balance>RP.MaxMoney-amount then return false end
    local copy=table.Copy(RP.Wallets);copy.accounts[id]=balance+amount
    if not RP.PersistWallets(copy) then return false end
    RP.Wallets=copy;RP.SyncMoney(ply);ply:ChatPrint("Зарплата: +"..RP.MoneyText(amount))
    return true
end
hook.Add("PlayerInitialSpawn","VCityRP.Wallet",function(ply)
    timer.Simple(1.2,function() if IsValid(ply) then RP.InitWallet(ply) end end)
end)
timer.Create("VCityRP.Salaries",10,0,function()
    for _,ply in ipairs(player.GetAll()) do
        if (ply.VCityRPNextSalary or math.huge)<=CurTime() then
            ply.VCityRPNextSalary=CurTime()+RP.GetSettings().salaryInterval
            RP.PaySalary(ply)
        end
    end
end)
