-- V-City RP 0.6.0 — SERVER ONLY. Статистика игроков и сторон за период (по умолчанию 14 дней).
-- Считается: убийства, смерти, захваты точек, время в игре, «свои» убийства (TK).
-- Стороны: usa, ru (ВС РФ + Дрина), civ. Период начинается в понедельник 00:00 по времени сервера
-- (опорная дата RP.StatsAnchor) и длится vcity_rp_stats_days дней. По окончании итоги пишутся в
-- data/vcity_rp/stats/period_ГГГГ-ММ-ДД.json, объявляются в чате, счётчики и точки сбрасываются.
-- Игрокам: !stats, !top (или консоль vcity_rp_stats, vcity_rp_stats_top). Суперадмин: vcity_rp_stats_close.
local RP = VCityRP

RP.StatsFile = "vcity_rp/stats_current.json"
RP.StatsDir = "vcity_rp/stats"
RP.StatsAnchor = os.time({ year = 2026, month = 10, day = 19, hour = 0 }) -- понедельник
local cvDays = CreateConVar("vcity_rp_stats_days", "14", FCVAR_ARCHIVE, "Длина периода статистики, дней")

local SIDE_NAMES = { usa = "США", ru = "РФ и Дрина", civ = "Гражданские" }
local KEYS = { "kills", "deaths", "captures", "time", "tk" }

-- Начало периода для момента t (чистая функция)
function RP.StatsPeriodStart(t, anchor, days)
    local len = math.max(days, 1) * 86400
    return anchor + math.floor((t - anchor) / len) * len
end

local function PeriodStart(t) return RP.StatsPeriodStart(t or os.time(), RP.StatsAnchor, cvDays:GetInt()) end
local function PeriodEnd() return (RP.Stats and RP.Stats.period or PeriodStart()) + math.max(cvDays:GetInt(), 1) * 86400 end

local function NewStats(start)
    return { period = start or PeriodStart(), players = {}, sides = { usa = {}, ru = {}, civ = {} } }
end

local dirty, nextSave = false, 0

local function Load()
    local raw = file.Read(RP.StatsFile, "DATA")
    -- ignoreConversions=true: players[] is keyed by SteamID64 strings
    local parsed = raw and raw ~= "" and util.JSONToTable(raw, false, true) or nil
    if istable(parsed) and tonumber(parsed.period) and istable(parsed.players) and istable(parsed.sides) then
        RP.Stats = parsed
        RP.Stats.period = tonumber(parsed.period)
        for _, s in ipairs({ "usa", "ru", "civ" }) do RP.Stats.sides[s] = RP.Stats.sides[s] or {} end
    else
        RP.Stats = NewStats()
    end
end

local function Save()
    file.CreateDir("vcity_rp")
    file.Write(RP.StatsFile, util.TableToJSON(RP.Stats, true))
    dirty = false
end

function RP.SideOfPlayer(ply)
    local role = IsValid(ply) and RP.GetRole and RP.GetRole(ply)
    if not role then return "civ" end
    local map = RP.SideOf or { usa = "usa", rf = "ru", drina = "ru" }
    return map[role.Faction] or "civ"
end

local function Entry(ply)
    local steam = ply:SteamID64()
    if not steam then return end
    local e = RP.Stats.players[steam]
    if not e then
        e = { name = ply:Nick() }
        RP.Stats.players[steam] = e
    end
    e.name = string.sub(ply:Nick(), 1, 40)
    return e
end

function RP.StatAdd(ply, key, n)
    if not IsValid(ply) or ply:IsBot() or not RP.Stats then return end
    local e = Entry(ply)
    if not e then return end
    e[key] = (tonumber(e[key]) or 0) + (n or 1)
    dirty = true
end

function RP.StatSide(side, key, n)
    if not RP.Stats or not RP.Stats.sides[side] then return end
    local s = RP.Stats.sides[side]
    s[key] = (tonumber(s[key]) or 0) + (n or 1)
    dirty = true
end

-- ================= сбор =================
hook.Add("PlayerDeath", "VCityRP.StatsDeath", function(victim, _, attacker)
    if not IsValid(victim) or not victim:IsPlayer() then return end
    local vSide = RP.SideOfPlayer(victim)
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
        local aSide = RP.SideOfPlayer(attacker)
        if aSide == vSide and aSide ~= "civ" then
            RP.StatAdd(attacker, "tk", 1)
            if RP.Log then RP.Log("tk", RP.Who(attacker) .. " убил своего: " .. RP.Who(victim)) end
        else
            RP.StatAdd(attacker, "kills", 1)
            RP.StatSide(aSide, "kills", 1)
        end
    end
    RP.StatAdd(victim, "deaths", 1)
    RP.StatSide(vSide, "deaths", 1)
end)

timer.Create("VCityRP.StatsTime", 60, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and not ply:IsBot() and ply:Alive() then
            RP.StatAdd(ply, "time", 60)
            RP.StatSide(RP.SideOfPlayer(ply), "time", 60)
        end
    end
end)

-- захваты считает модуль точек
hook.Add("VCityRP.PointCaptured", "VCityRP.StatsCapture", function(_, side, players)
    for _, ply in ipairs(players or {}) do RP.StatAdd(ply, "captures", 1) end
    RP.StatSide(side, "captures", 1)
end)

-- ================= итоги периода =================
local function Score(t) return (tonumber(t.captures) or 0) * 10 + (tonumber(t.kills) or 0) end

local function Top(key, limit)
    local list = {}
    for steam, e in pairs(RP.Stats.players) do
        if (tonumber(e[key]) or 0) > 0 then list[#list + 1] = { steam = steam, name = e.name or steam, value = e[key] } end
    end
    table.sort(list, function(a, b) return a.value > b.value end)
    local out = {}
    for i = 1, math.min(limit or 5, #list) do out[i] = list[i] end
    return out
end

function RP.StatsClosePeriod(reason)
    local stats = RP.Stats
    local usa, ru = Score(stats.sides.usa), Score(stats.sides.ru)
    local winner = usa > ru and "usa" or (ru > usa and "ru" or nil)

    local archive = {
        period = stats.period, closed = os.time(), reason = reason or "срок", winner = winner,
        sides = stats.sides, players = stats.players,
        topKills = Top("kills", 10), topCaptures = Top("captures", 10),
    }
    file.CreateDir("vcity_rp")
    file.CreateDir(RP.StatsDir)
    file.Write(RP.StatsDir .. "/period_" .. os.date("%Y-%m-%d", stats.period) .. ".json", util.TableToJSON(archive, true))

    local lines = { "=== ИТОГИ ПЕРИОДА (" .. os.date("%d.%m", stats.period) .. " – " .. os.date("%d.%m", os.time()) .. ") ===" }
    lines[#lines + 1] = winner and ("Победила сторона: " .. SIDE_NAMES[winner] .. " (очки: США " .. usa .. ", РФ/Дрина " .. ru .. ")") or ("Ничья (очки: США " .. usa .. ", РФ/Дрина " .. ru .. ")")
    local k, c = Top("kills", 1)[1], Top("captures", 1)[1]
    if k then lines[#lines + 1] = "Больше всех убийств: " .. k.name .. " (" .. k.value .. ")" end
    if c then lines[#lines + 1] = "Больше всех захватов: " .. c.name .. " (" .. c.value .. ")" end
    for _, line in ipairs(lines) do PrintMessage(HUD_PRINTTALK, line) end
    if RP.Log then RP.Log("stats", "период закрыт: " .. (winner or "ничья") .. " США=" .. usa .. " РФ=" .. ru) end

    RP.Stats = NewStats()
    Save()
    hook.Run("VCityRP.StatsPeriodEnded", archive)
end

timer.Create("VCityRP.StatsRollover", 30, 0, function()
    if os.time() >= PeriodEnd() then RP.StatsClosePeriod("срок") end
    if dirty and CurTime() >= nextSave then
        nextSave = CurTime() + 60
        Save()
    end
end)
hook.Add("ShutDown", "VCityRP.StatsShutdown", function() if dirty then Save() end end)
hook.Add("PlayerDisconnected", "VCityRP.StatsDisc", function() if dirty then Save() end end)

Load()
if os.time() >= PeriodEnd() then timer.Simple(5, function() RP.StatsClosePeriod("срок (сервер был выключен)") end) end

-- ================= просмотр =================
local function FmtTime(sec)
    sec = tonumber(sec) or 0
    return string.format("%dч %02dм", math.floor(sec / 3600), math.floor(sec % 3600 / 60))
end

local function SideLine(side)
    local s = RP.Stats.sides[side] or {}
    return string.format("%s: убийств %d, потерь %d, захватов %d (очки %d)", SIDE_NAMES[side], s.kills or 0, s.deaths or 0, s.captures or 0, Score(s))
end

local function Show(ply)
    local e = RP.Stats.players[ply:SteamID64() or ""] or {}
    local days = math.max(math.ceil((PeriodEnd() - os.time()) / 86400), 0)
    local lines = {
        "— Статистика (до конца периода: " .. days .. " дн.) —",
        string.format("Вы: убийств %d, смертей %d, захватов %d, в игре %s", e.kills or 0, e.deaths or 0, e.captures or 0, FmtTime(e.time)),
        SideLine("usa"), SideLine("ru"),
    }
    for _, line in ipairs(lines) do ply:ChatPrint(line) end
end

local function ShowTop(ply)
    ply:ChatPrint("— Лучшие за период —")
    for _, key in ipairs({ "kills", "captures" }) do
        local top = Top(key, 5)
        local parts = {}
        for i, t in ipairs(top) do parts[#parts + 1] = i .. ". " .. t.name .. " (" .. t.value .. ")" end
        ply:ChatPrint((key == "kills" and "Убийства: " or "Захваты: ") .. (#parts > 0 and table.concat(parts, "  ") or "пока никого"))
    end
end

concommand.Add("vcity_rp_stats", function(ply) if IsValid(ply) then Show(ply) end end)
concommand.Add("vcity_rp_stats_top", function(ply) if IsValid(ply) then ShowTop(ply) end end)

hook.Add("PlayerSay", "VCityRP.StatsChat", function(ply, text)
    local t = string.lower(string.Trim(text or ""))
    if t == "!stats" or t == "/stats" or t == "!стат" or t == "/стат" then Show(ply) return "" end
    if t == "!top" or t == "/top" or t == "!топ" or t == "/топ" then ShowTop(ply) return "" end
end)

concommand.Add("vcity_rp_stats_close", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    RP.StatsClosePeriod("вручную")
end)
