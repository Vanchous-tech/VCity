-- Superadmin form. Clients never write DATA; the server validates and writes the JSON.
local RP=VCityRP
local function copy(data) return util.JSONToTable(util.TableToJSON(data),false,true) end
local function tell(message) notification.AddLegacy(message,NOTIFY_ERROR,5);RP.AdminStatus=message end
local function parseJSON(entry,label)
    local value=util.JSONToTable(entry:GetValue(),false,true)
    if type(value)~="table" then error(label..": нужен JSON-массив или объект.",0) end
    return value
end
local function readSpawnPoints(entry)
    local points=parseJSON(entry,"Спавны")
    local count=0
    for key in pairs(points) do
        if type(key)~="number" or key<1 or key~=math.floor(key) then error("Спавны: нужен массив точек [{x,y,z,...}], а не одна точка.",0) end
        count=count+1
    end
    if count~=#points then error("Спавны: массив с пропусками.",0) end
    return points
end
local function lines(raw)
    local out={}
    for value in raw:gmatch("[^\r\n,]+") do
        local trimmed=value:match("^%s*(.-)%s*$")
        if trimmed~="" then out[#out+1]=trimmed end
    end
    return out
end
local function ammoText(data)
    local rows={};for name,count in pairs(data) do rows[#rows+1]=name.." = "..count end
    table.sort(rows);return table.concat(rows,"\n")
end
local function readAmmo(raw)
    local out={}
    for line in raw:gmatch("[^\r\n]+") do
        if not line:match("^%s*$") then
            local name,count=line:match("^%s*(.-)%s*=%s*(%d+)%s*$")
            if not name or name=="" then error("Патроны: формат ‘тип = количество’.",0) end
            out[name]=tonumber(count)
        end
    end
    return out
end
local function readNumber(entry,label)
    local n=tonumber(entry:GetValue())
    if not n or n~=n or n==math.huge or n==-math.huge then error(label..": нужно число.",0) end
    return n
end
local function setPending(value)
    RP.AdminPending=value
    if value then timer.Create("VCityRP.AdminTimeout",5,1,function() RP.AdminPending=false;tell("Нет ответа на запрос редактора.") end)
    else timer.Remove("VCityRP.AdminTimeout") end
end
local function loadRole(id)
    setPending(true);RP.AdminStatus="Загрузка..."
    net.Start(RP.NetAdminGet);net.WriteString(id);net.SendToServer()
end
-- ===== Помощники редактора: списки для выбора, поле выбора, предпросмотр =====
local BUILTIN_WEAPONS={"weapon_pistol","weapon_357","weapon_smg1","weapon_ar2","weapon_shotgun","weapon_crossbow","weapon_rpg","weapon_frag","weapon_crowbar","weapon_stunstick"}
local function weaponCatalog()
    local out,seen={}, {}
    for _,t in ipairs(weapons.GetList() or {}) do
        local id=t.ClassName
        if isstring(id) and id:find("^weapon_") and not seen[id] then
            seen[id]=true
            local name=(isstring(t.PrintName) and t.PrintName~="") and t.PrintName or id
            out[#out+1]={id=id,label=name.."  ["..id.."]"}
        end
    end
    for _,id in ipairs(BUILTIN_WEAPONS) do
        if not seen[id] then seen[id]=true;out[#out+1]={id=id,label=id} end
    end
    table.sort(out,function(a,b) return a.label<b.label end)
    return out
end
local function armorCatalog()
    local out={}
    for part,list in pairs(hg and hg.armor or {}) do
        if istable(list) then
            for id in pairs(list) do if isstring(id) then out[#out+1]={id=id,label=tostring(part)..": "..id} end end
        end
    end
    table.sort(out,function(a,b) return a.label<b.label end)
    return out
end
local function attachmentCatalog()
    local out={}
    local catalog=RP.AttachmentCatalog and RP.AttachmentCatalog() or {}
    for placement,data in pairs(catalog) do
        for _,id in ipairs(data.ids or {}) do out[#out+1]={id=id,label=placement..": "..id} end
    end
    table.sort(out,function(a,b) return a.label<b.label end)
    return out
end
local function styleEntry(field)
    field.Paint=function(self,pw,ph) draw.RoundedBox(0,0,0,pw,ph,RP.UI.row);self:DrawTextEntryText(RP.UI.text,RP.UI.selection,RP.UI.text) end
end
-- Окно выбора с поиском. onPick вызывается на каждый клик, окно закрывается кнопкой «Готово».
local function openPicker(title,items,onPick)
    if #items==0 then tell("Каталог недоступен на клиенте: введи ID вручную.") return end
    local pw,ph=400,500
    local f=vgui.Create("DFrame");f:SetSize(pw,ph);f:Center();f:SetTitle("");f:ShowCloseButton(false);f:SetDraggable(true);f:MakePopup()
    f.Paint=function(self,w2,h2)
        draw.RoundedBox(0,0,0,w2,h2,RP.UI.bg);surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,w2,h2,1)
        draw.SimpleText(title,"VCityRP.Body",14,14,RP.UI.text)
    end
    local done=RP.UIButton(f,"Готово",function() f:Close() end);done:SetPos(pw-108,8);done:SetSize(94,28)
    local search=vgui.Create("DTextEntry",f);search:SetPos(14,46);search:SetSize(pw-28,26);search:SetFont("VCityRP.Body");styleEntry(search)
    search:SetPlaceholderText("Поиск")
    local list=vgui.Create("DScrollPanel",f);list:SetPos(14,82);list:SetSize(pw-28,ph-96)
    local function fill()
        local canvas=list:GetCanvas();canvas:Clear()
        local q=string.lower(search:GetValue());local y,shown=0,0
        for _,item in ipairs(items) do
            if q=="" or string.find(string.lower(item.label),q,1,true) then
                shown=shown+1
                if shown>250 then break end
                local b=RP.UIButton(canvas,item.label,function() onPick(item) end)
                b:SetPos(0,y);b:SetSize(pw-52,26);y=y+28
            end
        end
        canvas:SetTall(y+4)
    end
    search.OnChange=fill;fill()
    search:RequestFocus()
end
local function appendLine(field,text)
    local current=field:GetValue()
    for line in current:gmatch("[^\r\n]+") do
        if line:match("^%s*(.-)%s*$")==text then return false end
    end
    field:SetText(current..((current=="" or current:sub(-1)=="\n") and "" or "\n")..text)
    if field.OnChange then field:OnChange() end
    return true
end
-- Предпросмотр модели: обновляется сам при изменении поля модели.
local function modelPreview(parent,x,y,w,h,modelField,skinField)
    local panel=vgui.Create("DModelPanel",parent);panel:SetPos(x,y);panel:SetSize(w,h)
    panel.LastModel=nil
    function panel:LayoutEntity(ent) end
    function panel:Think()
        local m=modelField:GetValue();local s=tonumber(skinField:GetValue()) or 0
        if m~=self.LastModel then
            self.LastModel=m
            if m~="" and util.IsValidModel(m) then
                self:SetModel(m)
                local ent=self.Entity
                if IsValid(ent) then
                    local mn,mx=ent:GetRenderBounds()
                    self:SetCamPos(Vector(80,60,(mn.z+mx.z)/2+8));self:SetLookAt((mn+mx)/2);self:SetFOV(40)
                end
            else
                self:SetModel("models/error.mdl")
            end
        end
        if IsValid(self.Entity) then self.Entity:SetSkin(math.max(0,math.floor(s))) end
    end
    return panel
end
local NUMBERS={"health","armor","skin","walkSpeed","runSpeed","jumpPower","maxPlayers","salary"}
local FLAGS={"enabled","clearWeapons","clearAmmo","fillClips","craftAccess","tradeAccess"}
local COPYABLE={"health","armor","armorItems","weapons","ammo","attachments","clearWeapons","clearAmmo","fillClips","walkSpeed","runSpeed","jumpPower","model","skin","bodygroups"}
local IMPORTABLE={"name","enabled","allowedGroups","maxPlayers","salary","craftAccess","tradeAccess","attachments","model","skin","bodygroups","health","armor","armorItems","weapons","ammo","clearWeapons","clearAmmo","fillClips","walkSpeed","runSpeed","jumpPower"}
local TABS={{"main","Основное"},{"look","Внешность"},{"gear","Снаряжение"},{"spawns","Спавны"},{"server","Сервер"},{"json","JSON"}}
function RP.OpenAdminEditor()
    if not LocalPlayer():IsSuperAdmin() then tell("Редактор доступен только суперадмину.") return end
    if IsValid(RP.AdminFrame) then RP.AdminFrame:MakePopup() return end
    local w,h=math.min(900,ScrW()-32),math.min(740,ScrH()-32)
    local frame=vgui.Create("DFrame");RP.AdminFrame=frame
    frame:SetSize(w,h);frame:Center();frame:SetTitle("");frame:ShowCloseButton(false);frame:SetDraggable(false);frame:MakePopup()
    frame.OnRemove=function(self) if RP.AdminFrame==self then RP.AdminFrame=nil end end
    local dirty=false
    local pendingCopy
    frame.Paint=function(self,pw,ph)
        draw.RoundedBox(0,0,0,pw,ph,RP.UI.bg)
        surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,pw,ph,1)
        draw.SimpleText("Конфиг сервера","VCityRP.Title",20,17,RP.UI.text)
        draw.SimpleText("garrysmod/data/"..RP.ConfigPath,"VCityRP.Small",20,48,RP.UI.muted)
        draw.SimpleText(RP.AdminStatus or "","VCityRP.Small",20,ph-24,RP.UI.muted)
        if dirty then draw.SimpleText("● есть несохранённые изменения","VCityRP.Small",pw-20,ph-24,RP.UI.accentText,TEXT_ALIGN_RIGHT) end
    end
    local close=RP.UIButton(frame,"X",function()
        if dirty then Derma_Query("Есть несохранённые изменения. Закрыть без сохранения?","V-City RP","Закрыть",function() frame:Close() end,"Отмена")
        else frame:Close() end
    end);close:SetPos(w-50,15);close:SetSize(30,28)
    local create=RP.UIButton(frame,"+ Новая роль",function() RP.OpenRoleCreator() end);create:SetPos(w-205,15);create:SetSize(145,28)
    local workshop=RP.UIButton(frame,"Мастерская",function() RP.OpenWorkshopAdmin() end);workshop:SetPos(w-340,15);workshop:SetSize(128,28)
    local subs=RP.UIButton(frame,"Подклассы",function() RP.OpenSubclassEditor() end);subs:SetPos(w-475,15);subs:SetSize(128,28)
    local select=vgui.Create("DComboBox",frame);select:SetPos(20,75);select:SetSize(w-320,28)
    select:SetFont("VCityRP.Body")
    local selected=RP.DefaultRole
    local function fillSelect()
        select:Clear()
        for _,id in ipairs(RP.RoleOrder) do select:AddChoice(RP.GetRoleLabel(RP.RoleByID(id)),id) end
        if RP.Roles[selected] then select:SetValue(RP.GetRoleLabel(RP.RoleByID(selected))) end
    end
    fillSelect()
    frame.RefreshRoles=fillSelect
    local function reload(id)
        pendingCopy=nil;dirty=false;loadRole(id)
    end
    local function guarded(action)
        if not dirty then return action() end
        Derma_Query("Есть несохранённые изменения. Продолжить без сохранения?","V-City RP","Продолжить",action,"Отмена")
    end
    select.OnSelect=function(self,index,label,id)
        if id==selected then return end
        guarded(function() selected=id;reload(id) end)
        -- при отмене вернуть подпись текущей роли
        timer.Simple(0,function() if IsValid(select) and RP.Roles[selected] and select:GetValue()~=RP.GetRoleLabel(RP.RoleByID(selected)) and dirty then select:SetValue(RP.GetRoleLabel(RP.RoleByID(selected))) end end)
    end
    local refresh=RP.UIButton(frame,"Обновить роль",function() guarded(function() reload(selected) end) end);refresh:SetPos(w-290,75);refresh:SetSize(130,28)
    local reload=RP.UIButton(frame,"Перечитать JSON",function()
        Derma_Query("Несохранённые поля не будут записаны. Перечитать файл сервера?","V-City RP","Перечитать",function()
            dirty=false;setPending(true);net.Start(RP.NetAdminReload);net.SendToServer()
        end,"Отмена")
    end);reload:SetPos(w-150,75);reload:SetSize(130,28)

    -- Вкладки: у каждой свой DScrollPanel
    local activeTab="main"
    local pages,tabButtons={}, {}
    local ph0=h-250
    for index,tab in ipairs(TABS) do
        local id=tab[1]
        local page=vgui.Create("DScrollPanel",frame);page:SetPos(20,150);page:SetSize(w-40,ph0);page:SetVisible(id==activeTab)
        pages[id]=page
        local b=RP.UIButton(frame,tab[2],function()
            activeTab=id
            for pid,p in pairs(pages) do p:SetVisible(pid==id) end
        end)
        b:SetPos(20+(index-1)*((w-40)/#TABS),114);b:SetSize((w-40)/#TABS-6,28)
        b.Active=function() return activeTab==id end
        tabButtons[id]=b
    end

    local entries,source,serverMap,revision,sourceSettings,ammoTypes={}, nil,nil,nil,nil,{}
    local FORMAT={
        weapons=function(v) return table.concat(v,"\n") end,
        armorItems=function(v) return table.concat(v,"\n") end,
        attachments=function(v) return table.concat(v,"\n") end,
        allowedGroups=function(v) return table.concat(v,", ") end,
        ammo=ammoText,
        bodygroups=function(v) return util.TableToJSON(v,true) end,
    }
    local function markDirty() dirty=true end
    local function setField(key,value)
        local field=entries[key]
        if not field or value==nil then return end
        if field.GetChecked then
            field:SetValue(value and 1 or 0)
        else
            local fmt=FORMAT[key]
            field:SetText(fmt and fmt(value) or tostring(value))
        end
        dirty=true
    end
    local function applyRole(role,keys)
        for _,key in ipairs(keys) do setField(key,role[key]) end
    end
    -- Собирает поля формы в таблицы роли и настроек (бросает error с понятным текстом)
    local function collect()
        local role=copy(source)
        for _,key in ipairs({"name","model"}) do role[key]=entries[key]:GetValue() end
        for _,key in ipairs(NUMBERS) do role[key]=readNumber(entries[key],key) end
        for _,key in ipairs(FLAGS) do role[key]=entries[key]:GetChecked() end
        role.attachments=lines(entries.attachments:GetValue())
        role.allowedGroups=lines(entries.allowedGroups:GetValue());role.weapons=lines(entries.weapons:GetValue());role.armorItems=lines(entries.armorItems:GetValue())
        role.ammo=readAmmo(entries.ammo:GetValue());role.bodygroups=parseJSON(entries.bodygroups,"Bodygroups")
        local points=readSpawnPoints(entries.spawns)
        role.spawns[serverMap]=#points>0 and points or nil
        local settings={roleChangeCooldown=readNumber(entries.roleChangeCooldown,"Cooldown"),respawnDelay=readNumber(entries.respawnDelay,"Задержка"),respawnOnRoleChange=entries.respawnOnRoleChange:GetChecked(),startingMoney=readNumber(entries.startingMoney,"Стартовый баланс"),salaryInterval=readNumber(entries.salaryInterval,"Интервал зарплаты"),currency=entries.currency:GetValue()}
        return role,settings
    end

    local function build(data)
        for _,page in pairs(pages) do page:GetCanvas():Clear() end
        entries={}
        source=copy(data.role);sourceSettings=copy(data.settings);serverMap=data.map;revision=data.revision;ammoTypes=data.ammoTypes or {}
        dirty=false
        local cw=w-64
        local cursor={}
        local function P(id) cursor[id]=cursor[id] or 0;return pages[id]:GetCanvas(),cursor[id] end
        local function advance(id,dy) cursor[id]=cursor[id]+dy end
        local function heading(id,text)
            local canvas,y=P(id)
            local label=vgui.Create("DLabel",canvas);label:SetPos(0,y);label:SetSize(cw,24);label:SetFont("VCityRP.Body");label:SetTextColor(RP.UI.accentText);label:SetText(text);advance(id,30)
        end
        local function entry(id,key,label,value,height)
            local canvas,y=P(id);height=height or 26
            local title=vgui.Create("DLabel",canvas);title:SetPos(0,y);title:SetSize(cw,18);title:SetFont("VCityRP.Small");title:SetTextColor(RP.UI.muted);title:SetText(label);y=y+20
            local field=vgui.Create("DTextEntry",canvas);field:SetPos(0,y);field:SetSize(cw,height);field:SetFont("VCityRP.Body")
            if height>30 then field:SetMultiline(true) end
            field:SetText(tostring(value));styleEntry(field)
            field.OnChange=markDirty
            entries[key]=field;advance(id,20+height+13);return field
        end
        local function flag(id,key,label,value)
            local canvas,y=P(id)
            local field=vgui.Create("DCheckBoxLabel",canvas);field:SetPos(0,y);field:SetSize(cw,22);field:SetFont("VCityRP.Body");field:SetTextColor(RP.UI.text);field:SetText(label);field:SetValue(value and 1 or 0)
            field.OnChange=function() RP.PlayUISound("release");dirty=true end
            entries[key]=field;advance(id,28)
        end
        local function button(id,label,action,width)
            local canvas,y=P(id)
            local b=RP.UIButton(canvas,label,action);b:SetPos(0,y);b:SetSize(width or 300,28);advance(id,38);return b
        end
        local function buttons(id,defs)
            local canvas,y=P(id);local x=0
            for _,def in ipairs(defs) do
                local b=RP.UIButton(canvas,def[1],def[2]);b:SetPos(x,y);b:SetSize(def[3] or 200,28);x=x+(def[3] or 200)+8
            end
            advance(id,38)
        end

        -- Основное
        heading("main","Роль: "..data.id.." · ревизия "..revision)
        entry("main","name","Название",source.name)
        flag("main","enabled","Роль доступна для выбора",source.enabled)
        entry("main","allowedGroups","Группы доступа через запятую; пусто = все. Суперадмин имеет доступ.",table.concat(source.allowedGroups,", "))
        entry("main","maxPlayers","Лимит мест; 0 = без лимита",source.maxPlayers)
        entry("main","salary","Зарплата роли за интервал",source.salary or 200)
        flag("main","craftAccess","Доступ к станку мастерской (Оружейник)",source.craftAccess)
        flag("main","tradeAccess","Право продавать оружие через E-меню (назначает свою цену)",source.tradeAccess)

        -- Внешность
        heading("look","Модель")
        local modelField=entry("look","model","Модель (.mdl); пусто = прежняя внешность персонажа",source.model)
        local skinField=entry("look","skin","Skin; используется только с назначенной моделью",source.skin)
        entry("look","bodygroups","Bodygroups JSON: {\"1\": 2}",util.TableToJSON(source.bodygroups,true),52)
        buttons("look",{
            {"Взять модель с меня",function()
                local me=LocalPlayer()
                setField("model",me:GetModel());setField("skin",me:GetSkin())
                local bg={}
                for i=0,me:GetNumBodyGroups()-1 do
                    local v=me:GetBodygroup(i)
                    if v>0 then bg[tostring(i)]=v end
                end
                setField("bodygroups",bg)
                RP.AdminStatus="Модель, skin и bodygroups взяты с тебя. Не забудь сохранить."
            end,220},
            {"Сбросить внешность",function() setField("model","");setField("skin",0);setField("bodygroups",{}) end,200},
        })
        do
            local canvas,y=P("look")
            modelPreview(canvas,0,y,260,300,modelField,skinField);advance("look",310)
        end

        -- Снаряжение
        heading("gear","Характеристики")
        entry("gear","health","Здоровье при спавне",source.health)
        entry("gear","armor","Стандартный Armor GMod; для Z-City ниже есть предметы брони",source.armor)
        entry("gear","walkSpeed","Скорость ходьбы",source.walkSpeed)
        entry("gear","runSpeed","Скорость бега",source.runSpeed)
        entry("gear","jumpPower","Сила прыжка",source.jumpPower)
        heading("gear","Оружие и экипировка")
        local weaponsField=entry("gear","weapons","Оружие: по одному классу weapon_* на строку",table.concat(source.weapons,"\n"),82)
        buttons("gear",{{"Выбрать оружие…",function()
            openPicker("Оружие",weaponCatalog(),function(item) if appendLine(weaponsField,item.id) then RP.AdminStatus="Добавлено: "..item.id end end)
        end,200}})
        local armorField=entry("gear","armorItems","Предметы Z-City: vest4, helmet1 (ID без ent_armor_)",table.concat(source.armorItems,"\n"),58)
        buttons("gear",{{"Выбрать броню…",function()
            openPicker("Броня Z-City",armorCatalog(),function(item) if appendLine(armorField,item.id) then RP.AdminStatus="Добавлено: "..item.id end end)
        end,200}})
        local ammo=entry("gear","ammo","Патроны: тип = количество. Например: 7.62x39 mm = 90",ammoText(source.ammo),82)
        buttons("gear",{
            {"Добавить тип патронов…",function()
                local items={}
                for _,name in ipairs(ammoTypes) do items[#items+1]={id=name,label=name} end
                openPicker("Типы патронов",items,function(item) appendLine(ammo,item.id.." = 90") end)
            end,220},
            {"Удвоить количество",function()
                local ok,parsed=pcall(readAmmo,ammo:GetValue())
                if not ok then tell(parsed) return end
                for name,count in pairs(parsed) do parsed[name]=math.min(count*2,999) end
                setField("ammo",parsed)
            end,190},
        })
        local attField=entry("gear","attachments","Обвесы роли, выданные вместе с оружием: по одному ID на строку (до 8)",table.concat(source.attachments or {},"\n"),70)
        buttons("gear",{{"Выбрать обвес…",function()
            openPicker("Обвесы",attachmentCatalog(),function(item) if appendLine(attField,item.id) then RP.AdminStatus="Добавлено: "..item.id end end)
        end,200}})
        flag("gear","clearWeapons","Убирать прежнее оружие при спавне",source.clearWeapons)
        flag("gear","clearAmmo","Убирать прежние патроны при спавне",source.clearAmmo)
        flag("gear","fillClips","Заполнять магазины выданного оружия",source.fillClips)
        heading("gear","Скопировать с другой роли")
        buttons("gear",{{"Скопировать снаряжение из роли…",function()
            local menu=DermaMenu()
            for _,id in ipairs(RP.RoleOrder) do
                if id~=selected then
                    local roleId=id
                    menu:AddOption(RP.GetRoleLabel(RP.RoleByID(id)),function()
                        pendingCopy=roleId;setPending(true);RP.AdminStatus="Загрузка роли для копирования..."
                        net.Start(RP.NetAdminGet);net.WriteString(roleId);net.SendToServer()
                    end)
                end
            end
            menu:Open()
        end,300}})

        -- Спавны
        heading("spawns","Спавны на карте "..serverMap)
        entry("spawns","spawns","Массив точек JSON; [] = стандартные спавны карты",util.TableToJSON(source.spawns[serverMap] or {},true),160)
        buttons("spawns",{
            {"Добавить мою позицию (на сервере)",function() setPending(true);net.Start(RP.NetAdminCapture);net.SendToServer() end,310},
            {"Очистить спавны этой карты",function() setField("spawns",{}) end,270},
        })

        -- Сервер
        heading("server","Экономика")
        entry("server","startingMoney","Стартовый баланс новых игроков",sourceSettings.startingMoney or 1000)
        entry("server","salaryInterval","Интервал зарплаты, секунды",sourceSettings.salaryInterval or 600)
        entry("server","currency","Обозначение валюты",sourceSettings.currency or "$" )
        heading("server","Общие настройки сервера")
        entry("server","roleChangeCooldown","Задержка между сменами ролей (секунды)",sourceSettings.roleChangeCooldown)
        entry("server","respawnDelay","Задержка обычного возрождения (секунды)",sourceSettings.respawnDelay)
        flag("server","respawnOnRoleChange","Переспавн при подтверждении новой роли",sourceSettings.respawnOnRoleChange)

        -- JSON: экспорт и импорт роли целиком
        heading("json","Экспорт и импорт роли")
        local jsonField=entry("json","_json","Текущие поля как JSON. Можно вставить чужой JSON роли и нажать «Применить в поля». Сохраняет только кнопка «Сохранить на сервере».","",300)
        buttons("json",{
            {"Показать поля как JSON",function()
                local ok,role=pcall(collect)
                if not ok then tell(role) return end
                local out={}
                for _,key in ipairs(IMPORTABLE) do out[key]=role[key] end
                jsonField:SetText(util.TableToJSON(out,true))
            end,230},
            {"Применить в поля",function()
                local ok,parsed=pcall(parseJSON,jsonField,"JSON")
                if not ok then tell(parsed) return end
                applyRole(parsed,IMPORTABLE)
                RP.AdminStatus="JSON применён к полям. Проверь и сохрани."
            end,190},
        })

        for id,page in pairs(pages) do page:GetCanvas():SetTall((cursor[id] or 0)+16) end
    end

    frame.AcceptData=function(data)
        if data.kind=="capture" then
            if not source or data.map~=serverMap then tell("Сначала загрузи роль для текущей карты.") return end
            local ok,points=pcall(readSpawnPoints,entries.spawns)
            if not ok then tell(points) return end
            points[#points+1]=data.point;setField("spawns",points)
            RP.AdminStatus="Точка добавлена в поля. Нажми ‘Сохранить на сервере’."
        elseif data.kind=="loaded" and pendingCopy and data.id==pendingCopy then
            pendingCopy=nil
            if not source then return end
            applyRole(data.role,COPYABLE)
            RP.AdminStatus="Снаряжение скопировано из «"..tostring(data.role.name).."». Проверь поля и сохрани."
        elseif data.kind=="loaded" or data.kind=="saved" or data.kind=="created" then
            if data.kind=="created" then selected=data.id;frame.RefreshRoles() end
            if data.id~=selected then return end
            build(data);select:SetValue(RP.GetRoleLabel(RP.RoleByID(selected)))
            RP.AdminStatus=data.kind=="saved" and "Запись на диске подтверждена. Применится при следующем спавне." or "Настройки загружены с сервера."
        end
    end
    local save=RP.UIButton(frame,"Сохранить на сервере",function()
        if not source then tell("Сначала загрузи роль.") return end
        local ok,request=pcall(function()
            local role,settings=collect()
            return {id=selected,role=role,settings=settings,revision=revision}
        end)
        if not ok then tell(request) return end
        net.Start(RP.NetAdminSave)
        if not RP.WriteJSON(request) then tell("Запрос слишком большой.") return end
        setPending(true);RP.AdminStatus="Сохранение и проверка записи...";net.SendToServer()
    end);save:SetPos(w-250,h-66);save:SetSize(230,30);save.Primary=true
    save.Think=function(self) self:SetEnabled(not RP.AdminPending and source~=nil) end
    local label=vgui.Create("DLabel",frame);label:SetPos(20,h-66);label:SetSize(w-290,30);label:SetFont("VCityRP.Small");label:SetTextColor(RP.UI.muted);label:SetText("Сохранение не телепортирует игроков. Для применения нужен спавн.")
    frame.RequestCurrent=function() loadRole(selected) end
    select:SetValue("Гражданский")
    loadRole(selected)
end
-- ===== Редактор подклассов: экипировка «фракция × подкласс» (суперадмин) =====
local SUB_COPY={"weapons","armorItems","attachments","ammo","model","skin","clearWeapons","clearAmmo","fillClips","additive"}
function RP.OpenSubclassEditor()
    if not LocalPlayer():IsSuperAdmin() then tell("Редактор доступен только суперадмину.") return end
    if IsValid(RP.SubFrame) then RP.SubFrame:MakePopup() return end
    local factions={}
    for _,f in ipairs(RP.Factions) do if RP.SubclassFactions[f.ID] then factions[#factions+1]=f end end
    if #factions==0 or #RP.Subclasses==0 then tell("Нет военных фракций или подклассов.") return end
    local w,h=math.min(840,ScrW()-32),math.min(740,ScrH()-32)
    local frame=vgui.Create("DFrame");RP.SubFrame=frame
    frame:SetSize(w,h);frame:Center();frame:SetTitle("");frame:ShowCloseButton(false);frame:SetDraggable(false);frame:MakePopup()
    frame.OnRemove=function(self) if RP.SubFrame==self then RP.SubFrame=nil end end
    local faction,sub=factions[1].ID,RP.Subclasses[1].ID
    local status,dirty,pendingCopy,ammoTypes="",false,nil,{}
    local fields={}
    frame.Paint=function(self,pw,ph)
        draw.RoundedBox(0,0,0,pw,ph,RP.UI.bg);surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,pw,ph,1)
        draw.SimpleText("Подклассы","VCityRP.Title",20,17,RP.UI.text)
        draw.SimpleText("garrysmod/data/vcity_rp/subclasses.json","VCityRP.Small",20,48,RP.UI.muted)
        draw.SimpleText(status,"VCityRP.Small",20,ph-24,RP.UI.muted)
        if dirty then draw.SimpleText("● есть несохранённые изменения","VCityRP.Small",pw-20,ph-24,RP.UI.accentText,TEXT_ALIGN_RIGHT) end
    end
    local function closeNow() frame:Close() end
    local close=RP.UIButton(frame,"X",function()
        if dirty then Derma_Query("Есть несохранённые изменения. Закрыть без сохранения?","V-City RP","Закрыть",closeNow,"Отмена") else closeNow() end
    end);close:SetPos(w-50,15);close:SetSize(30,28)

    local function request(f,s)
        net.Start(RP.NetSubAdminGet);net.WriteString(f);net.WriteString(s);net.SendToServer()
        status="Загрузка..."
    end
    local function guarded(action)
        if not dirty then return action() end
        Derma_Query("Есть несохранённые изменения. Продолжить без сохранения?","V-City RP","Продолжить",action,"Отмена")
    end
    local factionBox=vgui.Create("DComboBox",frame);factionBox:SetPos(20,75);factionBox:SetSize(230,28);factionBox:SetFont("VCityRP.Body")
    local subBox=vgui.Create("DComboBox",frame);subBox:SetPos(260,75);subBox:SetSize(250,28);subBox:SetFont("VCityRP.Body")
    for _,f in ipairs(factions) do factionBox:AddChoice(f.Name,f.ID) end
    for _,s in ipairs(RP.Subclasses) do subBox:AddChoice(s.Name,s.ID) end
    factionBox:SetValue(factions[1].Name);subBox:SetValue(RP.Subclasses[1].Name)
    local function label() return (RP.FactionsByID[faction] and RP.FactionsByID[faction].Name or faction).." / "..(RP.SubclassByID(sub) and RP.SubclassByID(sub).Name or sub) end
    factionBox.OnSelect=function(_,_,text,id)
        if id==faction then return end
        guarded(function() faction=id;dirty=false;pendingCopy=nil;request(faction,sub) end)
        timer.Simple(0,function() if IsValid(factionBox) and dirty then factionBox:SetValue(RP.FactionsByID[faction].Name) end end)
    end
    subBox.OnSelect=function(_,_,text,id)
        if id==sub then return end
        guarded(function() sub=id;dirty=false;pendingCopy=nil;request(faction,sub) end)
        timer.Simple(0,function() if IsValid(subBox) and dirty then subBox:SetValue(RP.SubclassByID(sub).Name) end end)
    end
    local scroll=vgui.Create("DScrollPanel",frame);scroll:SetPos(20,118);scroll:SetSize(w-40,h-206)
    local function markDirty() dirty=true end

    local function build(data)
        local canvas=scroll:GetCanvas();canvas:Clear();fields={}
        ammoTypes=data.ammoTypes or {}
        dirty=false
        local lo=data.loadout or {}
        local cw=w-64;local y=0
        local function heading(text)
            local l=vgui.Create("DLabel",canvas);l:SetPos(0,y);l:SetSize(cw,24);l:SetFont("VCityRP.Body");l:SetTextColor(RP.UI.accentText);l:SetText(text);y=y+30
        end
        local function entry(key,text,value,height)
            height=height or 26
            local t=vgui.Create("DLabel",canvas);t:SetPos(0,y);t:SetSize(cw,18);t:SetFont("VCityRP.Small");t:SetTextColor(RP.UI.muted);t:SetText(text);y=y+20
            local f=vgui.Create("DTextEntry",canvas);f:SetPos(0,y);f:SetSize(cw,height);f:SetFont("VCityRP.Body")
            if height>30 then f:SetMultiline(true) end
            f:SetText(value);styleEntry(f);f.OnChange=markDirty
            fields[key]=f;y=y+height+13;return f
        end
        local function buttons(defs)
            local x=0
            for _,d in ipairs(defs) do
                local b=RP.UIButton(canvas,d[1],d[2]);b:SetPos(x,y);b:SetSize(d[3] or 200,28);x=x+(d[3] or 200)+8
            end
            y=y+38
        end
        local function tri(key,text,value)
            local t=vgui.Create("DLabel",canvas);t:SetPos(0,y);t:SetSize(cw,18);t:SetFont("VCityRP.Small");t:SetTextColor(RP.UI.muted);t:SetText(text);y=y+20
            local c=vgui.Create("DComboBox",canvas);c:SetPos(0,y);c:SetSize(220,26);c:SetFont("VCityRP.Body")
            c:AddChoice("как у звания","inherit");c:AddChoice("да","yes");c:AddChoice("нет","no")
            c:ChooseOptionID(value==true and 2 or value==false and 3 or 1)
            c.OnSelect=markDirty
            fields[key]=c;y=y+39
        end
        heading("Подкласс: "..label())
        local add=vgui.Create("DCheckBoxLabel",canvas);add:SetPos(0,y);add:SetSize(cw,22);add:SetFont("VCityRP.Body");add:SetTextColor(RP.UI.text)
        add:SetText("Добавлять к экипировке звания (оружие, броня, обвесы, патроны), а не заменять");add:SetValue(lo.additive and 1 or 0)
        add.OnChange=function() RP.PlayUISound("release");dirty=true end
        fields.additive=add;y=y+32
        heading("Экипировка (пусто = как у звания)")
        local wf=entry("weapons","Оружие: по одному классу weapon_* на строку",table.concat(lo.weapons or {},"\n"),82)
        buttons({{"Выбрать оружие…",function() openPicker("Оружие",weaponCatalog(),function(item) if appendLine(wf,item.id) then status="Добавлено: "..item.id end end) end,200}})
        local af=entry("armorItems","Предметы Z-City: vest4, helmet1",table.concat(lo.armorItems or {},"\n"),58)
        buttons({{"Выбрать броню…",function() openPicker("Броня Z-City",armorCatalog(),function(item) if appendLine(af,item.id) then status="Добавлено: "..item.id end end) end,200}})
        local amf=entry("ammo","Патроны: тип = количество. Например: 7.62x39 mm = 90",ammoText(lo.ammo or {}),82)
        buttons({{"Добавить тип патронов…",function()
            local items={}
            for _,n in ipairs(ammoTypes) do items[#items+1]={id=n,label=n} end
            openPicker("Типы патронов",items,function(item) appendLine(amf,item.id.." = 90") end)
        end,220}})
        local atf=entry("attachments","Обвесы: по одному ID на строку (до 8)",table.concat(lo.attachments or {},"\n"),58)
        buttons({{"Выбрать обвес…",function() openPicker("Обвесы",attachmentCatalog(),function(item) if appendLine(atf,item.id) then status="Добавлено: "..item.id end end) end,200}})
        heading("Внешность (пусто = как у звания)")
        local mf=entry("model","Модель (.mdl)",lo.model or "")
        local sf=entry("skin","Skin",lo.skin~=nil and tostring(lo.skin) or "")
        buttons({
            {"Взять модель и skin с меня",function() mf:SetText(LocalPlayer():GetModel());sf:SetText(tostring(LocalPlayer():GetSkin()));dirty=true end,250},
            {"Очистить",function() mf:SetText("");sf:SetText("");dirty=true end,140},
        })
        modelPreview(canvas,0,y,240,280,mf,sf);y=y+290
        heading("Очистка при спавне")
        tri("clearWeapons","Убирать прежнее оружие",lo.clearWeapons)
        tri("clearAmmo","Убирать прежние патроны",lo.clearAmmo)
        tri("fillClips","Заполнять магазины выданного оружия",lo.fillClips)
        heading("Действия")
        buttons({
            {"Скопировать из другого подкласса…",function()
                local menu=DermaMenu()
                for _,f in ipairs(factions) do
                    for _,s in ipairs(RP.Subclasses) do
                        if not (f.ID==faction and s.ID==sub) then
                            local ff,ss=f.ID,s.ID
                            menu:AddOption(f.Name.." / "..s.Name,function()
                                pendingCopy=ff.."_"..ss;status="Загрузка для копирования..."
                                net.Start(RP.NetSubAdminGet);net.WriteString(ff);net.WriteString(ss);net.SendToServer()
                            end)
                        end
                    end
                end
                menu:Open()
            end,300},
            {"Сбросить подкласс (убрать переопределения)",function()
                Derma_Query("Удалить экипировку подкласса «"..label().."»? Он вернётся к экипировке звания.","V-City RP","Сбросить",function()
                    net.Start(RP.NetSubAdminSave)
                    if not RP.WriteJSON({faction=faction,sub=sub,reset=true}) then return end
                    net.SendToServer();status="Сброс..."
                end,"Отмена")
            end,340},
        })
        canvas:SetTall(y+16)
    end
    local function setFields(lo)
        local function text(v) return v==nil and "" or tostring(v) end
        fields.weapons:SetText(table.concat(lo.weapons or {},"\n"))
        fields.armorItems:SetText(table.concat(lo.armorItems or {},"\n"))
        fields.attachments:SetText(table.concat(lo.attachments or {},"\n"))
        fields.ammo:SetText(ammoText(lo.ammo or {}))
        fields.model:SetText(text(lo.model));fields.skin:SetText(text(lo.skin))
        fields.additive:SetValue(lo.additive and 1 or 0)
        for _,key in ipairs({"clearWeapons","clearAmmo","fillClips"}) do
            local v=lo[key]
            fields[key]:ChooseOptionID(v==true and 2 or v==false and 3 or 1)
        end
        dirty=true
    end
    local function collect()
        local lo={}
        if fields.additive:GetChecked() then lo.additive=true end
        local list=lines(fields.weapons:GetValue());if #list>0 then lo.weapons=list end
        list=lines(fields.armorItems:GetValue());if #list>0 then lo.armorItems=list end
        list=lines(fields.attachments:GetValue());if #list>0 then lo.attachments=list end
        local ammo=readAmmo(fields.ammo:GetValue());if next(ammo)~=nil then lo.ammo=ammo end
        local model=string.Trim(fields.model:GetValue());if model~="" then lo.model=model end
        local skin=string.Trim(fields.skin:GetValue())
        if skin~="" then
            local n=tonumber(skin)
            if not n or n<0 or n~=math.floor(n) then error("Skin: нужно целое число.",0) end
            lo.skin=n
        end
        for _,key in ipairs({"clearWeapons","clearAmmo","fillClips"}) do
            local _,data=fields[key]:GetSelected()
            if data=="yes" then lo[key]=true elseif data=="no" then lo[key]=false end
        end
        return lo
    end
    local save=RP.UIButton(frame,"Сохранить на сервере",function()
        if not fields.weapons then tell("Подкласс ещё не загружен.") return end
        local ok,lo=pcall(collect)
        if not ok then tell(lo) return end
        net.Start(RP.NetSubAdminSave)
        if not RP.WriteJSON({faction=faction,sub=sub,loadout=lo}) then tell("Запрос слишком большой.") return end
        net.SendToServer();status="Сохранение и проверка записи..."
    end);save:SetPos(w-250,h-66);save:SetSize(230,30);save.Primary=true
    local hint=vgui.Create("DLabel",frame);hint:SetPos(20,h-66);hint:SetSize(w-290,30);hint:SetFont("VCityRP.Small");hint:SetTextColor(RP.UI.muted)
    hint:SetText("Подкласс применяется при следующем спавне игрока. Поле, которое пусто, берётся из звания.")
    frame.Accept=function(data)
        if data.kind=="error" then tell(data.message or "Ошибка редактора подклассов.");status=data.message or "";return end
        if data.kind=="loaded" and pendingCopy and data.key==pendingCopy then
            pendingCopy=nil
            if fields.weapons then setFields(data.loadout or {}) end
            status="Экипировка скопирована. Проверь поля и сохрани."
        elseif data.faction==faction and data.sub==sub then
            build(data)
            status=data.kind=="saved" and "Запись на диске подтверждена. Применится при следующем спавне." or (data.exists and "Загружено." or "Переопределений нет: подкласс использует экипировку звания.")
        end
    end
    request(faction,sub)
end
net.Receive(RP.NetSubAdminResult,function(bits)
    local data=RP.ReadJSON(bits)
    if not data then tell("Некорректный ответ редактора подклассов.") return end
    if IsValid(RP.SubFrame) then RP.SubFrame.Accept(data) end
end)
concommand.Add("vcity_rp_subclass_editor",RP.OpenSubclassEditor)
net.Receive(RP.NetAdminResult,function(bits)
    local data=RP.ReadJSON(bits)
    setPending(false)
    if not data then tell("Некорректный ответ редактора.") return end
    if data.kind=="error" then tell(data.message or "Ошибка конфига.") return end
    if data.kind=="reloaded" then
        RP.AdminStatus=data.message
        if IsValid(RP.AdminFrame) then timer.Simple(0.25,function() if IsValid(RP.AdminFrame) then RP.AdminFrame.RequestCurrent() end end) end
        return
    end
    if IsValid(RP.AdminFrame) then RP.AdminFrame.AcceptData(data) end
end)
concommand.Add("vcity_rp_config",RP.OpenAdminEditor)

hook.Add("VCityRP.CatalogUpdated","VCityRP.AdminRoleList",function()
    if IsValid(RP.AdminFrame) and RP.AdminFrame.RefreshRoles then RP.AdminFrame.RefreshRoles() end
end)
