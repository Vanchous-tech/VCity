-- V-City RP 0.3.5 — daily restart notice: «уже поздно, рестарт сервера в 05:00».
--
-- The server itself does not restart the process: the shutdown is done by the host (systemd unit,
-- cron line, hosting panel scheduler, a screen/tmux loop). This module only announces it in game:
-- a reminder every 15 minutes through the night and a countdown in the last hour.
--
-- Pure helpers live here so the schedule can be checked without a game engine; the countdown loop
-- is in rp/sv_restart.lua and the on-screen block in rp/cl_restart.lua.
local RP = VCityRP

-- Settings. Defaults match the server: 24/7 with one restart at 05:00 host time.
RP.RestartDefaults = {
    hour = 5,
    minute = 0,
    warnMinutes = {60, 30, 15, 10, 5, 3, 2, 1},
    finalSeconds = 30,
    nightHours = 4,          -- reminders start 4 hours before the restart
    nightEverySeconds = 900, -- every 15 minutes
    nightText = "Уже поздно. Рестарт сервера в {time} — прогресс сохраняется, персонаж останется прежним.",
    warningText = "Рестарт сервера через {when}",
    finalText = "Рестарт сервера через 30 секунд. Отойдите в укрытие и не начинайте важный бой.",
    nowText = "Рестарт сервера. Вернётесь через минуту-две на том же персонаже."
}
RP.RestartSub = "Плановый рестарт каждый день в {time} · сервер работает круглосуточно"

-- Server clock indirection: tests replace it, the game uses the host local time.
RP.GetServerTime = function() return os.time() end

-- Russian plural forms: 1 минуту / 2 минуты / 5 минут.
function RP.PluralForm(count, one, few, many)
    local n = math.abs(math.floor(tonumber(count) or 0))
    local mod100 = n % 100
    if mod100 >= 11 and mod100 <= 14 then return many end
    local mod10 = n % 10
    if mod10 == 1 then return one end
    if mod10 >= 2 and mod10 <= 4 then return few end
    return many
end

function RP.Plural(count, forms)
    return RP.PluralForm(count, forms[1], forms[2], forms[3])
end

-- Compact duration: «30 секунд», «15 минут», «1 час», «4 часа».
function RP.DurationText(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    if seconds < 60 then
        return seconds .. " " .. RP.Plural(seconds, {"секунду", "секунды", "секунд"})
    end
    local minutes = math.floor(seconds / 60)
    if minutes % 60 == 0 and minutes >= 60 then
        local hours = minutes / 60
        return hours .. " " .. RP.Plural(hours, {"час", "часа", "часов"})
    end
    return minutes .. " " .. RP.Plural(minutes, {"минуту", "минуты", "минут"})
end

function RP.ClockText(hour, minute)
    return string.format("%02d:%02d", math.floor(hour or RP.RestartDefaults.hour), math.floor(minute or RP.RestartDefaults.minute))
end

-- Next restart moment: today at hour:minute when still ahead, otherwise tomorrow.
-- os.time normalises day overflow, so month and year ends are handled by the platform.
function RP.NextRestartTime(now, hour, minute)
    now = math.floor(tonumber(now) or RP.GetServerTime())
    local parts = os.date("*t", now)
    parts.hour = math.floor(hour or RP.RestartDefaults.hour)
    parts.min = math.floor(minute or RP.RestartDefaults.minute)
    parts.sec = 0
    local candidate = os.time(parts)
    if candidate <= now then
        parts.day = parts.day + 1
        candidate = os.time(parts)
    end
    return candidate
end

function RP.RestartState(now, hour, minute)
    now = math.floor(tonumber(now) or RP.GetServerTime())
    hour = hour or RP.RestartDefaults.hour
    minute = minute or RP.RestartDefaults.minute
    local at = RP.NextRestartTime(now, hour, minute)
    return {at = at, left = at - now, clock = RP.ClockText(hour, minute)}
end

-- Which countdown thresholds were crossed between two ticks. Without this a warning would either
-- be repeated every second or be missed when the server lags over the exact moment.
function RP.CrossedWarnings(list, left, previousLeft)
    local crossed = {}
    if type(list) ~= "table" or type(left) ~= "number" or type(previousLeft) ~= "number" then return crossed end
    for _, threshold in ipairs(list) do
        if type(threshold) == "number" and left <= threshold and previousLeft > threshold then
            crossed[#crossed + 1] = threshold
        end
    end
    table.sort(crossed, function(a, b) return a < b end)
    return crossed
end

function RP.FillRestartText(template, values)
    local text = tostring(template or "")
    for key, value in pairs(values or {}) do
        text = text:gsub("{" .. key .. "}", tostring(value))
    end
    return text
end
