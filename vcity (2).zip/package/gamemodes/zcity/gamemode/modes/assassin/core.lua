-- SPDX-License-Identifier: AGPL-3.0-or-later
-- Server-only target graph in a pure module. Clients never receive the graph.
local Core = {}
function Core.New(list, random)
    random = random or math.random
    local order, seen = {}, {}
    for _, id in ipairs(list) do
        assert(not seen[id], "duplicate participant")
        seen[id] = true; order[#order+1] = id
    end
    for i = #order, 2, -1 do
        local j = random(i); order[i], order[j] = order[j], order[i]
    end
    local state = {members = seen, targets = {}, hunters = {}, count = #order}
    if #order >= 2 then
        for i, id in ipairs(order) do
            local nextID = order[i % #order + 1]
            state.targets[id], state.hunters[nextID] = nextID, id
        end
    end
    return state
end
function Core.Remove(state, id)
    if not state or not state.members[id] then return false end
    local hunter, target = state.hunters[id], state.targets[id]
    state.members[id], state.targets[id], state.hunters[id] = nil, nil, nil
    state.count = state.count - 1
    if state.count >= 2 then
        state.targets[hunter], state.hunters[target] = target, hunter
    elseif state.count == 1 then
        state.targets[hunter], state.hunters[hunter] = nil, nil
    end
    return true, hunter
end
function Core.IsTarget(state, hunter, victim)
    return state ~= nil and hunter ~= nil and victim ~= nil and hunter ~= victim
        and state.members[hunter] == true and state.members[victim] == true and state.targets[hunter] == victim
end
function Core.Winner(state)
    if not state or state.count > 1 then return false end
    return true, next(state.members) -- nil means a draw
end
return Core
