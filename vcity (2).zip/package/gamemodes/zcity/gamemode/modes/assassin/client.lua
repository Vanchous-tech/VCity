-- SPDX-License-Identifier: AGPL-3.0-or-later
local MODE = MODE
local C = MODE.Config
local private, result
local endMenu
local function inMode() return CurrentRound and CurrentRound()==MODE end
local function closeEndMenu() if IsValid(endMenu) then endMenu:Remove() end;endMenu=nil end
local function clear() private=nil;result=nil end
hook.Add("RoundInfoCalled","Assassin.Clear",clear)
function MODE:RoundStart() clear();closeEndMenu();if zb.RemoveFade then zb.RemoveFade() end;zb.fade=0 end
function MODE:EndRound() private=nil end

-- Same layout/behavior as Homicide's end-of-round ZFrame (cl_homicide.lua):
-- close button top-left, title via PaintOver, DScrollPanel of colored rows.
local colGray,colRed,colRedUp=Color(85,85,85),Color(130,10,10),Color(160,30,30)
local colBlue,colBlueUp=Color(10,10,160),Color(40,40,160)
local function createEndMenu(text,rows)
    closeEndMenu()
    surface.PlaySound("ambient/alarms/warningbell1.wav")

    local sizeX,sizeY=ScrW()/2.5,ScrH()/1.2
    local posX,posY=ScrW()/1.3-sizeX/2,ScrH()/2-sizeY/2

    endMenu=vgui.Create("ZFrame")
    if not IsValid(endMenu) then return end
    endMenu:SetPos(posX,posY);endMenu:SetSize(sizeX,sizeY)
    endMenu:MakePopup();endMenu:SetKeyboardInputEnabled(false);endMenu:ShowCloseButton(false)

    local closebutton=vgui.Create("DButton",endMenu)
    closebutton:SetPos(5,5);closebutton:SetSize(ScrW()/20,ScrH()/30);closebutton:SetText("")
    closebutton.DoClick=function() closeEndMenu() end
    closebutton.Paint=function(self,w,h)
        surface.SetDrawColor(122,122,122,255)
        surface.DrawOutlinedRect(0,0,w,h,2.5)
        surface.SetFont("ZB_InterfaceMedium");surface.SetTextColor(255,255,255,255)
        local lengthX=surface.GetTextSize("Закрыть")
        surface.SetTextPos(lengthX-lengthX/1.1,4);surface.DrawText("Закрыть")
    end
    endMenu.PaintOver=function(self,w,h)
        surface.SetFont("ZB_InterfaceMediumLarge");surface.SetTextColor(255,255,255,255)
        local lengthX=surface.GetTextSize(text)
        surface.SetTextPos(w/2-lengthX/2,20);surface.DrawText(text)
    end

    local scroll=vgui.Create("DScrollPanel",endMenu)
    scroll:SetPos(10,80);scroll:SetSize(sizeX-20,sizeY-90)

    for _,row in ipairs(rows) do
        local but=vgui.Create("DButton",scroll)
        but:SetSize(100,50);but:Dock(TOP);but:DockMargin(8,6,8,-1);but:SetText("")
        but.Paint=function(self,w,h)
            local col1=row.eliminated and colRed or colBlue
            local col2=row.eliminated and colRedUp or colBlueUp
            surface.SetDrawColor(col1.r,col1.g,col1.b,col1.a);surface.DrawRect(0,0,w,h)
            surface.SetDrawColor(col2.r,col2.g,col2.b,col2.a);surface.DrawRect(0,h/2,w,h/2)

            surface.SetFont("ZB_InterfaceMediumLarge");surface.SetTextColor(255,255,255,255)
            local _,ly=surface.GetTextSize(row.alias)
            local status=row.alias..(row.eliminated and " — устранён" or " — выжил")
            surface.SetTextPos(15,h/2-ly/2);surface.DrawText(status)

            if row.target~="" then
                surface.SetFont("ZB_InterfaceMedium");surface.SetTextColor(colGray.r,colGray.g,colGray.b,255)
                local tx,ty=surface.GetTextSize("цель: "..row.target)
                surface.SetTextPos(w-tx-15,h/2-ty/2);surface.DrawText("цель: "..row.target)
            end
        end
        scroll:AddItem(but)
    end
end

net.Receive("ASSN_Target",function()
    local serial,revision=net.ReadUInt(32),net.ReadUInt(32)
    local mine,target=net.ReadString(),net.ReadString()
    if not inMode() or zb.ROUND_STATE~=1 then return end
    if GetGlobalInt("ASSN_Round",serial)~=serial then return end
    if private and private.serial==serial and private.revision>=revision then return end
    private={serial=serial,revision=revision,mine=mine,target=target}
end)
net.Receive("ASSN_End",function()
    local text=net.ReadString()
    local count=net.ReadUInt(8)
    local rows={}
    for i=1,count do
        rows[i]={alias=net.ReadString(),eliminated=net.ReadBool(),target=net.ReadString()}
    end
    if not inMode() or zb.ROUND_STATE~=3 then return end
    private=nil;result=text
    createEndMenu(text,rows)
end)
function MODE:RenderScreenspaceEffects()
    if not inMode() or zb.ROUND_STATE~=0 then return end
    surface.SetDrawColor(0,0,0,255);surface.DrawRect(0,0,ScrW(),ScrH())
end
function MODE:HUDPaint()
    if not inMode() then return end
    if zb.ROUND_STATE==0 then
        draw.SimpleText("ASSASSIN","ZB_HomicideMediumLarge",ScrW()/2,ScrH()*.25,Color(210,65,60),TEXT_ALIGN_CENTER)
        draw.SimpleText("Все охотники. Все цели.","ZB_HomicideMedium",ScrW()/2,ScrH()*.5,color_white,TEXT_ALIGN_CENTER)
        draw.SimpleText("Узнайте имя вблизи. За нападение на постороннего — вина.","ZB_HomicideMedium",ScrW()/2,ScrH()*.8,color_white,TEXT_ALIGN_CENTER)
        return
    end
    if zb.ROUND_STATE==3 then
        local text=result or GetGlobalString("ASSN_Result", "")
        if text~="" then draw.SimpleText(text,"ZB_HomicideMediumLarge",ScrW()/2,ScrH()*.35,color_white,TEXT_ALIGN_CENTER) end
        return
    end
    local p=LocalPlayer()
    if zb.ROUND_STATE~=1 or not IsValid(p) or not p:Alive() or p:Team()==TEAM_SPECTATOR or not private then return end
    local x,y=ScrW()*.035,ScrH()*.76
    draw.SimpleText("Ваше имя: "..private.mine,"ZB_InterfaceMedium",x,y,Color(180,180,180))
    draw.SimpleText(private.target~="" and ("Ваша цель: "..private.target) or "Целей больше нет", "ZB_InterfaceMediumLarge",x,y+30,color_white)
    local remaining=math.max(0,math.ceil(GetGlobalFloat("ASSN_GraceEnd",0)-CurTime()))
    local hint=remaining>0 and ("Растворитесь в толпе. Атаки через "..remaining.." с.") or "Имена видны вблизи. Посторонних не трогать."
    draw.SimpleText(hint,"ZB_InterfaceMedium",x,y+64,Color(200,165,95))
end

-- Native Identifier paints names without our required short-distance limit.
-- Wrap its existing hook, not all of HUDPaint. Other modes still call original.
function MODE:DrawNearbyName()
    local p=LocalPlayer()
    if not IsValid(p) or not p:Alive() or p:Team()==TEAM_SPECTATOR or zb.ROUND_STATE~=1 then return end
    if p.organism and p.organism.otrub then return end
    local trace=hg.eyeTrace(p)
    if not trace or not trace.Hit or not IsValid(trace.Entity) then return end
    local ent=trace.Entity
    if not ent:IsPlayer() and not ent:IsRagdoll() then return end
    if ent:GetNetVar("disappearance",nil) then return end
    local origin=trace.StartPos or p:EyePos()
    if origin:DistToSqr(trace.HitPos)>C.IdentifyDistance*C.IdentifyDistance then return end

    -- Same two-pass outline + distance falloff as the native Identifier hook
    -- in lua/homigrad/cl_hud.lua, so the nametag is pixel-for-pixel indistinguishable
    -- from vanilla. AColor is forced uniform in config.lua, so GetPlayerColor()
    -- never leaks a real identity here. No target highlighting, colors or arrows.
    draw.NoTexture()
    local Size=math.max(math.min(1-trace.Fraction,1),0.1)
    local pos=trace.HitPos:ToScreen()
    local x,y=pos.x,pos.y

    local col=ent:GetPlayerColor():ToColor()
    col.a=255*Size*1.5

    local coloutline=(col.r<50 and col.g<50 and col.b<50) and Color(100,100,100) or Color(0,0,0)
    coloutline.a=255*Size

    local name=ent:GetPlayerName() or ""
    draw.DrawText(name,"HomigradFontLarge",x+1,y+31,coloutline,TEXT_ALIGN_CENTER)
    draw.DrawText(name,"HomigradFontLarge",x,y+30,col,TEXT_ALIGN_CENTER)
end
local function installIdentifier()
    local all=hook.GetTable()
    local original=all.HUDPaint and all.HUDPaint.Identifier
    local old=hg.AssassinIdentifierBridge
    if old and original==old.wrapper then original=old.original end
    if type(original)~="function" then return false end
    local wrapper=function(...)
        if inMode() then MODE:DrawNearbyName();return end
        return original(...)
    end
    hg.AssassinIdentifierBridge={original=original,wrapper=wrapper}
    hook.Add("HUDPaint","Identifier",wrapper)
    return true
end
installIdentifier()
-- Lifecycle observers MUST return nil. Returning installer true/false stops
-- all later GMod hook callbacks, including native Z-City UI/chat setup.
hook.Add("InitPostEntity","Assassin.Identifier",function() installIdentifier() end)
hook.Add("OnReloaded","Assassin.Identifier",function() installIdentifier() end)
