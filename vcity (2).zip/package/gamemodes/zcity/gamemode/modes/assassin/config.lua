-- Assassin / Z-City. Shared config, no secrets here. Restart the server after edits.
return {
    PrepareSeconds = 5,
    GraceTime = 30, -- from active round start, NOT from preparation
    MaxRoundSeconds = 600, -- 0 disables the safety timeout (otherwise draw)
    IdentifyDistance = 120, -- Source units; names only when looking from nearby
    SelfDefenseWindow = 4, -- seconds a victim of a cold illegal hit may hit back guilt-free
    Firearm = "weapon_glock17", -- one FULL loaded magazine, zero reserve
    Melee = "weapon_sogknife",
    Bandage = "weapon_bandage_sh",
    Tourniquet = "weapon_tourniquet",
    -- Native Appearance key, not a raw model path. Same profile for everyone.
    Appearance = {
        AModel = "Male 07",
        AClothes = {main = "normal", pants = "normal", boots = "normal"},
        AColor = Color(100,100,100), AAttachments = {}, ABodygroups = {}, AFacemap = "Default",
    },
    -- Distinct round aliases. Never use Steam names as target clues.
    FirstNames = {"Алексей", "Андрей", "Антон", "Борис", "Вадим", "Виктор", "Денис", "Иван", "Илья", "Кирилл", "Максим", "Михаил", "Никита", "Олег", "Павел", "Роман", "Сергей", "Тимур", "Фёдор", "Юрий"},
    LastNames = {"Белов", "Волков", "Громов", "Дроздов", "Егоров", "Жуков", "Зайцев", "Ильин", "Ковалёв", "Лебедев", "Морозов", "Никитин", "Орлов", "Петров", "Романов", "Соколов", "Титов", "Фомин", "Хромов", "Шилов"},
}
