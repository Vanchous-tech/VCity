-- SPDX-License-Identifier: AGPL-3.0-or-later
-- Z-City only autoloads this prefixed file; no replacement of base gamemode files.
local MODE = MODE
local path = "zcity/gamemode/modes/assassin/"
if SERVER then
    AddCSLuaFile(path .. "config.lua")
    AddCSLuaFile(path .. "client.lua")
end
MODE.Config = include(path .. "config.lua")
MODE.name, MODE.PrintName = "assassin", "Assassin"
MODE.Description = "У каждого своя тайная цель. Узнайте имя вблизи; за нападение на посторонних — вина."
MODE.Chance = 0
MODE.start_time, MODE.end_time = MODE.Config.PrepareSeconds, 8
MODE.ROUND_TIME = MODE.Config.MaxRoundSeconds > 0 and MODE.Config.MaxRoundSeconds or 86400
MODE.GraceTime = MODE.Config.GraceTime
MODE.randomSpawns, MODE.buymenu, MODE.LootSpawn = true, false, false
MODE.GuiltDisabled, MODE.OverrideSpawn = false, false
local class = player.RegClass("assassin_civilian")
class.CanUseDefaultPhrase, class.CanUseGestures, class.CanEmitRNDSound = true, true, false
function class.Guilt() return 1 end -- native GuiltReg multiplies by this return value
function MODE:GraceActive()
    if zb.ROUND_STATE == 0 then return true end
    return zb.ROUND_STATE == 1 and CurTime() < GetGlobalFloat("ASSN_GraceEnd", 0)
end
-- Based on the user's sketch and Deathmatch. Server/client movement prediction.
function MODE:HG_MovementCalc_2(mul, ply, cmd, mv)
    if not self:GraceActive() or not cmd then return end
    cmd:RemoveKey(IN_ATTACK); cmd:RemoveKey(IN_ATTACK2)
    if mv then mv:RemoveKey(IN_ATTACK); mv:RemoveKey(IN_ATTACK2) end
    if IsValid(ply) then
        local hands = ply:GetWeapon("weapon_hands_sh")
        if IsValid(hands) then
            cmd:SelectWeapon(hands)
            if SERVER then ply:SelectWeapon("weapon_hands_sh") end
        end
    end
end
function MODE:PlayerCanLegAttack() if self:GraceActive() then return false end end
if SERVER then
    MODE.Core = include(path .. "core.lua")
    include(path .. "server.lua")
else
    include(path .. "client.lua")
end
