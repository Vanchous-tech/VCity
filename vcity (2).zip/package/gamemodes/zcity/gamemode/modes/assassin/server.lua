-- SPDX-License-Identifier: AGPL-3.0-or-later
local MODE = MODE
local C, Core = MODE.Config, MODE.Core
util.AddNetworkString("ASSN_Target")
util.AddNetworkString("ASSN_End")
local function validPlayer(p) return IsValid(p) and p:IsPlayer() end
local function active() return CurrentRound() == MODE and zb.ROUND_STATE == 1 end
local function warn(s) ErrorNoHalt("[Assassin] " .. s .. "\n") end
local function owner(ent)
    if validPlayer(ent) then return ent end
    if IsValid(ent) and ent:IsRagdoll() then
        local p = ent:GetNWEntity("ply")
        if validPlayer(p) then return p end
    end
end

-- self.threats[X] = {by=Y, time=t}: X was hit by Y at time t in a hit that was
-- itself cold (neither a legal target-kill nor already self-defense). X may
-- hit Y back guilt-free within C.SelfDefenseWindow. Consumed on use, and never
-- re-granted from a self-defense hit, so an aggressor cannot launder repeated
-- attacks by provoking one exempted counter-hit (see PreHomigradDamage).
function MODE:HasStanding(attacker, against)
    local t = self.threats and self.threats[attacker]
    return t and t.by == against and (CurTime() - t.time) <= C.SelfDefenseWindow
end

-- GuiltCheck's multiplier alone DOES NOT suppress native Attacker.Guilt.
-- Route lawful hits around the existing named hook, leave all other modes and
-- wrongful attacks to the original native function. Never return true to stop
-- the other HomigradDamage listeners.
function MODE:LawfulDamage(ply, dmg)
    local victim, attacker = owner(ply), dmg:GetAttacker()
    if not active() or not validPlayer(attacker) or not victim then return false end
    local saved = self.damagePermits and self.damagePermits[dmg]
    if saved and saved.victim == victim and saved.attacker == attacker then return saved.legal end
    return Core.IsTarget(self.ring, attacker, victim) or self:HasStanding(attacker, victim)
end
function MODE:InstallGuiltBridge()
    local hooks = hook.GetTable()
    local original = hooks.HomigradDamage and hooks.HomigradDamage.GuiltReg
    local old = hg.AssassinGuiltBridge
    if old and original == old.wrapper then original = old.original end
    if type(original) ~= "function" then return false end
    local wrapper = function(ply, dmg, ...)
        if MODE:LawfulDamage(ply, dmg) then return end
        return original(ply, dmg, ...)
    end
    hg.AssassinGuiltBridge = {original = original, wrapper = wrapper}
    hook.Add("HomigradDamage", "GuiltReg", wrapper)
    -- Native trip/push guilt is a separate listener, not GuiltReg.
    local fall = hooks.ZC_SomeoneGetFallBy and hooks.ZC_SomeoneGetFallBy.IdiotsMustBeKilled
    local oldFall = hg.AssassinFallGuiltBridge
    if oldFall and fall == oldFall.wrapper then fall = oldFall.original end
    if type(fall) == "function" then
        local fallWrapper = function(attacker, victim, ...)
            local victimPly = owner(victim)
            if active() and (Core.IsTarget(MODE.ring, attacker, victimPly) or MODE:HasStanding(attacker, victimPly)) then return end
            return fall(attacker, victim, ...)
        end
        hg.AssassinFallGuiltBridge = {original=fall, wrapper=fallWrapper}
        hook.Add("ZC_SomeoneGetFallBy", "IdiotsMustBeKilled", fallWrapper)
    end
    return true
end
MODE:InstallGuiltBridge()
hook.Add("InitPostEntity", "Assassin.GuiltBridge", function() MODE:InstallGuiltBridge() end)
hook.Add("OnReloaded", "Assassin.GuiltBridge", function() MODE:InstallGuiltBridge() end)
-- Native callback is called with dot syntax, not colon syntax.
function MODE.GuiltCheck() return 1, false end -- normal karma, no extra TDM team-ban policy
function MODE:PreHomigradDamage(ply, dmg)
    if not active() or dmg:GetDamage() <= 0 then return end
    local victim, attacker = owner(ply), dmg:GetAttacker()
    if not victim or not validPlayer(attacker) then return end
    self.damagePermits = self.damagePermits or setmetatable({}, {__mode="k"})

    local isTarget = Core.IsTarget(self.ring, attacker, victim)
    local selfDefense = not isTarget and self:HasStanding(attacker, victim)
    -- Classification at HIT time survives synchronous death and target inheritance.
    self.damagePermits[dmg] = {victim=victim, attacker=attacker, legal = isTarget or selfDefense}

    if selfDefense then
        -- Spend the standing: one free counter-hit per cold attack, not a
        -- running feud license.
        self.threats[attacker] = nil
    elseif not isTarget then
        -- A cold, unprovoked illegal hit. The victim now has standing to hit
        -- this specific attacker back within the window.
        self.threats = self.threats or {}
        self.threats[victim] = {by = attacker, time = CurTime()}
    end
end

function MODE:CanLaunch()
    if not hg.Appearance or type(hg.Appearance.ForceApplyAppearance) ~= "function" then
        return false, "Нет штатной системы Appearance"
    end
    if not self:InstallGuiltBridge() then return false, "Нет штатного обработчика GuiltReg" end
    local sample = table.Copy(C.Appearance); sample.AName = "Assassin"
    if hg.Appearance.AppearanceValidater and not hg.Appearance.AppearanceValidater(sample) then
        return false, "Невалидный профиль Appearance в config.lua"
    end
    for _,id in ipairs({"weapon_hands_sh",C.Firearm,C.Melee,C.Bandage,C.Tourniquet}) do
        if not weapons.GetStored(id) then return false, "Нет SWEP: " .. id end
    end
    return true
end
function MODE:CanSpawn() return false end
function MODE:SaveLook(p)
    self.looks = self.looks or {}
    if self.looks[p] then return end
    local acc = p:GetNetVar("Accessories", "")
    local look = {model=p:GetModel(), skin=p:GetSkin(), color=p:GetPlayerColor(),
        name=p:GetNWString("PlayerName", ""), nwcolor=p:GetNWVector("PlayerColor"),
        accessories=type(acc)=="table" and table.Copy(acc) or acc,
        appearance=p.CurAppearance and table.Copy(p.CurAppearance), groups={}, materials={}, clothes={}}
    for i=0,p:GetNumBodyGroups()-1 do look.groups[i]=p:GetBodygroup(i) end
    for i=0,#p:GetMaterials()-1 do look.materials[i]=p:GetSubMaterial(i) end
    for _,key in ipairs({"main","pants","boots","hands"}) do look.clothes[key]=p:GetNWString("Colthes"..key, "") end
    self.looks[p]=look
end
function MODE:RestoreLook(p)
    local look = self.looks and self.looks[p]
    if not look then return end
    self.looks[p]=nil
    if not validPlayer(p) then return end
    p:SetModel(look.model);p:SetSkin(look.skin);p:SetSubMaterial()
    for i,v in pairs(look.groups) do p:SetBodygroup(i,v) end
    for i,v in pairs(look.materials) do p:SetSubMaterial(i,v) end
    p:SetPlayerColor(look.color);p:SetNWVector("PlayerColor",look.nwcolor)
    p:SetNWString("PlayerName",look.name);p:SetNetVar("Accessories",look.accessories)
    for key,value in pairs(look.clothes) do p:SetNWString("Colthes"..key,value) end
    p.CurAppearance=look.appearance -- CachedAppearance and saved client files never changed
end
function MODE:MakeAlias(index, used)
    for i=1,100 do
        local name=C.FirstNames[math.random(#C.FirstNames)] .. " " .. C.LastNames[math.random(#C.LastNames)]
        if not used[name] then used[name]=true return name end
    end
    local code,number="",index
    repeat
        code=string.char(65+(number-1)%26)..code
        number=math.floor((number-1)/26)
    until number==0
    local name="Гость " .. code
    while used[name] do name=name .. "а" end
    used[name]=true;return name
end
function MODE:SetUniform(p, alias)
    self:SaveLook(p)
    local appearance = table.Copy(C.Appearance)
    appearance.AName = alias
    p:SetPlayerClass("assassin_civilian")
    hg.Appearance.ForceApplyAppearance(p, appearance)
    p:SetSkin(0)
end
function MODE:GiveKit(p)
    p:StripWeapons();p:RemoveAllAmmo()
    hg.CreateInv(p)
    p.armors,p.armors_health={},{};p:SyncArmor()
    local gun
    for _,id in ipairs({"weapon_hands_sh", C.Firearm, C.Melee, C.Bandage, C.Tourniquet}) do
        if not weapons.GetStored(id) then warn("Нет SWEP: "..id) return false end
        local wep=p:Give(id,true)
        if not IsValid(wep) then warn("Не выдан SWEP: "..id) return false end
        if id==C.Firearm then gun=wep end
    end
    local capacity=gun:GetMaxClip1()
    if capacity<=0 then capacity=gun.Primary and gun.Primary.ClipSize or 0 end
    if capacity<=0 then warn("Firearm должен поддерживать обычный магазин") return false end
    gun:SetClip1(capacity)
    gun:SetClip2(0)
    p:RemoveAllAmmo() -- even if a third-party Initialize gave reserve ammo
    local inv=p:GetNetVar("Inventory",{})
    inv.Weapons=inv.Weapons or {};inv.Weapons.hg_sling=true;p:SetNetVar("Inventory",inv)
    if p.organism then p.organism.allowholster=true end
    p:SelectWeapon("weapon_hands_sh")
    return true
end
function MODE:Intermission()
    game.CleanUpMap()
    self.token={};local token=self.token
    self.members,self.ring,self.failed,self.prepared={},nil,nil,false
    self.winner,self.started=nil,nil
    self.reveal,self.eliminationOrder={},{}
    self.threats={}
    self.damagePermits=setmetatable({}, {__mode="k"})
    self.serial=(self.serial or 0)+1;self.revision=0
    SetGlobalFloat("ASSN_GraceEnd",0)
    SetGlobalString("ASSN_Result", "")
    SetGlobalInt("ASSN_Round",self.serial)
    local ready,reason=self:CanLaunch()
    if not ready then self.failed=reason or "Не выполнены требования режима";warn(self.failed) end
    timer.Simple(0.2,function()
        if CurrentRound()~=self or self.token~=token or zb.ROUND_STATE~=0 then return end
        if self.failed then self.prepared=true return end
        local used,index={},0
        for _,p in player.Iterator() do
            if p:Team()~=TEAM_SPECTATOR and p:Alive() then
                index=index+1
                local alias=self:MakeAlias(index,used)
                p:SetupTeam(0) -- all on the SAME team, otherwise native GuiltReg exits early
                self:SetUniform(p,alias)
                p:StripWeapons();p:RemoveAllAmmo()
                p:Give("weapon_hands_sh",true)
                p:Freeze(true)
                self.members[p]={alias=alias,eliminated=false}
                zb.GiveRole(p,"Assassin",Color(180,180,180))
            end
        end
        self.prepared=true
    end)
end
function MODE:GiveEquipment() end -- equipment is issued at active start, once
function MODE:RoundStart()
    self.started=CurTime()
    SetGlobalFloat("ASSN_GraceEnd",self.started + C.GraceTime)
    local participants={}
    if not self.prepared then self.failed="Подготовка раунда не завершилась" end
    for p,entry in pairs(self.members or {}) do
        if validPlayer(p) and p:Alive() and not entry.eliminated then
            participants[#participants+1]=p
            p:SetTeam(0);p:Freeze(false)
            if not self:GiveKit(p) then self.failed="Ошибка выдачи снаряжения; проверьте консоль" end
        end
    end
    for _,p in player.Iterator() do
        local entry=self.members[p]
        if (not entry or entry.eliminated) and p:Alive() then p:KillSilent() end
    end
    self.ring=Core.New(participants)
    if #participants<2 and not self.failed then self.failed="Нужно как минимум два участника" end
    if self.failed then warn(self.failed) end
    -- Снимок исходной цепочки по алиасам, для раскрытия на итоговом экране.
    -- Живая self.ring мутирует при каждом Core.Remove, поэтому берём копию сейчас.
    self.reveal={}
    if self.ring then
        for p,target in pairs(self.ring.targets) do
            local entry,targetEntry=self.members[p],self.members[target]
            if entry and targetEntry then self.reveal[entry.alias]=targetEntry.alias end
        end
    end
    self:SendTargets()
end
function MODE:SendTarget(p)
    if not validPlayer(p) then return end
    local entry=self.members and self.members[p]
    local target=self.ring and self.ring.targets[p]
    local targetEntry=target and self.members[target]
    net.Start("ASSN_Target")
    net.WriteUInt(self.serial or 0,32);net.WriteUInt(self.revision or 0,32)
    net.WriteString(entry and entry.alias or "")
    net.WriteString(targetEntry and targetEntry.alias or "")
    net.Send(p) -- NEVER broadcast the graph, hunter ID or target entity
end
function MODE:SendTargets()
    self.revision=(self.revision or 0)+1
    for p in pairs(self.members or {}) do self:SendTarget(p) end
end
function MODE:Eliminate(p)
    local entry=self.members and self.members[p]
    if not entry or entry.eliminated then return end
    entry.eliminated=true
    self.eliminationOrder=self.eliminationOrder or {}
    self.eliminationOrder[#self.eliminationOrder+1]=entry.alias
    if Core.Remove(self.ring,p) then self:SendTargets() end
end
function MODE:PlayerDeath(p) if CurrentRound()==self then self:Eliminate(p) end end
function MODE:PlayerDisconnected(p)
    self:Eliminate(p)
    if self.members then self.members[p]=nil end
    if self.looks then self.looks[p]=nil end
end
function MODE:PlayerSpawn(p)
    -- hg.FakeUp internally calls Player:Spawn with this native global flag.
    -- It is NOT a respawn/new life and must not eliminate the participant.
    if OverrideSpawn or not active() then return end
    local token=self.token
    timer.Simple(0.1,function()
        if not active() or self.token~=token or not validPlayer(p) then return end
        -- Includes manual respawns of an eliminated participant, never grants a new target.
        self:Eliminate(p)
        if p:Alive() then p:KillSilent() end
    end)
end
function MODE:RoundThink()
    if not self.ring then return end
    local missing={}
    for p in pairs(self.ring.members) do
        if not validPlayer(p) or not p:Alive() or p:Team()~=0 then missing[#missing+1]=p end
    end
    for _,p in ipairs(missing) do
        if validPlayer(p) and p:Alive() and p:Team()~=0 then p:KillSilent() end
        self:Eliminate(p)
    end
end
function MODE:ShouldRoundEnd()
    if self.failed then self.winner=nil return true end
    local finished,winner=Core.Winner(self.ring)
    if finished then self.winner=winner return true end
    if C.MaxRoundSeconds>0 and self.started and CurTime()>=self.started+C.MaxRoundSeconds then
        self.winner=nil return true
    end
    return false
end
function MODE:EndRound()
    local entry=self.winner and self.members and self.members[self.winner]
    local text=self.failed or (entry and ("Выжил: "..entry.alias) or "Ничья")
    SetGlobalString("ASSN_Result",text)

    -- Порядок для списка на итоговом экране: сперва выбывшие в порядке гибели
    -- (интереснее читать сверху вниз как хронику), затем живые.
    local order,seen={},{}
    for _,alias in ipairs(self.eliminationOrder or {}) do
        if not seen[alias] then order[#order+1]=alias;seen[alias]=true end
    end
    for _,e in pairs(self.members or {}) do
        if not seen[e.alias] then order[#order+1]=e.alias;seen[e.alias]=true end
    end
    local eliminated,aliasEntry={},{}
    for _,e in pairs(self.members or {}) do aliasEntry[e.alias]=e end
    for _,alias in ipairs(self.eliminationOrder or {}) do eliminated[alias]=true end

    net.Start("ASSN_End")
    net.WriteString(text)
    net.WriteUInt(#order,8)
    for _,alias in ipairs(order) do
        local e=aliasEntry[alias]
        net.WriteString(alias)
        net.WriteBool(e and e.eliminated or eliminated[alias] or false)
        net.WriteString(self.reveal and self.reveal[alias] or "")
    end
    net.Broadcast()

    for p in pairs(self.members or {}) do if validPlayer(p) then p:Freeze(false) end end
end
local function admin(p) return not IsValid(p) or p:IsAdmin() end
concommand.Add("assassin_next",function(p)
    if not admin(p) then return end
    NextRound("assassin")
    if validPlayer(p) then p:ChatPrint("Следующий режим: Assassin") end
end)
concommand.Add("assassin_end",function(p)
    if not admin(p) or CurrentRound()~=MODE then return end
    MODE.winner=nil;MODE.failed=nil;zb:EndRound()
end)
hook.Add("ZB_PreRoundStart","Assassin.Reset",function()
    MODE.token={}
    for _,p in player.Iterator() do
        if p.PlayerClassName=="assassin_civilian" then p:SetPlayerClass() end
        if MODE.looks and MODE.looks[p] then MODE:RestoreLook(p) end
        if MODE.members and MODE.members[p] and validPlayer(p) then p:Freeze(false) end
    end
    MODE.members={};MODE.ring=nil;MODE.damagePermits=nil;MODE.threats=nil
end)
