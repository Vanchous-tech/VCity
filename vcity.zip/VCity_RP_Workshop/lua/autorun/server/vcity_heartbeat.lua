-- V-City RP: server-only heartbeat. Configuration lives in DATA, never in Workshop/client Lua.
-- No console output on success and no restart commands. Dedicated server only.
local FILE = "vcity_monitor/config.json"
local INTERVAL = 180
local nextSend = 0
local pendingUntil = 0
local function pulse()
    local now = SysTime()
    if now < nextSend or now < pendingUntil then return end
    nextSend = now + INTERVAL
    local raw = file.Read(FILE, "DATA")
    local cfg = raw and util.JSONToTable(raw) or nil
    if not istable(cfg) or not isstring(cfg.url) or not isstring(cfg.secret) or
        not cfg.url:match("^https://[%w%-%.]+%.workers%.dev/pulse$") or
        #cfg.secret < 32 or #cfg.secret > 128 or cfg.secret:find("[%c%s]") then
        if not VCityMonitorWarned then
            VCityMonitorWarned = true
            print("[V-City Monitor] Нет корректной серверной конфигурации data/vcity_monitor/config.json; сигнал отключён.")
        end
        return
    end
    VCityMonitorWarned = false
    pendingUntil = now + 30
    HTTP({url = cfg.url, method = "POST", headers = {["X-VCity-Heartbeat"] = cfg.secret}, body = "", timeout = 15,
        success = function(code)
            pendingUntil = 0
            if code ~= 200 then print("[V-City Monitor] Сигнал не принят, HTTP " .. tostring(code)) end
        end,
        failed = function()
            pendingUntil = 0
            print("[V-City Monitor] Не удалось отправить сигнал. Проверь сеть и адрес Worker.")
        end})
end
-- GetGameDescription runs even during dedicated-server hibernation unless hide_server is set;
-- Think is a fallback while the server is active. Return nothing to leave the game description alone.
hook.Add("GetGameDescription", "VCityMonitor.Heartbeat", pulse)
hook.Add("Think", "VCityMonitor.HeartbeatFallback", pulse)
