-- V-City RP 1.0.0-beta.1 — CLIENT. Точки захвата: HUD в круге, метки по расстоянию, слой на карте zc_map.
local RP = VCityRP
local points = {}

local COL = {
    [""] = Color(190, 190, 190), usa = Color(110, 150, 225), ru = Color(225, 90, 80),
}
local NAMES = { [""] = "Нейтральная", usa = "США", ru = "РФ и Дрина" }

net.Receive("vcity_rp_points", function()
    local n = net.ReadUInt(5)
    points = {}
    for i = 1, n do
        points[i] = {
            name = net.ReadString(),
            pos = Vector(net.ReadFloat(), net.ReadFloat(), net.ReadFloat()),
            r = net.ReadUInt(12),
            owner = net.ReadString(),
            cap = net.ReadString(),
            prog = net.ReadUInt(7),
            contested = net.ReadBool(),
        }
    end
end)

surface.CreateFont("VCityRP.PointBig", { font = "Arial", size = 22, weight = 700, extended = true })
surface.CreateFont("VCityRP.PointSmall", { font = "Arial", size = 15, weight = 500, extended = true })

local function Inside(ply, p)
    local pos = ply:GetPos()
    local dx, dy = pos.x - p.pos.x, pos.y - p.pos.y
    return dx * dx + dy * dy <= p.r * p.r and math.abs(pos.z - p.pos.z) <= 300
end

hook.Add("HUDPaint", "VCityRP.PointsHUD", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() or #points == 0 then return end

    local sw = ScrW()
    local current

    for _, p in ipairs(points) do
        local dist = ply:GetPos():Distance(p.pos)
        if Inside(ply, p) then current = p end

        -- метка на расстоянии (не дальше 50 м), если точка в поле зрения
        if dist * 0.01905 <= 50 and not current then
            local s = (p.pos + Vector(0, 0, 120)):ToScreen()
            if s.visible then
                local c = COL[p.owner] or COL[""]
                draw.SimpleTextOutlined(p.name, "VCityRP.PointSmall", s.x, s.y, c, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, color_black)
                draw.SimpleTextOutlined(math.floor(dist * 0.01905) .. " м", "VCityRP.PointSmall", s.x, s.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
            end
        end
    end

    if not current then return end

    local w, h = 360, 74
    local x, y = sw / 2 - w / 2, 70
    surface.SetDrawColor(10, 11, 13, 215)
    surface.DrawRect(x, y, w, h)
    local oc = COL[current.owner] or COL[""]
    surface.SetDrawColor(oc)
    surface.DrawOutlinedRect(x, y, w, h, 2)

    draw.SimpleText(current.name, "VCityRP.PointBig", sw / 2, y + 6, color_white, TEXT_ALIGN_CENTER)
    draw.SimpleText("Владелец: " .. (NAMES[current.owner] or "?"), "VCityRP.PointSmall", sw / 2, y + 32, oc, TEXT_ALIGN_CENTER)

    local bx, by, bw, bh = x + 14, y + 52, w - 28, 12
    surface.SetDrawColor(40, 42, 48, 240)
    surface.DrawRect(bx, by, bw, bh)

    if current.contested then
        draw.SimpleText("ИДЁТ БОЙ — захват остановлен", "VCityRP.PointSmall", sw / 2, by - 2, Color(255, 200, 80), TEXT_ALIGN_CENTER)
    elseif current.prog > 0 then
        local c = COL[current.cap] or COL[""]
        surface.SetDrawColor(c)
        surface.DrawRect(bx, by, bw * current.prog / 100, bh)
    end
end)

-- слой на карте zc_map (px на юнит = s)
hook.Add("ZCMap_DrawOverlay", "VCityRP.PointsMap", function(w, h, W2S, s)
    surface.SetFont("VCityRP.PointSmall")
    for _, p in ipairs(points) do
        local sx, sy = W2S(w, h, p.pos.x, p.pos.y)
        local c = COL[p.owner] or COL[""]
        local rad = math.max(p.r * s, 8)

        surface.SetDrawColor(c.r, c.g, c.b, 50)
        draw.NoTexture()
        local seg, poly = 28, {}
        for i = 0, seg - 1 do
            local a = math.rad(i / seg * 360)
            poly[#poly + 1] = { x = sx + math.cos(a) * rad, y = sy + math.sin(a) * rad }
        end
        surface.DrawPoly(poly)
        surface.SetDrawColor(c.r, c.g, c.b, 230)
        for i = 1, #poly do
            local a, b = poly[i], poly[i % #poly + 1]
            surface.DrawLine(a.x, a.y, b.x, b.y)
        end

        local text = p.name .. (p.prog > 0 and (" " .. p.prog .. "%") or "")
        draw.SimpleTextOutlined(text, "VCityRP.PointSmall", sx, sy, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
    end
end)

-- ============================================================
-- Граница зоны в мире (0.6.5): стенка + яркая линия по земле.
-- Клиентские настройки:
--   vcity_rp_zone_draw 1|0     — рисовать границу
--   vcity_rp_zone_dist <м>     — с какой дистанции видно границу (по умолч. 250)
--   vcity_rp_zone_height <юн.> — высота стенки (по умолч. 220)
-- ============================================================
local cvZoneDraw = CreateClientConVar("vcity_rp_zone_draw", "1", true, false, "Draw capture zone boundary in world")
local cvZoneDist = CreateClientConVar("vcity_rp_zone_dist", "250", true, false, "Max distance (m) to see zone boundary")
local cvZoneH = CreateClientConVar("vcity_rp_zone_height", "220", true, false, "Zone wall height (units)")

local UNIT_M = 0.01905
local GROUND_REFRESH = 5 -- сек: как часто пересчитывать высоту земли под границей

-- высота земли под каждой вершиной кольца (кеш на точку)
local function UpdateGround(p)
    local seg = math.Clamp(math.floor(p.r / 10), 24, 96)
    p._seg, p._gz, p._gt = seg, {}, CurTime()
    for i = 0, seg - 1 do
        local a = i / seg * math.pi * 2
        local x, y = p.pos.x + math.cos(a) * p.r, p.pos.y + math.sin(a) * p.r
        local tr = util.TraceLine({
            start = Vector(x, y, p.pos.z + 400),
            endpos = Vector(x, y, p.pos.z - 600),
            mask = MASK_SOLID_BRUSHONLY,
        })
        p._gz[i] = (tr.Hit and not tr.StartSolid) and tr.HitPos.z or p.pos.z
    end
end

local function Quad2(a, b, c, d, col)
    render.DrawQuad(a, b, c, d, col)
    render.DrawQuad(d, c, b, a, col) -- обратная сторона (видно изнутри и снаружи)
end

hook.Add("PostDrawTranslucentRenderables", "VCityRP.PointsZone3D", function(bDepth, bSkybox, b3DSkybox)
    if bSkybox or b3DSkybox then return end
    if not cvZoneDraw:GetBool() or #points == 0 then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local epos = ply:GetPos()
    local maxDist = cvZoneDist:GetFloat() / UNIT_M
    local H = cvZoneH:GetFloat()
    local now = CurTime()

    render.SetColorMaterial()

    for _, p in ipairs(points) do
        local dx, dy = epos.x - p.pos.x, epos.y - p.pos.y
        local d = math.sqrt(dx * dx + dy * dy)
        local toEdge = math.abs(d - p.r) -- расстояние до самой границы
        if toEdge <= maxDist then
            if not p._gz or now - p._gt > GROUND_REFRESH then UpdateGround(p) end

            local c = COL[p.owner] or COL[""]
            -- ближе к границе — ярче; вдали плавно гаснет
            local k = 1 - math.Clamp((toEdge - maxDist * 0.3) / (maxDist * 0.7), 0, 1)
            local inside = d <= p.r
            local wallA = (inside and 28 or 45) * k
            local lineA = 230 * (0.35 + 0.65 * k)
            if p.contested then
                local pulse = 0.5 + 0.5 * math.sin(now * 6)
                c = Color(255, 190 + 40 * pulse, 60)
                wallA = wallA * (1 + pulse)
            end

            local wallCol = Color(c.r, c.g, c.b, wallA)
            local lineCol = Color(c.r, c.g, c.b, lineA)
            local topCol = Color(c.r, c.g, c.b, lineA * 0.5)
            local seg, gz = p._seg, p._gz

            for i = 0, seg - 1 do
                local j = (i + 1) % seg
                local a1 = i / seg * math.pi * 2
                local a2 = (i + 1) / seg * math.pi * 2
                local x1, y1 = p.pos.x + math.cos(a1) * p.r, p.pos.y + math.sin(a1) * p.r
                local x2, y2 = p.pos.x + math.cos(a2) * p.r, p.pos.y + math.sin(a2) * p.r
                local z1, z2 = gz[i], gz[j]

                local b1, b2 = Vector(x1, y1, z1 + 3), Vector(x2, y2, z2 + 3)
                local t1, t2 = Vector(x1, y1, z1 + H), Vector(x2, y2, z2 + H)
                local l1, l2 = Vector(x1, y1, z1 + 14), Vector(x2, y2, z2 + 14)
                local m1, m2 = Vector(x1, y1, z1 + H - 8), Vector(x2, y2, z2 + H - 8)

                Quad2(b1, b2, t2, t1, wallCol) -- стенка
                Quad2(b1, b2, l2, l1, lineCol) -- яркая полоса у земли
                Quad2(m1, m2, t2, t1, topCol)  -- верхняя кромка
            end
        end
    end
end)
