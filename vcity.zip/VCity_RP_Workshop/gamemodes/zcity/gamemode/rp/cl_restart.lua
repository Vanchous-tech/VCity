-- V-City RP 1.0.0-beta.1 — CLIENT ONLY. Draws the restart notice over the world.
--
-- Same look as the rest of 0.3.5: no panel and no blur, orange text with a hard shadow, so it stays
-- readable on sand and sky. The block fades in, holds, then fades out.
local RP = VCityRP

RP.RestartNotice = nil

local function accent()
    return (RP.UI and RP.UI.accent) or Color(255, 128, 40)
end

local function text()
    return (RP.UI and RP.UI.text) or Color(235, 235, 238)
end

net.Receive(RP.NetRestart, function()
    local message = net.ReadString()
    local sub = net.ReadString()
    local seconds = net.ReadUInt(8)
    local now = RealTime()
    RP.RestartNotice = {
        text = message,
        sub = sub,
        start = now,
        expires = now + math.Clamp(seconds, 3, 240)
    }
    if chat and chat.AddText then
        chat.AddText(accent(), "[V-CITY] ", text(), message)
    end
    hook.Run("VCityRP.RestartNoticeShown", message, sub)
end)

-- 0 -> 1 while fading in, 1 -> 0 while fading out.
function RP.RestartNoticeAlpha(now, notice)
    if not notice or type(now) ~= "number" then return 0 end
    local span = math.max(0.001, notice.expires - notice.start)
    local show = math.min(0.4, span / 3)
    local hide = math.min(0.8, span / 2)
    local elapsed = now - notice.start
    local remaining = notice.expires - now
    if elapsed < 0 or remaining <= 0 then return 0 end
    return math.Clamp(math.min(elapsed / show, remaining / hide), 0, 1)
end

hook.Add("HUDPaint", "VCityRP.RestartNotice", function()
    local notice = RP.RestartNotice
    if not notice then return end
    local now = RealTime()
    local alpha = RP.RestartNoticeAlpha(now, notice)
    if alpha <= 0 then
        if now >= notice.expires then RP.RestartNotice = nil end
        return
    end
    local main = (RP.UI and RP.UI.accent) or Color(255, 128, 40)
    local sub = text()
    local layer = Color(main.r, main.g, main.b, math.floor(255 * alpha))
    local shade = RP.TextShadow and RP.TextShadow() or Color(0, 0, 0, 0)
    local soft = Color(sub.r, sub.g, sub.b, math.floor(210 * alpha))
    local shadow = Color(shade.r or 0, shade.g or 0, shade.b or 0, math.floor((shade.a or 0) * alpha))
    local centerX = ScrW() / 2
    local top = ScrH() * 0.14
    local draw_text = RP.ShadowText or draw.SimpleText
    draw_text(notice.text, "VCityRP.Title", centerX, top, layer, shadow, TEXT_ALIGN_CENTER)
    if notice.sub and notice.sub ~= "" then
        draw_text(notice.sub, "VCityRP.Small", centerX, top + 34, soft, shadow, TEXT_ALIGN_CENTER)
    end
end)

-- Clients that join in the middle of a cycle ask for the status once, so a fresh player also learns
-- the restart time instead of learning it only at the next announcement.
hook.Add("InitPostEntity", "VCityRP.RestartAsk", function()
    timer.Simple(8, function()
        if not RP.RestartWanted() then return end
        net.Start(RP.NetRestartAsk)
        net.SendToServer()
    end)
end)

function RP.RestartWanted()
    local convar = GetConVar and GetConVar("vcity_rp_restart")
    if convar and convar.GetBool and not convar:GetBool() then return false end
    return true
end
