-- Client-only player interaction wheel. Existing server messages/permissions are unchanged.
local RP=VCityRP
RP.RadialUIVersion="1.0.0-beta.1"

-- Angles are clockwise from +X; first sector centred on twelve o'clock.
function RP.RadialSectorAt(x,y,inner,outer,count)
    local radius=math.sqrt(x*x+y*y)
    if radius<inner or radius>outer or count<1 then return nil end
    local angle=(math.deg(math.atan2(y,x))+135)%360
    local width=360/count
    local index=math.floor(angle/width)+1
    local within=angle%width
    if within<1.6 or within>width-1.6 then return nil end -- visual gaps are not clickable
    return index
end
local function sector(cx,cy,inner,outer,first,last,color)
    surface.SetDrawColor(color);draw.NoTexture()
    local steps=math.max(8,math.ceil((last-first)/4))
    for step=0,steps-1 do
        local a=math.rad(first+(last-first)*step/steps)
        local b=math.rad(first+(last-first)*(step+1)/steps)
        -- Convex quads, not a concave DrawPoly annulus (Source clips concave polygons).
        surface.DrawPoly({
            {x=cx+math.cos(a)*inner,y=cy+math.sin(a)*inner},
            {x=cx+math.cos(a)*outer,y=cy+math.sin(a)*outer},
            {x=cx+math.cos(b)*outer,y=cy+math.sin(b)*outer},
            {x=cx+math.cos(b)*inner,y=cy+math.sin(b)*inner}
        })
    end
end
local function text(parent,value,x,y,width)
    local l=vgui.Create("DLabel",parent);l:SetFont("VCityRP.Body");l:SetTextColor(RP.UI.text);l:SetPos(x,y);l:SetSize(width,28);l:SetText(value);return l
end
local function packet(data)
    net.Start(RP.NetInteractionAction)
    if RP.WriteJSON(data) then net.SendToServer() end
end
local function prompt(owner,title,description,default,callback)
    local f=vgui.Create("DFrame");f:SetTitle("");f:ShowCloseButton(false);f:SetSize(math.min(460,ScrW()-32),215);f:Center();f:MakePopup()
    f.Paint=function(self,w,h)
        draw.RoundedBox(4,0,0,w,h,RP.UI.bg);surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,w,h,1)
        draw.SimpleText(title,"VCityRP.Title",20,18,RP.UI.accent)
    end
    text(f,description,20,62,f:GetWide()-40)
    local entry=vgui.Create("DTextEntry",f);entry:SetPos(20,100);entry:SetSize(f:GetWide()-40,30);entry:SetText(tostring(default));entry:SetNumeric(true);entry:RequestFocus()
    entry.Paint=function(self,w,h) draw.RoundedBox(3,0,0,w,h,RP.UI.row);self:DrawTextEntryText(RP.UI.text,RP.UI.selection,RP.UI.text) end
    local ok=RP.UIButton(f,"Продолжить",function()
        local amount=tonumber(entry:GetValue())
        if not amount or amount~=math.floor(amount) or amount<1 or amount>2000000000 then notification.AddLegacy("Нужна целая положительная сумма.",NOTIFY_ERROR,4) return end
        f:Close();callback(amount)
    end);ok:SetPos(f:GetWide()-190,153);ok:SetSize(170,32);ok.Primary=true
    local cancel=RP.UIButton(f,"Назад",function() f:Close();if IsValid(owner) then owner:MakePopup() end end);cancel:SetPos(20,153);cancel:SetSize(110,32)
    f.OnKeyCodePressed=function(self,key) if key==KEY_ESCAPE then self:Close();if IsValid(owner) then owner:MakePopup() end end end
end
function RP.OpenInteractionRadial(data)
    if IsValid(RP.InteractionFrame) then RP.InteractionFrame:Close() end
    local size=math.min(630,ScrW()-32,ScrH()-32)
    local frame=vgui.Create("DFrame");RP.InteractionFrame=frame
    frame:SetSize(size,size);frame:Center();frame:SetTitle("");frame:ShowCloseButton(false);frame:SetDraggable(false);frame:MakePopup()
    -- Belt and braces: the default VGUI frame background stays off even if the paint is replaced.
    if frame.SetPaintBackgroundEnabled then frame:SetPaintBackgroundEnabled(false) end
    local wheel=vgui.Create("DPanel",frame);wheel:SetPos(12,78);wheel:SetSize(size-24,size-138);wheel:SetMouseInputEnabled(true)
    local layer,page,hovered="main",1,nil
    local options={};local hover={};local info="Наведи на сектор и нажми ЛКМ"
    local rebuild
    local function back() layer="main";page=1;rebuild();RP.PlayUISound("release") end
    local function close() frame:Close();RP.PlayUISound("release") end
    local function transferMoney()
        prompt(frame,"Передать деньги","Сумма в "..(RP.GetSettings().currency or "$"),100,function(amount)
            if amount>(data.money or 0) then notification.AddLegacy("Недостаточно денег в открытом меню; обнови взаимодействие по E.",NOTIFY_ERROR,4) return end
            Derma_Query("Передать "..RP.MoneyText(amount).." игроку "..data.name.."?","Подтверждение","Передать",function()
                packet({action="money",amount=amount,token=data.token});close()
            end,"Назад",function() if IsValid(frame) then frame:MakePopup() end end)
        end)
    end
    local function ammoOffer(record)
        prompt(frame,"Передать патроны",record.name.." · в инвентаре: "..record.count,math.min(30,record.count),function(amount)
            if amount>record.count then notification.AddLegacy("В открытом инвентаре меньше патронов.",NOTIFY_ERROR,4) return end
            packet({action="ammo",ammo=record.id,amount=amount,token=data.token});close()
        end)
    end
    rebuild=function()
        options={};hover={};hovered=nil
        if layer=="main" then
            options={
                {name="Деньги",hint="Передать сумму",mark="$",action=transferMoney},
                {name="Предметы",hint="Оружие / SWEP",mark="2",action=function() layer="items";page=1;rebuild() end},
                {name="Патроны",hint="Выбрать тип",mark="3",action=function() layer="ammo";page=1;rebuild() end},
                {name="Информация",hint="Роль / профессия",mark="i",action=function()
                    info=data.name.." / "..data.role
                end}
            }
            if data.canSeat then
                options[#options+1]={name="В машину",hint="Посадить связанного пассажиром",mark="+",action=function()
                    packet({action="seat_prisoner",token=data.token});close()
                end}
            end
        else
            local records=layer=="items" and (data.items or {}) or (data.ammo or {})
            local start=(page-1)*4+1
            for index=start,math.min(start+3,#records) do
                local record=records[index]
                options[#options+1]={name=record.name,hint=layer=="ammo" and ("Доступно: "..record.count) or record.class,mark=tostring(#options+1),action=function()
                    if layer=="ammo" then ammoOffer(record)
                    else
                        packet({action="weapon",entity=record.entity,token=data.token});close()
                    end
                end}
            end
            if #records>4 then options[#options+1]={name="Далее",hint="Следующая страница",mark=">",action=function() page=page%math.ceil(#records/4)+1;rebuild() end} end
            options[#options+1]={name="Назад",hint="Главное кольцо",mark="<",action=back}
            if #records==0 then
                if layer=="items" then info="Нет доступных для передачи предметов"
                else info="Нет патронов для передачи" end
            end
        end
    end
    local function geometry(w,h)
        local r=math.min(w,h)*0.46
        return w/2,h/2,r*0.48,r
    end
    wheel.Think=function(self)
        local x,y=self:LocalCursorPos();local cx,cy,inner,outer=geometry(self:GetWide(),self:GetTall())
        local nextHover=RP.RadialSectorAt(x-cx,y-cy,inner,outer,#options)
        if nextHover~=hovered and nextHover then RP.PlayUISound("hover") end
        hovered=nextHover
    end
    local growth=RP.UI.HoverGrowth or 0.028
    local shadow=Color(0,0,0,235)
    wheel.Paint=function(self,w,h)
        local cx,cy,inner,outer=geometry(w,h)
        for index,option in ipairs(options) do
            hover[index]=Lerp(math.Clamp(FrameTime()*(RP.UI.HoverSpeed or 16),0,1),hover[index] or 0,hovered==index and 1 or 0)
            local amount=hover[index]
            -- The hovered sector swells slightly, exactly like the F4 role buttons.
            local scale=1+growth*amount
            local segInner,segOuter=inner*scale,outer*scale
            local first=-135+(index-1)*360/#options+1.7;local last=-135+index*360/#options-1.7
            local color=RP.UIColor(RP.UI.row,RP.UI.active,amount)
            sector(cx,cy,segInner,segOuter,first,last,color)
            sector(cx,cy,segOuter-1.4,segOuter,first,last,RP.UIColor(RP.UI.line,RP.UI.accent,amount))
            if amount>0.01 then sector(cx,cy,segInner,segInner+2,first,last,Color(255,128,40,amount*220)) end
            local angle=math.rad((first+last)/2);local radius=(segInner+segOuter)/2
            local x,y=cx+math.cos(angle)*radius,cy+math.sin(angle)*radius
            draw.ShadowText(option.mark,"VCityRP.Title",x,y-24,RP.UI.accent,shadow,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            draw.ShadowText(option.name,"VCityRP.Body",x,y+4,amount>0.1 and RP.UI.accentText or RP.UI.text,shadow,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            draw.ShadowText(tostring(index),"VCityRP.Small",x,y+26,RP.UI.muted,shadow,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        end
    end
    -- Public helper: the drawn geometry of one sector, so hit tests and tests can agree.
    function RP.RadialSectorGeometry(w,h,count,grow)
        local cx,cy,inner,outer=geometry(w,h)
        local scale=1+(growth or 0)*(grow or 0)
        return cx,cy,inner*scale,outer*scale
    end
    local function activate(index)
        local option=options[index]
        if option then RP.PlayUISound("release");option.action() end
    end
    wheel.OnMousePressed=function(self,code)
        if code==MOUSE_RIGHT then if layer=="main" then close() else back() end return end
        if code~=MOUSE_LEFT then return end
        local x,y=self:LocalCursorPos();local cx,cy,inner,outer=geometry(self:GetWide(),self:GetTall())
        if (x-cx)^2+(y-cy)^2<inner*inner then if layer=="main" then close() else back() end
        else activate(RP.RadialSectorAt(x-cx,y-cy,inner,outer,#options)) end
    end
    -- No panel behind the ring: the wheel floats over the world like the F4 menu does.
    -- Text keeps a hard shadow so it stays readable on sand, sky or a dark interior.
    frame.Paint=function(self,w,h)
        -- Role, centre and bottom hints intentionally hidden; controls still work.
    end
    frame.OnKeyCodePressed=function(self,key)
        if key==KEY_ESCAPE or key==KEY_E then close() return end
        for index=1,6 do if key==KEY_1+index-1 then activate(index) return end end
    end
    frame.OnRemove=function(self) if RP.InteractionFrame==self then RP.InteractionFrame=nil end end
    rebuild();RP.PlayUISound("release")
end
