-- V-City RP 1.0.0-beta.1 — CLIENT. Защитные заплатки для чужого кода Z-City (сам Z-City не меняем).
-- 1) PostDrawTranslucentRenderables «huyCock333» (homigrad_base/sh_worldmodel.lua:888) вызывает
--    self:DrawLaser() у каждого оружия из hg.weapons, а у части оружия метода нет — ошибка каждый кадр.
--    Ставим пустую заглушку и один раз пишем в консоль класс такого оружия.
local warned = {}

local function Patch()
    local hooks = hook.GetTable().PostDrawTranslucentRenderables
    local original = hooks and hooks["huyCock333"]
    if not isfunction(original) or VCityRP.__laserPatched then return end
    VCityRP.__laserPatched = true

    hook.Add("PostDrawTranslucentRenderables", "huyCock333", function(...)
        local list = hg and hg.weapons
        if istable(list) then
            for i = 1, #list do
                local wep = list[i]
                if IsValid(wep) and not wep.DrawLaser then
                    wep.DrawLaser = function() end
                    local class = wep:GetClass()
                    if not warned[class] then
                        warned[class] = true
                        print("[V-City] у оружия «" .. class .. "» нет DrawLaser — поставлена заглушка (ошибка Z-City подавлена).")
                    end
                end
            end
        end
        return original(...)
    end)
end

hook.Add("InitPostEntity", "VCityRP.PatchLaser", function() timer.Simple(3, Patch) end)
timer.Simple(5, Patch)
