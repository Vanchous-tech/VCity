-- Server-authoritative roles, immediate role-change respawn and configured spawn setup.
local RP=VCityRP
for _,name in ipairs({RP.NetSelect,RP.NetResult,RP.NetOpen}) do util.AddNetworkString(name) end
local function result(ply,ok,payload)
    net.Start(RP.NetResult);net.WriteBool(ok);net.WriteString(payload or "");net.Send(ply)
end
function RP.ApplyRole(ply,id)
    local role=RP.RoleByID(id)
    if not IsValid(ply) or not ply:IsPlayer() or not role then return false end
    local previous=RP.GetRole(ply)
    if id~=RP.DefaultRole then ply:SetNW2String(RP.ProfessionNWKey,"") end
    ply:SetNW2String(RP.RoleNWKey,id)
    role=RP.GetRole(ply)
    if zb.GiveRole then zb.GiveRole(ply,RP.GetRoleLabel(role),role.Color) end
    if previous.ID~=id then hook.Run("VCityRP.RoleChanged",ply,role,previous) end
    return true
end
function RP.InitializePlayer(ply)
    if not IsValid(ply) or ply.VCityRPInitialized then return end
    ply.VCityRPInitialized=true;ply.initialspawn=nil
    ply:SetNW2String(RP.ProfessionNWKey,"")
    ply.Karma=nil;ply.Guilt=nil
    if ply.SetNetVar then ply:SetNetVar("Karma",nil) end
    RP.ApplyRole(ply,RP.DefaultRole)
    timer.Simple(1,function()
        if not IsValid(ply) then return end
        if ply.SyncVars then ply:SyncVars() end
        RP.SendPublicConfig(ply)
        RP.ApplyRole(ply,RP.GetRole(ply).ID)
    end)
end
hook.Add("PlayerInitialSpawn","VCityRP.DefaultCivilian",RP.InitializePlayer)

function RP.RoleAccess(ply,id)
    local cfg=RP.Config.roles[id]
    if not cfg or not cfg.enabled then return false,"Роль отключена." end
    local locked=RP.LockReason and RP.LockReason(ply,id)
    if locked then return false,locked end
    if #cfg.allowedGroups>0 and not ply:IsSuperAdmin() then
        local permitted=false
        for _,group in ipairs(cfg.allowedGroups) do if ply:GetUserGroup()==group then permitted=true end end
        if not permitted then return false,"У тебя нет доступа к этой роли." end
    end
    if cfg.maxPlayers>0 then
        local occupied=0
        for _,other in ipairs(player.GetAll()) do
            if other~=ply and RP.GetRole(other).ID==id then occupied=occupied+1 end
        end
        if occupied>=cfg.maxPlayers then return false,"Все места этой роли заняты." end
    end
    return true
end
function RP.TryChooseRole(ply,id,chosenSub)
    if not IsValid(ply) or not ply:IsPlayer() or not RP.Roles[id] then return false,"Такой роли нет." end
    local previous=RP.GetRole(ply)
    if chosenSub~=nil and (type(chosenSub)~="string" or not RP.SubclassAvailable(RP.Roles[id],chosenSub)) then
        return false,"Подкласс недоступен этому званию."
    end
    if previous.ID==id then
        if chosenSub~=nil and chosenSub~=ply:GetNW2String(RP.SubNWKey,"") then
            local ok,message=RP.SetSubclass(ply,chosenSub)
            if not ok then return false,message end
        end
        return true,id -- changing subclass alone never heals or respawns
    end
    local previousSub=ply:GetNW2String(RP.SubNWKey,"")
    local allowed,reason=RP.RoleAccess(ply,id)
    if not allowed then return false,reason end
    if not ply:Alive() or ply:Team()==TEAM_SPECTATOR then return false,"Сначала возродись." end
    if IsValid(ply.FakeRagdoll) or (ply.organism and ply.organism.incapacitated) then return false,"Нельзя менять роль в ragdoll или без сознания." end
    if (ply.VCityRPNextRoleChange or 0)>CurTime() then return false,"Смена роли пока на cooldown." end
    local permission,message=hook.Run("VCityRP.CanChooseRole",ply,RP.RoleByID(id),previous)
    if permission==false then return false,message or "Роль недоступна." end
    local settings=RP.GetSettings()
    ply.VCityRPNextRoleChange=CurTime()+settings.roleChangeCooldown
    RP.ApplyRole(ply,id)
    if chosenSub~=nil then RP.SetSubclass(ply,chosenSub) end
    if settings.respawnOnRoleChange then
        if ply:InVehicle() then ply:ExitVehicle() end
        local ok,err=pcall(ply.Spawn,ply)
        if not ok then
            RP.ApplyRole(ply,previous.ID)
            ply:SetNW2String(RP.SubNWKey,previousSub)
            ErrorNoHalt("[V-City RP] Role respawn error: "..tostring(err).."\n")
            return false,"Ошибка переспавна; подробности в консоли сервера."
        end
    end
    return true,id
end
net.Receive(RP.NetSelect,function(bits,ply)
    if not IsValid(ply) or not ply:IsPlayer() or bits>1024 then return end
    if (ply.VCityRPNextPacket or 0)>CurTime() then return end
    ply.VCityRPNextPacket=CurTime()+0.25
    local id=net.ReadString()
    if #id>40 then result(ply,false,"Некорректная роль.") return end
    local chosenSub
    if net.BytesLeft()>0 then chosenSub=net.ReadString() end
    if chosenSub and #chosenSub>40 then result(ply,false,"Некорректный подкласс.") return end
    local ok,message=RP.TryChooseRole(ply,id,chosenSub)
    result(ply,ok,message)
end)
function RP.OpenMenuForPlayer(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if (ply.VCityRPNextMenu or 0)>CurTime() then return true end
    ply.VCityRPNextMenu=CurTime()+0.2
    RP.SendPublicConfig(ply)
    net.Start(RP.NetOpen);net.Send(ply)
    return true
end
hook.Add("ShowSpare2","VCityRP.F4",RP.OpenMenuForPlayer)

-- Also called by the tiny hook in the original appearance module.
-- This prevents a late cached appearance response from replacing a configured uniform.
function RP.ApplyConfiguredAppearance(ply,appearance)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    local cfg=ply.VCityRPSpawnConfig or RP.GetRoleSettings(RP.GetRole(ply).ID)
    if cfg.model=="" or not util.IsValidModel(cfg.model) then return false end
    local changed=ply:GetModel()~=cfg.model
    if changed then ply:SetModel(cfg.model) end
    ply:SetSubMaterial()
    ply:SetBodyGroups("00000000000000000000000000000000")
    ply:SetSkin(math.Clamp(cfg.skin,0,math.max(ply:SkinCount()-1,0)))
    for index,value in pairs(cfg.bodygroups) do
        local i=tonumber(index)
        if i and i<ply:GetNumBodyGroups() then ply:SetBodygroup(i,math.Clamp(value,0,math.max(ply:GetBodygroupCount(i)-1,0))) end
    end
    if changed and ply.SetupHands then ply:SetupHands() end
    local source=appearance or ply.CachedAppearance or ply.CurAppearance or {}
    ply.CurAppearance=table.Copy(source)
    ply.CurAppearance.AModel=cfg.model
    if source.AName then ply:SetNWString("PlayerName",source.AName) end
    if ply.SetNetVar then ply:SetNetVar("Accessories",{}) end
    return true
end

function RP.PlaceAtRoleSpawn(ply,cfg)
    local points=cfg.spawns[game.GetMap()]
    if not points or #points==0 then return false end
    local start=math.random(#points)
    for offset=0,#points-1 do
        local point=points[(start+offset-1)%#points+1]
        local pos=Vector(point.x,point.y,point.z)
        if util.IsInWorld(pos) then
            local mins,maxs=ply:GetHull()
            local tr=util.TraceHull({start=pos,endpos=pos,mins=mins,maxs=maxs,filter=ply,mask=MASK_PLAYERSOLID})
            if not tr.StartSolid and not tr.AllSolid and not tr.Hit then
                ply:SetPos(pos);ply:SetEyeAngles(Angle(point.p,point.yaw,point.r));return true
            end
        end
    end
    print("[V-City RP] No free configured spawn for "..RP.GetRole(ply).ID.."; using map spawn.")
    return false
end
function RP.ApplySpawnSettings(ply)
    if not IsValid(ply) or not ply:Alive() or OverrideSpawn then return false end
    local cfg=ply.VCityRPSpawnConfig or RP.GetRoleSettings(RP.GetRole(ply).ID)
    RP.ApplyConfiguredAppearance(ply)
    RP.PlaceAtRoleSpawn(ply,cfg)
    ply:SetMaxHealth(cfg.health);ply:SetHealth(cfg.health)
    ply:SetArmor(cfg.armor)
    ply:SetWalkSpeed(cfg.walkSpeed);ply:SetRunSpeed(cfg.runSpeed);ply:SetJumpPower(cfg.jumpPower)
    if cfg.clearWeapons then ply:StripWeapons() end
    if cfg.clearAmmo then ply:RemoveAllAmmo() end
    if cfg.VCityPresetSlingCount~=nil and RP.SetSlingCount then
        ply.inventory=ply.inventory or ply:GetNetVar("Inventory",{}) or {}
        RP.SetSlingCount(ply.inventory,cfg.VCityPresetSlingCount)
        ply:SetNetVar("Inventory",ply.inventory)
        RP.SyncSlingCapacity(ply)
    end
    if weapons.GetStored("weapon_hands_sh") then ply:Give("weapon_hands_sh",true) end
    local giveWeapons,skipped=RP.LimitSpawnWeapons(ply,cfg.weapons)
    if skipped>0 then ply:ChatPrint("[V-City RP] Не выдано основного оружия: "..skipped..". Нужны два ремня для двух предметов.") end
    for _,class in ipairs(giveWeapons) do
        local weapon=ply:Give(class,true)
        if IsValid(weapon) and cfg.fillClips then
            if weapon:GetMaxClip1()>0 then weapon:SetClip1(weapon:GetMaxClip1()) end
            if weapon:GetMaxClip2()>0 then weapon:SetClip2(weapon:GetMaxClip2()) end
        end
    end
    for name,amount in pairs(cfg.ammo) do
        if game.GetAmmoID(name)>=0 then ply:SetAmmo(amount,name)
        else print("[V-City RP] Unknown ammo type: "..name) end
    end
    ply.armors=ply.armors or {};ply.armors_health=ply.armors_health or {}
    if hg.AddArmor then for _,item in ipairs(cfg.armorItems) do hg.AddArmor(ply,item) end end
    -- Refresh inventory AFTER the loadout, but do not clear newly assigned armor.
    if hg.RenewInv then hg.RenewInv(ply,false) elseif hg.CreateInv then hg.CreateInv(ply) end
    if RP.ApplyAttachmentsToLoadout and #(cfg.attachments or {})>0 then
        ply.VCityRPAttachmentApplied=true
        local count=RP.ApplyAttachmentsToLoadout(ply,cfg.attachments)
        ply.VCityRPAttachmentFailed=count==0
    end
    if ply:HasWeapon("weapon_hands_sh") then ply:SelectWeapon("weapon_hands_sh") end
    if RP.ApplyPresetDetails then RP.ApplyPresetDetails(ply,cfg) end
    -- Внешние аддоны (телефон zc_phone) выдают свои предметы здесь: StripWeapons выше их уже не снесёт.
    hook.Run("RP_RoleLoadout",ply,cfg)
    return true
end
local function queueSetup(ply,delay)
    local serial=ply.VCityRPSpawnSerial or 0
    timer.Simple(delay,function()
        if not IsValid(ply) or not ply:Alive() or serial~=ply.VCityRPSpawnSerial or ply.VCityRPAppliedSerial==serial or OverrideSpawn then return end
        local ok,applied=pcall(RP.ApplySpawnSettings,ply)
        if ok and applied then ply.VCityRPAppliedSerial=serial
        elseif not ok then ErrorNoHalt("[V-City RP] Loadout error: "..tostring(applied).."\n") end
    end)
end
-- Homigrad clears organism/inventory/armor in this event. Apply after all its handlers.
hook.Add("Player Spawn","VCityRP.ConfiguredLoadout",function(ply)
    if not IsValid(ply) or OverrideSpawn then return end
    queueSetup(ply,0)
end)
function RP.PlayerSpawn(ply)
    if OverrideSpawn then return end
    RP.InitializePlayer(ply)
    if not RP.GetRoleSettings(RP.GetRole(ply).ID).enabled then RP.ApplyRole(ply,RP.DefaultRole) end
    local sub=ply:GetNW2String(RP.SubNWKey,"")
    if not RP.SubclassAvailable(RP.GetRole(ply),sub) then ply:SetNW2String(RP.SubNWKey,"") end
    ply.VCityRPSpawnSerial=(ply.VCityRPSpawnSerial or 0)+1
    local cfg=table.Copy(RP.GetRoleSettings(RP.GetRole(ply).ID))
    cfg.VCityPresetDetails=table.Copy(cfg.presetDetails or {})
    cfg.VCityPresetSlingCount=cfg.presetSlingCount
    if RP.ApplyRolePreset then cfg=RP.ApplyRolePreset(ply,cfg) end
    cfg=RP.ApplySubclassLoadout(ply,cfg)
    if RP.ApplySubclassPreset then cfg=RP.ApplySubclassPreset(ply,cfg) end
    ply.VCityRPSpawnConfig=cfg
    ply.initialspawn=nil;ply.viewmode=3;ply.VCityRPRespawnAt=nil
    ply:SuppressHint("OpeningMenu");ply:SuppressHint("Annoy1");ply:SuppressHint("Annoy2")
    ply:UnSpectate();ply:Freeze(false);ply:SetMoveType(MOVETYPE_WALK);ply:SetTeam(1)
    ply:SetHull(Vector(-16,-16,0),Vector(16,16,72));ply:SetHullDuck(Vector(-16,-16,0),Vector(16,16,36))
    if ApplyAppearance then ApplyAppearance(ply,nil,nil,nil,true) end
    if ply.GetRandomSpawn then ply:GetRandomSpawn() end
    RP.ApplyRole(ply,RP.GetRole(ply).ID)
    queueSetup(ply,0.5) -- fallback; skipped if the native Homigrad event already applied this spawn
end
hook.Add("PlayerDeath","VCityRP.RespawnDelay",function(ply)
    ply.VCityRPRespawnAt=CurTime()+RP.GetSettings().respawnDelay
end)
function RP.PlayerDeathThink(ply)
    if ply:Team()==TEAM_SPECTATOR then ply:UnSpectate();ply:SetTeam(1) end
    if (ply.VCityRPRespawnAt or math.huge)>CurTime() then return false end
    local noRespawn=GetConVar("hg_norespawn")
    if noRespawn and noRespawn:GetBool() then return false end
    if ply:KeyPressed(IN_JUMP) or ply:KeyPressed(IN_ATTACK) then ply:Spawn() end
    return false
end
hook.Add("VCityRP.ConfigChanged","VCityRP.RefreshRoleLabels",function()
    for _,ply in ipairs(player.GetAll()) do RP.ApplyRole(ply,RP.GetRole(ply).ID) end
end)
for _,path in pairs(RP.Sounds) do if file.Exists("sound/"..path,"GAME") then resource.AddFile("sound/"..path) end end

hook.Add("ZB_JoinSpectators","VCityRP.NoSpectators",function() return true end)
hook.Add("OnPlayerChangedTeam","VCityRP.RejectSpectatorTeam",function(ply,old,new)
    if new~=TEAM_SPECTATOR then return end
    timer.Simple(0,function()
        if not IsValid(ply) or ply:Team()~=TEAM_SPECTATOR then return end
        ply:UnSpectate();ply:SetTeam(1)
        if not ply:Alive() then ply.VCityRPRespawnAt=CurTime()+RP.GetSettings().respawnDelay end
    end)
end)
