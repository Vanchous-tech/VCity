-- Validated per-weapon ZCLP metadata, also safe to decode during early boot
-- before the weapon/attachment registries are available.
local RP=VCityRP
local function fail(msg) error(msg,0) end
local function sequence(v,label)
    if type(v)~="table" then fail(label..": нужен массив") end
    local out,n={},0
    for k,item in pairs(v) do
        local i=k
        if type(k)=="string" and #k<=8 and k:match("^[1-9]%d*$") then i=tonumber(k) end
        if type(i)~="number" or i<1 or i~=math.floor(i) or out[i]~=nil then fail(label..": неверный индекс") end
        out[i]=item;n=n+1
    end
    for i=1,n do if out[i]==nil then fail(label..": пропуск в массиве") end end
    return out
end
function RP.NormalizePresetDetails(input,allowedWeapons)
    local ok,result=pcall(function()
        if type(input)~="table" then fail("Данные обвесов должны быть таблицей") end
        local allowed={};for _,class in ipairs(allowedWeapons or {}) do allowed[class]=true end
        local out={}
        for class,d in pairs(input) do
            if type(class)~="string" or #class>64 or not (class:match("^weapon_[a-z0-9_]+$") or class=="gmod_tool" or class=="gmod_camera") or not allowed[class] then fail("Данные для оружия вне списка: "..tostring(class)) end
            if type(d)~="table" then fail("Неверные данные обвесов: "..class) end
            for k in pairs(d) do if k~="attachments" and k~="clip1" and k~="clip2" then fail("Неизвестное поле оружия: "..tostring(k)) end end
            local entry={attachments={}}
            local seen={}
            for _,id in ipairs(sequence(d.attachments or {},"Обвесы")) do
                if type(id)~="string" or #id<1 or #id>48 or not id:match("^[%a_][%w_]*$") then fail("Неверный ID обвеса") end
                if not seen[id] then entry.attachments[#entry.attachments+1]=id;seen[id]=true end
            end
            for _,k in ipairs({"clip1","clip2"}) do
                local n=d[k]
                if n~=nil then
                    if type(n)~="number" or n~=n or n<-1 or n>10000 or n~=math.floor(n) then fail("Неверный размер магазина") end
                    entry[k]=n
                end
            end
            out[class]=entry
        end
        return out
    end)
    if not ok then return nil,tostring(result) end
    return result
end
