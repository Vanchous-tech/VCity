local RP=VCityRP
util.AddNetworkString(RP.NetInteraction)
util.AddNetworkString(RP.NetInteractionAction)
RP.ItemOffers={}
local protected={weapon_hands_sh=true,weapon_zombclaws=true,gmod_tool=true,gmod_camera=true,weapon_physgun=true}
function RP.CanInteract(a,b)
    if not IsValid(a) or not a:IsPlayer() or not a:Alive() or not IsValid(b) or not b:IsPlayer() or not b:Alive() or a==b then return false end
    if IsValid(a.FakeRagdoll) or IsValid(b.FakeRagdoll) or a:InVehicle() or b:InVehicle() then return false end
    if a:GetPos():DistToSqr(b:GetPos())>120*120 then return false end
    local tr=util.TraceLine({start=a:EyePos(),endpos=b:WorldSpaceCenter(),filter=a,mask=MASK_SOLID})
    return not tr.Hit or tr.Entity==b
end
function RP.TransferWeapon(from,to,weapon)
    if not RP.CanInteract(from,to) or not IsValid(weapon) or not weapon:IsWeapon() or weapon:GetOwner()~=from then return false,"Предмет больше недоступен." end
    local class=weapon:GetClass()
    if protected[class] or weapon.NoDrop or to:HasWeapon(class) then return false,"Этот предмет нельзя передать или он уже есть у получателя." end
    if RP.CanReceivePrimary and not RP.CanReceivePrimary(to,weapon) then return false,"У получателя нет места для основного оружия." end
    from:DropWeapon(weapon)
    if not IsValid(weapon) then return false,"Предмет не удалось извлечь." end
    to:PickupWeapon(weapon)
    if weapon:GetOwner()~=to then
        from:PickupWeapon(weapon)
        return false,"Получатель не может взять предмет; передача отменена."
    end
    if hg.RenewInv then hg.RenewInv(from,false);hg.RenewInv(to,false) end
    return true
end
local function send(ply,data)
    net.Start(RP.NetInteraction);if RP.WriteJSON(data) then net.Send(ply) end
end
function RP.OpenInteraction(ply,target)
    if not RP.CanInteract(ply,target) then return false end
    local items={}
    for _,weapon in ipairs(ply:GetWeapons()) do
        if not protected[weapon:GetClass()] and not weapon.NoDrop then
            items[#items+1]={entity=weapon:EntIndex(),name=weapon:GetPrintName() or weapon:GetClass(),class=weapon:GetClass()}
        end
    end
    local ammo={}
    for id,count in pairs(ply:GetAmmo()) do if count>0 then ammo[#ammo+1]={id=id,name=game.GetAmmoName(id),count=count} end end
    local token=math.random(1,2147483647)
    ply.VCityRPInteraction={target=target,token=token,expires=CurTime()+45}
    send(ply,{kind="open",target=target:EntIndex(),token=token,name=target:GetNWString("PlayerName",target:Nick()),
        role=RP.GetRoleLabel(RP.GetRole(target)),items=items,ammo=ammo,money=ply:GetNW2Int(RP.MoneyNWKey,0),
        currency=RP.GetSettings().currency or "$",
        canSeat=target.GetNetVar and target:GetNetVar("handcuffed",false)==true or false})
    return true
end
hook.Add("KeyPress","VCityRP.Interact",function(ply,key)
    if key~=IN_USE or not ply:Alive() or ply:KeyDown(IN_ATTACK2) then return end
    if (ply.VCityRPNextUse or 0)>CurTime() then return end
    ply.VCityRPNextUse=CurTime()+0.3
    local target=ply:GetEyeTrace().Entity
    if IsValid(target) and target:IsPlayer() then RP.OpenInteraction(ply,target) end
end)
net.Receive(RP.NetInteractionAction,function(bits,ply)
    if not IsValid(ply) or bits>8192 then return end
    if (ply.VCityRPNextInteraction or 0)>CurTime() then return end
    ply.VCityRPNextInteraction=CurTime()+0.25
    local data=RP.ReadJSON(bits);if not data then return end
    if data.action=="accept" or data.action=="decline" then
        local offer=RP.ItemOffers[data.offer]
        if not offer or offer.to~=ply then return end
        RP.ItemOffers[data.offer]=nil -- consumed before the operation; replay cannot grant twice
        if data.action=="decline" then return end
        if offer.expires<CurTime() or not RP.CanInteract(offer.from,ply) then return end
        local ok,message
        if offer.kind~="weapon" and offer.kind~="ammo" then return end
        if offer.kind=="weapon" then ok,message=RP.TransferWeapon(offer.from,ply,offer.weapon)
        else
            local amount=offer.amount
            if offer.from:GetAmmoCount(offer.ammo)<amount then ok=false;message="Патроны уже недоступны."
            else
                offer.from:RemoveAmmo(amount,offer.ammo);ply:GiveAmmo(amount,offer.ammo,true);ok=true
                if hg.RenewInv then hg.RenewInv(offer.from,false);hg.RenewInv(ply,false) end
            end
        end
        ply:ChatPrint(ok and "Предмет получен." or message)
        if IsValid(offer.from) then offer.from:ChatPrint(ok and "Предмет передан." or message) end
        return
    end
    local session=ply.VCityRPInteraction
    if not session or data.token~=session.token or session.expires<CurTime() or not RP.CanInteract(ply,session.target) then return end
    local target=session.target
    if data.action=="seat_prisoner" then
        local ok,message=RP.SeatCuffedPlayer(ply,target)
        ply:ChatPrint(message)
        if ok then
            target:ChatPrint("Вас посадили на пассажирское место.")
            ply.VCityRPInteraction=nil
        end
        return
    elseif data.action=="money" then
        local ok,message=RP.TransferMoney(ply,target,data.amount)
        if ok then ply:ChatPrint("Передано: "..RP.MoneyText(data.amount));target:ChatPrint("Получено: "..RP.MoneyText(data.amount))
        else ply:ChatPrint(message) end
    elseif data.action=="weapon" or data.action=="ammo" then
        local kind=data.action;local weapon
        if kind=="weapon" then
            if type(data.entity)~="number" or data.entity~=math.floor(data.entity) then return end
            weapon=Entity(data.entity)
            if not IsValid(weapon) or not weapon:IsWeapon() or weapon:GetOwner()~=ply or protected[weapon:GetClass()] or weapon.NoDrop then return end
        else
            if type(data.ammo)~="number" or data.ammo~=math.floor(data.ammo) or not game.GetAmmoName(data.ammo) then return end
            if type(data.amount)~="number" or data.amount~=math.floor(data.amount) or data.amount<1 or data.amount>10000 or ply:GetAmmoCount(data.ammo)<data.amount then return end
        end
        for _,offer in pairs(RP.ItemOffers) do if offer.from==ply or offer.to==target then ply:ChatPrint("Предыдущее предложение ещё ожидает ответа.") return end end
        local id=tostring(math.random(1,2147483647)).."_"..tostring(ply:EntIndex())
        RP.ItemOffers[id]={from=ply,to=target,expires=CurTime()+20,kind=kind,weapon=weapon,ammo=data.ammo,amount=data.amount}
        send(target,{kind="offer",offer=id,from=ply:GetNWString("PlayerName",ply:Nick()),
            label=kind=="weapon" and (weapon:GetPrintName() or weapon:GetClass()) or (game.GetAmmoName(data.ammo).." × "..data.amount)})
        ply:ChatPrint("Предложение отправлено; получатель должен подтвердить.")
    end
end)
timer.Create("VCityRP.OfferCleanup",2,0,function()
    for id,offer in pairs(RP.ItemOffers) do if offer.expires<CurTime() or not IsValid(offer.from) or not IsValid(offer.to) then RP.ItemOffers[id]=nil end end
end)
