-- V-City RP / ZCITY Loadout Presets bridge. Server-owned copies, never player autoloads.
local RP=VCityRP
local NET="vcity_rp_zclp_bridge"
local PATH="vcity_rp/zclp_links.json"
local MAXFILE=524288
util.AddNetworkString(NET)
local links={roles={},subs={}}
local function fail(msg) error(msg,0) end
local function str(v,label,max)
    if type(v)~="string" or #v==0 or #v>(max or 64) or v:find("[%z\1-\31]") then fail(label..": неверная строка") end
    return v
end
-- Only explicitly designated sequences are normalized. Keep numeric object keys
-- elsewhere as strings: SteamID64 and similar identifiers must not be converted.
local function array(v,label)
    if type(v)~="table" then fail(label..": нужен массив") end
    local out,n={},0
    for k,value in pairs(v) do
        n=n+1
        local i=k
        if type(k)=="string" then
            if not k:match("^[1-9]%d*$") or #k>8 then fail(label..": неверный индекс "..k) end
            i=tonumber(k)
        end
        if type(i)~="number" or i<1 or i~=math.floor(i) then fail(label..": неверный индекс") end
        if out[i]~=nil then fail(label..": повтор индекса "..i) end
        out[i]=value
    end
    for i=1,n do if out[i]==nil then fail(label..": пропуск индекса "..i) end end
    return out
end
-- ZCLP metadata may also be encoded as a mixed or sparse JSON object.
local function index(t,i)
    if type(t)~="table" then return nil end
    if t[i]~=nil and t[tostring(i)]~=nil then fail("Повтор индекса в данных ZCLP: "..i) end
    if t[i]~=nil then return t[i] end
    return t[tostring(i)]
end
local function count(v,label)
    if type(v)~="table" then fail(label..": нужна таблица") end
end
local function integer(v,min,max,label)
    if type(v)~="number" or v~=v or v<min or v>max or v~=math.floor(v) then fail(label..": неверное число") end
    return v
end
local builtin={weapon_pistol=true,weapon_357=true,weapon_smg1=true,weapon_ar2=true,weapon_shotgun=true,weapon_crossbow=true,weapon_rpg=true,weapon_frag=true,weapon_crowbar=true,weapon_stunstick=true,weapon_physgun=true,weapon_physcannon=true,gmod_tool=true,gmod_camera=true}
local function weaponClass(v)
    local c=str(v,"Оружие")
    if not c:match("^[a-z][a-z0-9_]*$") or (c:sub(1,7)~="weapon_" and c~="gmod_tool" and c~="gmod_camera") then fail("Недопустимый класс оружия: "..c) end
    if not weapons.GetStored(c) and not builtin[c] then fail("Оружие не найдено на сервере: "..c) end
    return c
end
local function armorID(v)
    local id=str(v,"Броня"):gsub("^ent_armor_","")
    if not id:match("^[a-z][a-z0-9_]*$") then fail("Неверный ID брони: "..id) end
    for _,t in pairs(hg.armor or {}) do if type(t)=="table" and t[id] then return id end end
    fail("Броня не найдена на сервере: "..id)
end
-- Convert ZCLP snapshot to a small well-defined server schema. No untrusted SetInfo.
local function snapshotSlingCount(s)
    if type(s)~="table" then fail("Неверный пресет") end
    if s.accessories~=nil and type(s.accessories)~="table" then fail("Неверные аксессуары") end
    local present=s.accessories and s.accessories.hg_sling==true
    if s.vcitySlingCount==nil then return present and 1 or 0 end
    local n=integer(s.vcitySlingCount,0,2,"Оружейные ремни")
    if (n>0)~=not not present then fail("Количество ремней не соответствует аксессуарам") end
    return n
end
local function fromSnapshot(name,s)
    str(name,"Название пресета",100)
    if type(s)~="table" then fail("Нет данных пресета") end
    local out={name=name,weapons={},armorItems={},ammo={},details={},slingCount=snapshotSlingCount(s)}
    local seen={}
    for _,w in ipairs(array(s.weapons or {},"Оружие")) do
        if type(w)~="table" then fail("Неверная запись оружия") end
        local class=weaponClass(w.class)
        if seen[class] then fail("Оружие повторяется: "..class) end
        seen[class]=true;out.weapons[#out.weapons+1]=class
        local d={attachments={}}
        if w.clip1~=nil then d.clip1=integer(w.clip1,-1,10000,"Магазин 1") end
        if w.clip2~=nil then d.clip2=integer(w.clip2,-1,10000,"Магазин 2") end
        local at=index(w.info,2)
        -- Not every SWEP GetInfo() stores attachments at index 2. Medicine,
        -- tools, etc. store their own values there; never interpret those as
        -- attachment slots and never apply arbitrary untrusted SetInfo data.
        if type(at)=="table" then
            local known={sight=true,mount=true,barrel=true,grip=true,underbarrel=true,magwell=true,agsmag=true}
            for slot,entry in pairs(at) do
                if known[slot] then
                    if type(entry)~="table" then fail("Неверный слот обвеса: "..slot) end
                    local id=index(entry,1)
                    if id~=nil and id~="empty" then
                        str(id,"Обвес",48)
                        if RP.AttachmentPlacementOf(id)~=slot then fail("Неизвестный обвес или слот: "..id) end
                        d.attachments[#d.attachments+1]=id
                    end
                end
            end
        end
        local order={mount=1,magwell=2,barrel=3,underbarrel=4,grip=5,sight=6}
        table.sort(d.attachments,function(a,b)
            return (order[RP.AttachmentPlacementOf(a)] or 50)<(order[RP.AttachmentPlacementOf(b)] or 50)
        end)
        out.details[class]=d
    end
    count(s.armor or {},"Броня")
    seen={}
    for _,id in pairs(s.armor or {}) do
        id=armorID(id);if not seen[id] then out.armorItems[#out.armorItems+1]=id;seen[id]=true end
    end
    count(s.ammo or {},"Патроны")
    for id,amount in pairs(s.ammo or {}) do
        local num=tonumber(id)
        if not num or num<0 or num~=math.floor(num) then fail("Неверный ID патронов") end
        local ammo=game.GetAmmoName(num)
        if type(ammo)~="string" or ammo=="" or #ammo>64 then fail("Неизвестный ID патронов: "..tostring(id)) end
        out.ammo[ammo]=integer(amount,0,999,"Патроны "..ammo)
    end
    return out
end
local function write(new)
    local raw=util.TableToJSON(new,true)
    if not raw or #raw>MAXFILE or type(util.JSONToTable(raw,false,true))~="table" then return false,"Библиотека слишком большая." end
    file.CreateDir("vcity_rp")
    local prev=file.Read(PATH,"DATA")
    if prev then file.Write(PATH..".bak",prev);if file.Read(PATH..".bak","DATA")~=prev then return false,"Не удалось создать резервную копию." end end
    file.Write(PATH..".pending",raw)
    if file.Read(PATH..".pending","DATA")~=raw then return false,"Ошибка записи временного файла." end
    file.Write(PATH,raw)
    if file.Read(PATH,"DATA")~=raw then if prev then file.Write(PATH,prev) end;return false,"Ошибка записи файла." end
    file.Delete(PATH..".pending");return true
end
local raw=file.Read(PATH,"DATA")
if raw and #raw<=MAXFILE then
    local data=util.JSONToTable(raw,false,true)
    if type(data)=="table" and type(data.roles)=="table" and type(data.subs)=="table" then links=data
    else ErrorNoHalt("[V-City RP] Не удалось прочитать zclp_links.json; файл не изменён.\n") end
end
local function target(req)
    if req.kind=="role" and type(req.id)=="string" and RP.Config.roles[req.id] then return links.roles,req.id end
    if req.kind=="ranksub" and type(req.id)=="string" and RP.Roles[req.id] and RP.SubclassAllowed(RP.Roles[req.id]) and type(req.sub)=="string" and RP.SubclassByID(req.sub) then return links.subs,"rank:"..req.id..":"..req.sub end
    if req.kind=="sub" and type(req.faction)=="string" and type(req.sub)=="string" and RP.SubclassFactions[req.faction] and RP.SubclassByID(req.sub) then return links.subs,req.faction.."_"..req.sub end
end
local function respond(ply,msg)
    net.Start(NET);if not RP.WriteJSON(msg) then RP.WriteJSON({ok=false,message="Ответ слишком большой."}) end;net.Send(ply)
end
net.Receive(NET,function(bits,ply)
    if not RP.AdminGate(ply,bits,RP.MaxNetJSON*8+16,0.4,"zclpbridge") then return end
    local req,err=RP.ReadJSON(bits);if not req then respond(ply,{ok=false,message=err or "Неверный запрос"});return end
    local group,key=target(req);if not group then respond(ply,{ok=false,message="Роль или подкласс не найдены."});return end
    if req.action=="get" then respond(ply,{ok=true,kind=req.kind,key=key,name=group[key] and group[key].name or "",action="get"});return end
    local entry
    if req.action=="set" or req.action=="preview" then
        local ok,value=pcall(fromSnapshot,req.name,req.preset)
        if not ok then respond(ply,{ok=false,message=tostring(value)});return end
        entry=value
        if req.action=="preview" then respond(ply,{ok=true,kind=req.kind,key=key,name=entry.name,action="preview",value=entry});return end
    elseif req.action~="clear" then respond(ply,{ok=false,message="Неизвестное действие."});return end
    local new=table.Copy(links);local group2=req.kind=="role" and new.roles or new.subs;group2[key]=entry
    local ok,message=write(new)
    if not ok then respond(ply,{ok=false,message=message});return end
    links=new
    if RP.Log and RP.Who then RP.Log("admin",RP.Who(ply).." изменил ZCLP-привязку "..key) end
    respond(ply,{ok=true,kind=req.kind,key=key,name=entry and entry.name or "",action=req.action})
end)
-- Validate saved asset classes again at spawn: missing addon means fallback to ordinary role.
local function validSaved(p)
    if type(p)~="table" or type(p.details)~="table" then return false end
    local normalized=table.Copy(p)
    local ok=pcall(function()
        if p.slingCount~=nil then normalized.slingCount=integer(p.slingCount,0,2,"Оружейные ремни") end
        normalized.weapons=array(p.weapons,"Оружие")
        normalized.armorItems=array(p.armorItems,"Броня")
        count(p.ammo,"Патроны");count(p.details,"Оружие")
        for _,v in ipairs(normalized.weapons) do weaponClass(v) end
        for _,v in ipairs(normalized.armorItems) do armorID(v) end
        for name,n in pairs(p.ammo) do str(name,"Патроны");if game.GetAmmoID(name)<0 then fail("Патроны не найдены") end;integer(n,0,999,"Патроны") end
        for class,d in pairs(p.details) do
            weaponClass(class);if type(d)~="table" then fail("Неверная запись оружия") end
            local attachments=array(d.attachments,"Обвесы")
            normalized.details[class].attachments=attachments
            for _,id in ipairs(attachments) do str(id,"Обвес",48);if not RP.AttachmentPlacementOf(id) then fail("Обвес не найден") end end
            if d.clip1~=nil then integer(d.clip1,-1,10000,"Магазин") end
            if d.clip2~=nil then integer(d.clip2,-1,10000,"Магазин") end
        end
    end)
    return ok and normalized or nil
end
local warned=setmetatable({}, {__mode="k"})
local function applyConfig(cfg,p)
    local normalized=validSaved(p)
    if not normalized then
        if not warned[p] then
            warned[p]=true
            ErrorNoHalt("[V-City RP] Preset link invalid or missing assets: "..tostring(type(p)=="table" and p.name or "?").."; using ordinary settings.\n")
        end
        return cfg
    end
    cfg.weapons=normalized.weapons;cfg.armorItems=normalized.armorItems;cfg.ammo=table.Copy(normalized.ammo);cfg.attachments={}
    cfg.VCityPresetDetails=normalized.details
    if normalized.slingCount~=nil then cfg.VCityPresetSlingCount=normalized.slingCount end
    return cfg
end
function RP.ApplyRolePreset(ply,cfg)
    local p=links.roles[RP.GetRole(ply).ID]
    if p then return applyConfig(cfg,p) end
    return cfg
end
function RP.ApplySubclassPreset(ply,cfg)
    local role=RP.GetRole(ply);local sub=ply:GetNW2String(RP.SubNWKey,"")
    if not RP.SubclassAvailable(role,sub) or sub=="" then return cfg end
    local rank=RP.SubclassRankOverrides and RP.SubclassRankOverrides[role.ID]
    local p=links.subs["rank:"..role.ID..":"..sub]
    if not p and not (rank and rank[sub] and rank[sub].blocksLegacy) then p=links.subs[role.Faction.."_"..sub] end
    if p then return applyConfig(cfg,p) end
    return cfg
end
function RP.ApplyPresetDetails(ply,cfg)
    if not cfg.VCityPresetDetails then return end
    local allowed={};for _,class in ipairs(cfg.weapons or {}) do allowed[class]=true end
    for class,d in pairs(cfg.VCityPresetDetails) do
        local wep=allowed[class] and ply:GetWeapon(class)
        if IsValid(wep) then
            if RP.RestorePresetAttachments and #(d.attachments or {})>0 then
                local _,failed=RP.RestorePresetAttachments(wep,d.attachments)
                if #failed>0 then ErrorNoHalt("[V-City RP] Не удалось установить обвесы на "..class..": "..table.concat(failed,", ").."\n") end
            end
            if d.clip1 and d.clip1>=0 and wep:GetMaxClip1()>0 then wep:SetClip1(math.min(d.clip1,wep:GetMaxClip1())) end
            if d.clip2 and d.clip2>=0 and wep:GetMaxClip2()>0 then wep:SetClip2(math.min(d.clip2,wep:GetMaxClip2())) end
        end
    end
end
-- ZCLP accepts client-supplied presets. Keep original manual handlers for admins,
-- but block ordinary players before the original receiver reads the payload.
-- Keep ZCLP auto-spawn hooks disabled even for admins: role spawn wins.
local wrappers={}
local commandWrapper
local captureWrappers={}
-- ZCLP's snapshot is produced by a local function in a separate addon. Extend
-- only the synchronous snapshot send, preserving the original handler and ACL.
local function captureSnapshot(original,bits,ply)
    local oldWrite=net.WriteTable
    net.WriteTable=function(value,...)
        if type(value)=="table" and type(value.meta)=="table" and type(value.weapons)=="table" and type(value.accessories)=="table" and IsValid(ply) and RP.SlingCount then
            value.vcitySlingCount=RP.SlingCount(ply:GetNetVar("Inventory",{}))
            value.accessories.hg_sling=value.vcitySlingCount>0 and true or nil
        end
        return oldWrite(value,...)
    end
    local ok,result=pcall(original,bits,ply)
    net.WriteTable=oldWrite
    if not ok then error(result,0) end
    return result
end
-- The addon equips its accessories after calling Give on weapons. Filter the
-- incoming copy to the allowed capacity, then synchronize the two-sling count
-- only after the original handler reports a successful application.
local function applyManual(original,bits,ply,kind)
    local readTable,readEntity,start,writeString=net.ReadTable,net.ReadEntity,net.Start,net.WriteString
    local snapshot,target,success,current
    net.ReadTable=function(...)
        local value=readTable(...)
        if snapshot==nil and type(value)=="table" then
            snapshot=value
            local ok,n=pcall(snapshotSlingCount,value)
            local capacity=math.max(1,ok and n or 0)
            local copy=table.Copy(value)
            if type(copy.weapons)=="table" and RP.IsPrimaryClass then
                local filtered,count={},0
                for _,w in ipairs(copy.weapons) do
                    if type(w)=="table" and type(w.class)=="string" and RP.IsPrimaryClass(w.class) then
                        count=count+1
                        if count<=capacity then filtered[#filtered+1]=w end
                    else filtered[#filtered+1]=w end
                end
                copy.weapons=filtered
            end
            return copy
        end
        return value
    end
    net.ReadEntity=function(...) local ent=readEntity(...);if not target then target=ent end;return ent end
    net.Start=function(name,...) current=name;return start(name,...) end
    net.WriteString=function(value,...)
        if current=="zclp_notify" and ((kind=="zclp_load_preset" and value=="loaded") or (kind=="zclp_give_preset" and value=="given")) then success=true end
        return writeString(value,...)
    end
    local ok,result=pcall(original,bits,ply)
    net.ReadTable,net.ReadEntity,net.Start,net.WriteString=readTable,readEntity,start,writeString
    if not ok then error(result,0) end
    local recipient=kind=="zclp_load_preset" and ply or target
    if success and snapshot and IsValid(recipient) and recipient:IsPlayer() and RP.SetSlingCount then
        local valid,n=pcall(snapshotSlingCount,snapshot)
        recipient.inventory=recipient.inventory or recipient:GetNetVar("Inventory",{}) or {}
        RP.SetSlingCount(recipient.inventory,valid and n or 0)
        recipient:SetNetVar("Inventory",recipient.inventory)
        RP.SyncSlingCapacity(recipient)
        if hg.weaponInv and hg.weaponInv.Insert then
            for _,wep in ipairs(recipient:GetWeapons()) do
                if RP.IsPrimaryWeapon(wep) then hg.weaponInv.Insert(recipient,wep) end
            end
            if hg.weaponInv.Sync then hg.weaponInv.Sync(recipient) end
        end
    end
    return result
end
local function mayUseManual(ply)
    return IsValid(ply) and ply:IsPlayer() and (ply:IsAdmin() or ply:IsSuperAdmin())
end
local function refuse(ply)
    if IsValid(ply) and (ply.VCityRPZCLPNotice or 0)<CurTime() then
        ply.VCityRPZCLPNotice=CurTime()+5
        ply:ChatPrint("[V-City RP] Ручная выдача ZCLP доступна только админам и суперадминам.")
    end
end
local function installZCLPGuard()
    for _,name in ipairs({"zclp_create_preset","zclp_update_preset"}) do
        local old=net.Receivers[name]
        if type(old)=="function" and old~=captureWrappers[name] then
            local original=old
            local wrapper=function(bits,ply) return captureSnapshot(original,bits,ply) end
            captureWrappers[name]=wrapper
            net.Receive(name,wrapper)
        end
    end
    for _,name in ipairs({"zclp_load_preset","zclp_give_preset","zclp_kit_request"}) do
        local old=net.Receivers[name]
        -- Initialize and InitPostEntity both run; never wrap our own wrapper.
        if type(old)=="function" and old~=wrappers[name] then
            local original,kind=old,name
            local wrapper=function(bits,ply)
                if not mayUseManual(ply) then refuse(ply);return end
                if kind=="zclp_load_preset" or kind=="zclp_give_preset" then return applyManual(original,bits,ply,kind) end
                return original(bits,ply)
            end
            wrappers[name]=wrapper
            net.Receive(name,wrapper)
        end
    end
    -- The original ZCLP command is independent from its net receiver.
    -- Preserve its own privilege checks and let trusted server console run it too.
    local commands,complete=concommand.GetTable()
    local original=commands and commands.zclp_kit
    if type(original)=="function" and original~=commandWrapper then
        local previous=original
        commandWrapper=function(ply,cmd,args,argstr)
            if IsValid(ply) and not mayUseManual(ply) then refuse(ply);return end
            return previous(ply,cmd,args,argstr)
        end
        concommand.Add("zclp_kit",commandWrapper,complete and complete.zclp_kit)
    end
    hook.Remove("PlayerSpawn","ZCLP_AutoSpawn")
    hook.Remove("PlayerSpawn","ZCLP_KitAutoSpawn")
end
hook.Add("Initialize","VCityRP.ZCLPGuard",installZCLPGuard)
hook.Add("InitPostEntity","VCityRP.ZCLPGuard",installZCLPGuard)
