-- V-City RP: count up to two sling items while preserving Z-City's legacy boolean.
local RP=VCityRP
function RP.SlingCount(inv)
    if type(inv)~="table" or type(inv.Weapons)~="table" or not inv.Weapons.hg_sling then return 0 end
    local n=tonumber(inv.VCitySlingCount) or 1
    return math.max(1,math.min(2,math.floor(n)))
end
function RP.SetSlingCount(inv,count)
    inv.Weapons=inv.Weapons or {}
    local n=math.max(0,math.min(2,math.floor(tonumber(count) or 0)))
    inv.VCitySlingCount=n>0 and n or nil
    inv.Weapons.hg_sling=n>0 and true or nil
    return n
end
function RP.PrimaryCapacity(inv)
    return math.max(1,RP.SlingCount(inv))
end
function RP.IsPrimaryWeapon(wep)
    return IsValid(wep) and wep.weaponInvCategory==1
end
function RP.PrimaryCount(ply,except)
    if not IsValid(ply) or not ply.GetWeapons then return 0 end
    local count=0
    for _,wep in ipairs(ply:GetWeapons()) do
        if wep~=except and RP.IsPrimaryWeapon(wep) then count=count+1 end
    end
    return count
end
if SERVER then
    -- Only update the existing main-weapon limit; leave every other category intact.
    function RP.SyncSlingCapacity(ply)
        if not IsValid(ply) then return end
        local slot=ply.weaponInv and ply.weaponInv[1]
        if slot then
            slot.limit=RP.PrimaryCapacity(ply.inventory)
            if hg.weaponInv and hg.weaponInv.Sync then hg.weaponInv.Sync(ply) end
        end
    end
    function RP.CanReceivePrimary(ply,wep)
        if not RP.IsPrimaryWeapon(wep) then return true end
        local count=RP.SlingCount(ply.inventory)
        if wep.sling and count<2 then count=count+1 end
        return RP.PrimaryCount(ply,wep)<math.max(1,count)
    end
    function RP.IsPrimaryClass(class)
        local seen={}
        for _=1,16 do
            if type(class)~="string" or seen[class] then break end
            seen[class]=true
            local info=weapons.GetStored(class)
            if not info then break end
            if info.weaponInvCategory~=nil then return info.weaponInvCategory==1 end
            class=info.Base
        end
        return false
    end
    -- Preserve order, configurations and metadata; skip only excess primary weapons.
    function RP.LimitSpawnWeapons(ply,list)
        local out,seen={},{}
        local n=RP.PrimaryCount(ply)
        local cap=RP.PrimaryCapacity(ply.inventory)
        local skipped=0
        for _,class in ipairs(list or {}) do
            local owned=ply:HasWeapon(class) or seen[class]
            if not owned and RP.IsPrimaryClass(class) then
                if n>=cap then skipped=skipped+1
                else n=n+1;out[#out+1]=class;seen[class]=true end
            else out[#out+1]=class;seen[class]=true end
        end
        return out,skipped
    end
end

if SERVER then
    -- Covers direct Give/PickupWeapon calls that do not invoke PlayerCanPickupWeapon.
    hook.Add("WeaponEquip", "VCityRP.SlingOverflow", function(wep,ply)
        if not RP.Enabled or not RP.IsPrimaryWeapon(wep) or not IsValid(ply) or not ply:IsPlayer() then return end
        timer.Simple(0,function()
            if not RP.Enabled or not IsValid(ply) or not IsValid(wep) or wep:GetOwner()~=ply then return end
            if RP.PrimaryCount(ply)>RP.PrimaryCapacity(ply.inventory) then
                ply:DropWeapon(wep)
                if IsValid(wep) and wep:GetOwner()==ply then
                    wep:Remove() -- last resort if an addon refuses the drop
                elseif IsValid(wep) then
                    wep.IsSpawned=true
                    wep.init=true
                end
                ply:ChatPrint("[V-City RP] Лишнее основное оружие не помещается: недостаточно ремней.")
                if hg.RenewInv then hg.RenewInv(ply,false) end
                RP.SyncSlingCapacity(ply)
            end
        end)
    end)
end
