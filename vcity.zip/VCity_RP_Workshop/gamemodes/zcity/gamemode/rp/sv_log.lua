-- V-City RP 1.0.0-beta.1 — SERVER ONLY. Единый журнал событий.
-- Файлы по дням: data/vcity_rp/logs/ГГГГ-ММ-ДД.txt, строка: [ЧЧ:ММ:СС] [категория] текст.
-- Запись буферизована (раз в 5 секунд и при выходе), старые файлы удаляются (vcity_rp_log_days).
-- RP.Log(категория, текст) — для любых модулей. RP.Who(ply) — «Ник<steam|роль>».
-- Просмотр (суперадмин): vcity_rp_log [строк=30] [фильтр] [ГГГГ-ММ-ДД]
local RP = VCityRP

RP.LogDir = "vcity_rp/logs"
local cvDays = CreateConVar("vcity_rp_log_days", "30", FCVAR_ARCHIVE, "Сколько дней хранить журнал")
local buffer = {}

local function clean(s, limit)
    s = tostring(s or "")
    s = string.gsub(s, "[%c]+", " ")
    return string.sub(s, 1, limit or 300)
end

function RP.Who(ply)
    if not IsValid(ply) then return "-" end
    local role = RP.GetRole and RP.GetRole(ply)
    return clean(ply:Nick(), 40) .. "<" .. tostring(ply:SteamID64() or "bot") .. "|" .. tostring(role and role.ID or "?") .. ">"
end

local function path(t) return RP.LogDir .. "/" .. os.date("%Y-%m-%d", t) .. ".txt" end

function RP.Log(category, text)
    local t = os.time()
    buffer[#buffer + 1] = { t = t, line = string.format("[%s] [%s] %s", os.date("%H:%M:%S", t), clean(category, 20), clean(text)) }
    if #buffer > 5000 then table.remove(buffer, 1) end
end

local function Flush()
    if #buffer == 0 then return end
    file.CreateDir("vcity_rp")
    file.CreateDir(RP.LogDir)
    local byFile, order = {}, {}
    for _, e in ipairs(buffer) do
        local p = path(e.t)
        if not byFile[p] then byFile[p] = {} order[#order + 1] = p end
        byFile[p][#byFile[p] + 1] = e.line
    end
    buffer = {}
    for _, p in ipairs(order) do
        file.Append(p, table.concat(byFile[p], "\n") .. "\n")
    end
end
RP.FlushLog = Flush

local function Cleanup()
    local keep = math.max(cvDays:GetInt(), 1) * 86400
    local files = file.Find(RP.LogDir .. "/*.txt", "DATA")
    for _, name in ipairs(files or {}) do
        local y, m, d = string.match(name, "^(%d+)-(%d+)-(%d+)%.txt$")
        if y then
            local t = os.time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 12 })
            if t and os.time() - t > keep then file.Delete(RP.LogDir .. "/" .. name) end
        end
    end
end

timer.Create("VCityRP.LogFlush", 5, 0, Flush)
timer.Create("VCityRP.LogCleanup", 3600, 0, Cleanup)
timer.Simple(10, Cleanup)
hook.Add("ShutDown", "VCityRP.LogShutdown", function() RP.Log("server", "остановка/смена карты: " .. game.GetMap()) Flush() end)

RP.Log("server", "старт, карта " .. game.GetMap())

-- ================= автоматические события =================
hook.Add("PlayerInitialSpawn", "VCityRP.LogJoin", function(ply)
    RP.Log("join", RP.Who(ply) .. " зашёл")
end)
hook.Add("PlayerDisconnected", "VCityRP.LogLeave", function(ply)
    RP.Log("leave", RP.Who(ply) .. " вышел")
end)
hook.Add("VCityRP.RoleChanged", "VCityRP.LogRole", function(ply, role, previous)
    RP.Log("role", RP.Who(ply) .. " " .. tostring(previous and previous.ID or "-") .. " -> " .. tostring(role and role.ID or "?"))
end)
hook.Add("PlayerDeath", "VCityRP.LogDeath", function(victim, inflictor, attacker)
    if not IsValid(victim) or not victim:IsPlayer() then return end
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
        local weapon = IsValid(attacker:GetActiveWeapon()) and attacker:GetActiveWeapon():GetClass() or "?"
        RP.Log("kill", RP.Who(attacker) .. " убил " .. RP.Who(victim) .. " (" .. weapon .. ")")
    else
        RP.Log("death", RP.Who(victim) .. " погиб (" .. (IsValid(attacker) and attacker:GetClass() or "мир") .. ")")
    end
end)

-- подкласс
do
    local original = RP.SetSubclass
    if isfunction(original) and not RP.__logSubWrapped then
        RP.__logSubWrapped = true
        RP.SetSubclass = function(ply, id)
            local ok, msg = original(ply, id)
            if ok then RP.Log("subclass", RP.Who(ply) .. " подкласс: " .. (id == "" and "снят" or tostring(id))) end
            return ok, msg
        end
    end
end

-- деньги
do
    if RP.TransferMoney and not RP.__logMoneyWrapped then
        RP.__logMoneyWrapped = true
        local transfer = RP.TransferMoney
        RP.TransferMoney = function(from, to, amount)
            local ok, err = transfer(from, to, amount)
            RP.Log("money", (ok and "перевод " or "перевод НЕУДАЧА (" .. tostring(err) .. ") ") .. tostring(amount) .. ": " .. RP.Who(from) .. " -> " .. RP.Who(to))
            return ok, err
        end
    end
end

-- ================= просмотр =================
concommand.Add("vcity_rp_log", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    Flush()
    local n = math.Clamp(tonumber(args[1]) or 30, 1, 300)
    local filter = args[2] and args[2] ~= "-" and string.lower(args[2]) or nil
    local day = args[3] or os.date("%Y-%m-%d")
    if not string.match(day, "^%d%d%d%d%-%d%d%-%d%d$") then day = os.date("%Y-%m-%d") end

    local raw = file.Read(RP.LogDir .. "/" .. day .. ".txt", "DATA") or ""
    local lines = {}
    for line in string.gmatch(raw, "[^\n]+") do
        if not filter or string.find(string.lower(line), filter, 1, true) then lines[#lines + 1] = line end
    end

    local out = { "[V-City RP] журнал " .. day .. ": " .. #lines .. " строк, показаны последние " .. math.min(n, #lines) }
    for i = math.max(#lines - n + 1, 1), #lines do out[#out + 1] = lines[i] end
    for _, line in ipairs(out) do
        if IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, line .. "\n") else print(line) end
    end
    if IsValid(ply) then ply:ChatPrint("[V-City RP] журнал выведен в консоль (" .. #lines .. " строк).") end
end)
