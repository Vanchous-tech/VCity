-- V-City RP 1.0.0-beta.1 — SERVER ONLY. Спавнеры транспорта.
-- Спавнер = место на карте + класс машины. Машина появляется при старте сервера и после уничтожения
-- (или брошенности) возрождается через заданное время. Всё хранится в JSON и подгружается само:
--   data/vcity_rp/vehicles_<карта>.json
-- Поля спавнера: class, label, pos, yaw, delay (сек до возрождения после уничтожения),
--   abandon (сек: пустая машина дальше 300 юнитов от места возвращается; 0 = не возвращать),
--   side ("" все / usa / ru — кто может сесть), enabled, onstart (появиться при старте).
-- Меню (суперадмин): vcity_rp_veh_menu. Консоль: vcity_rp_veh_add <класс> [delay] [abandon] [название…],
--   _list · _remove <id> · _respawn <id> · _move <id> · _yaw <id> <градусы> · _set <id> <поле> <значение> · _reload
-- Конвары: vcity_rp_veh (1/0 весь модуль), vcity_rp_veh_wreck (сек до уборки обломков, 30),
--   vcity_rp_veh_clear (радиус свободного места для возрождения, 150).
local RP = VCityRP

RP.Spawners = RP.Spawners or {}
RP.SpawnerMax = 64
local cvOn = CreateConVar("vcity_rp_veh", "1", FCVAR_ARCHIVE, "Спавнеры транспорта (1/0)")
local cvWreck = CreateConVar("vcity_rp_veh_wreck", "30", FCVAR_ARCHIVE, "Секунд до уборки обломков уничтоженной машины")
local cvClear = CreateConVar("vcity_rp_veh_clear", "150", FCVAR_ARCHIVE, "Радиус, в котором не должно быть игроков при возрождении")

util.AddNetworkString("vcity_rp_veh_open")
util.AddNetworkString("vcity_rp_veh_act")
util.AddNetworkString("vcity_rp_veh_props")

local runtime = {} -- [id] = { ent=, goneAt=, destroyedAt=, emptySince= }
local sessionCounter = 0
local function markSession(s)
    sessionCounter = sessionCounter + 1
    s.session = tostring(sessionCounter)
end

local function File() return "vcity_rp/vehicles_" .. string.lower(game.GetMap()) .. ".json" end

-- ================= проверка данных (чистая логика, тестируется) =================
local CLASS_PATTERN = "^[%w_%.%-]+$"

local MAX_PROPS = 48
local function cleanSavedProperties(value)
    if value == nil then return {} end
    if not istable(value) then return nil end
    local out, count = {}, 0
    for key, val in pairs(value) do
        if not isstring(key) or #key < 1 or #key > 64 or key:find("[%c]") or
            not isstring(val) or #val > 128 or val:find("[%c]") then return nil end
        count = count + 1
        if count > MAX_PROPS then return nil end
        out[key] = val
    end
    return out
end

function RP.CleanSpawner(src)
    if not istable(src) then return nil end
    local class = isstring(src.class) and src.class or nil
    if not class or #class > 64 or not string.match(class, CLASS_PATTERN) then return nil end
    local x, y, z = tonumber(src.x), tonumber(src.y), tonumber(src.z)
    if not x or not y or not z then return nil end

    local properties = cleanSavedProperties(src.lvsProperties)
    if not properties then return nil end
    local skin = src.skin
    if skin ~= nil then
        skin = tonumber(skin)
        if not skin or skin ~= skin or skin ~= math.floor(skin) or skin < 0 or skin > 255 then return nil end
    end
    local label = isstring(src.label) and string.sub(string.gsub(src.label, "[%c|]", ""), 1, 32) or ""
    local side = (src.side == "usa" or src.side == "ru") and src.side or ""

    return {
        class = class, label = label, x = x, y = y, z = z,
        yaw = math.NormalizeAngle and math.NormalizeAngle(tonumber(src.yaw) or 0) or (tonumber(src.yaw) or 0),
        delay = math.Clamp(math.floor(tonumber(src.delay) or 300), 5, 86400),
        abandon = math.Clamp(math.floor(tonumber(src.abandon) or 0), 0, 86400),
        side = side,
        enabled = src.enabled ~= false,
        onstart = src.onstart ~= false,
        lvsProperties = properties,
        skin = skin,
    }
end

-- ================= сохранение / загрузка =================
local function Save()
    local out = {}
    for _, s in ipairs(RP.Spawners) do
        out[#out + 1] = { class = s.class, label = s.label, x = s.x, y = s.y, z = s.z, yaw = s.yaw,
            delay = s.delay, abandon = s.abandon, side = s.side, enabled = s.enabled, onstart = s.onstart,
            lvsProperties = s.lvsProperties, skin = s.skin }
    end
    local data = util.TableToJSON(out, true)
    if not data then return false end
    local path, tmp = File(), File() .. ".pending.json"
    local old = file.Read(path, "DATA")
    local ok = pcall(function()
        file.CreateDir("vcity_rp")
        file.Write(tmp, data)
        if file.Read(tmp, "DATA") ~= data then error("temporary vehicle config write failed") end
        if old and old ~= "" then
            local backup = "vcity_rp/vehicles_" .. string.lower(game.GetMap()) .. ".previous.json"
            file.Write(backup, old)
            if file.Read(backup, "DATA") ~= old then error("vehicle config backup failed") end
        end
        file.Write(path, data)
        if file.Read(path, "DATA") ~= data then error("vehicle config write failed") end
    end)
    if not ok then
        pcall(function()
            if old ~= nil then file.Write(path, old) elseif file.Exists(path, "DATA") then file.Delete(path) end
        end)
    end
    if file.Exists(tmp, "DATA") then file.Delete(tmp) end
    return ok
end

local function Load()
    RP.Spawners = {}
    local raw = file.Read(File(), "DATA")
    local parsed = raw and raw ~= "" and util.JSONToTable(raw) or nil
    if not istable(parsed) then return end
    for _, src in ipairs(parsed) do
        if #RP.Spawners >= RP.SpawnerMax then break end
        local s = RP.CleanSpawner(src)
        if s then
            s.id = #RP.Spawners + 1
            markSession(s)
            RP.Spawners[#RP.Spawners + 1] = s
        end
    end
end

-- ================= спавн =================
local function ClassOK(class)
    if not isstring(class) or not string.match(class, CLASS_PATTERN) then return false end
    return scripted_ents.GetStored(class) ~= nil or list.Get("Vehicles")[class] ~= nil
end

local function PlayersNear(s)
    local pos, r = Vector(s.x, s.y, s.z), cvClear:GetFloat()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() and ply:GetPos():DistToSqr(pos) < r * r then return true end
    end
    return false
end

local function Destroyed(ent)
    if not IsValid(ent) then return true end
    if ent.GetDestroyed and ent:GetDestroyed() then return true end
    if ent.GetHP and ent.GetMaxHP then
        local ok, hp, max = pcall(function() return ent:GetHP(), ent:GetMaxHP() end)
        if ok and tonumber(max) and max > 0 and tonumber(hp) and hp <= 0 then return true end
    end
    return false
end

local function Occupied(ent)
    if not IsValid(ent) then return false end
    if ent.GetDriver and IsValid(ent:GetDriver()) then return true end
    if istable(ent.pSeats) then
        for _, pod in ipairs(ent.pSeats) do
            if IsValid(pod) and IsValid(pod:GetDriver()) then return true end
        end
    end
    local driverSeat = ent.GetDriverSeat and ent:GetDriverSeat()
    if IsValid(driverSeat) and IsValid(driverSeat:GetDriver()) then return true end
    for _, child in ipairs(ent:GetChildren() or {}) do
        if child.GetDriver and IsValid(child:GetDriver()) then return true end
    end
    return false
end

local function Remove(id)
    local rt = runtime[id]
    if rt and IsValid(rt.ent) then rt.ent:Remove() end
end

-- Read the same editable NetworkVars that the stock LVS property panel uses.
-- Never accept a key or constraints supplied by a client.
local function editing(ent)
    if not IsValid(ent) or not ent.LVS or not ent.GetEditingData or not ent.SetNetworkKeyValue then return {} end
    local ok, result = pcall(ent.GetEditingData, ent)
    return ok and istable(result) and result or {}
end
local function cleanValue(edit, value)
    if not istable(edit) or not isstring(value) or #value > 128 or value:find("[%c]") then return nil end
    local kind = edit.type
    if kind == "Boolean" then
        if value == "1" or value == "true" then return "1" end
        if value == "0" or value == "false" then return "0" end
    elseif kind == "Int" or kind == "Float" then
        local n = tonumber(value)
        if not n or n ~= n or n == math.huge or n == -math.huge or math.abs(n) > 1000000000 then return nil end
        if kind == "Int" and n ~= math.floor(n) then return nil end
        local lo, hi = tonumber(edit.min) or 0, tonumber(edit.max) or 1
        if n < lo or n > hi then return nil end
        return tostring(n)
    elseif kind == "Combo" and istable(edit.values) then
        for _, option in pairs(edit.values) do
            if (isstring(option) or type(option) == "number" or type(option) == "boolean") and tostring(option) == value then return value end
        end
    elseif kind == "Generic" or kind == "String" then
        return value
    end
    return nil
end
local function skinLimit(ent)
    if not IsValid(ent) or not ent.SkinCount then return 0 end
    local ok, count = pcall(ent.SkinCount, ent)
    return ok and math.Clamp(math.floor(tonumber(count) or 0), 0, 256) or 0
end
local function applySettings(ent, s)
    if not IsValid(ent) then return end
    local available = editing(ent)
    local keys = {}
    for key in pairs(s.lvsProperties or {}) do keys[#keys+1] = key end
    local function priority(key)
        key = string.lower(key)
        if key == "aiteam" then return 1 end
        if key == "aicontrolled" then return 3 end
        if key == "aigunners" then return 4 end
        return 2
    end
    table.sort(keys, function(a,b)
        local pa,pb=priority(a),priority(b)
        if pa==pb then return a<b end
        return pa<pb
    end)
    for _, key in ipairs(keys) do
        local value = s.lvsProperties[key]
        local cleaned = cleanValue(available[key], value)
        if cleaned then
            local ok, result = pcall(ent.SetNetworkKeyValue, ent, key, cleaned)
            if not ok or not result then ErrorNoHalt("[V-City RP] Не удалось применить свойство " .. key .. " спавнера #" .. s.id .. "\n") end
        else
            ErrorNoHalt("[V-City RP] Свойство " .. key .. " спавнера #" .. s.id .. " недоступно или вне диапазона; запись сохранена.\n")
        end
    end
    if s.skin ~= nil then
        local count = skinLimit(ent)
        if s.skin == 0 or s.skin < count then ent:SetSkin(s.skin)
        else ErrorNoHalt("[V-City RP] Скин спавнера #" .. s.id .. " недоступен; запись сохранена.\n") end
    end
end

local function Spawn(s)
    if not ClassOK(s.class) then
        if RP.Log and not s.missingLogged then RP.Log("vehicle", "класс не найден: " .. s.class .. " (спавнер #" .. s.id .. "), повтор раз в минуту") end
        s.missingLogged = true
        return false
    end
    s.missingLogged = nil
    local ent = ents.Create(s.class)
    if not IsValid(ent) then return false end
    ent:SetPos(Vector(s.x, s.y, s.z + 12))
    ent:SetAngles(Angle(0, s.yaw, 0))
    ent:Spawn()
    ent:Activate()
    ent.VCitySpawnerID = s.id
    ent.VCitySpawnerSide = s.side
    runtime[s.id] = { ent = ent, spawnedAt = CurTime() }
    -- LVS runs PostInitialize/OnSpawn in a zero-delay timer AFTER Spawn().
    -- Several vehicles reset Loadout (and other values) in OnSpawn. Wait for
    -- lvsReady before applying saved overrides, without touching replaced cars.
    if ent.LVS and type(ent.IsInitialized) == "function" then
        local function applyWhenReady(attempt)
            if not IsValid(ent) or RP.Spawners[s.id] ~= s or not runtime[s.id] or runtime[s.id].ent ~= ent then return end
            local ok, ready = pcall(ent.IsInitialized, ent)
            if ok and ready then applySettings(ent, s) return end
            if attempt >= 50 then
                ErrorNoHalt("[V-City RP] LVS не инициализировалась: свойства спавнера #" .. s.id .. " не применены.\n")
                return
            end
            timer.Simple(0.2, function() applyWhenReady(attempt + 1) end)
        end
        timer.Simple(0.1, function() applyWhenReady(1) end)
    else
        applySettings(ent, s)
    end
    if RP.Log then RP.Log("vehicle", "возрождён «" .. (s.label ~= "" and s.label or s.class) .. "» (спавнер #" .. s.id .. ")") end
    return true
end

function RP.RespawnSpawner(id, force)
    local s = RP.Spawners[id]
    if not s then return false end
    if force then Remove(id) end
    runtime[id] = nil
    return Spawn(s)
end

-- Периодическая проверка: уничтожена / исчезла / брошена
timer.Create("VCityRP.Vehicles", 2, 0, function()
    if not cvOn:GetBool() then return end
    local now = CurTime()

    for _, s in ipairs(RP.Spawners) do
        local rt = runtime[s.id]
        if not s.enabled then
            if rt and IsValid(rt.ent) then rt.ent:Remove() end
            runtime[s.id] = nil
        elseif not rt then
            -- ещё не появлялась (после старта или перезагрузки конфига)
            if (s.onstart or RP.VehiclesStarted) and now >= (s.retryAt or 0) then
                if not PlayersNear(s) and not Spawn(s) then s.retryAt = now + 60 end
            end
        elseif IsValid(rt.ent) then
            if Destroyed(rt.ent) then
                rt.destroyedAt = rt.destroyedAt or now
                if now - rt.destroyedAt >= math.min(cvWreck:GetFloat(), s.delay) then
                    rt.ent:Remove()
                end
            elseif s.abandon > 0 then
                local away = rt.ent:GetPos():DistToSqr(Vector(s.x, s.y, s.z)) > 300 * 300
                if away and not Occupied(rt.ent) then
                    rt.emptySince = rt.emptySince or now
                    if now - rt.emptySince >= s.abandon then
                        if RP.Log then RP.Log("vehicle", "брошена, возвращена на место: " .. s.class .. " (#" .. s.id .. ")") end
                        rt.returned = true
                        rt.ent:Remove()
                    end
                else
                    rt.emptySince = nil
                end
            end
        else
            -- машины нет: ждём delay от момента уничтожения/удаления, потом возрождаем
            rt.goneAt = rt.goneAt or (rt.returned and (now - s.delay + 10)) or rt.destroyedAt or now
            if now - rt.goneAt >= s.delay and not PlayersNear(s) then
                runtime[s.id] = nil
                Spawn(s)
            end
        end
    end
end)

-- старт: даём LVS и остальным аддонам загрузиться
hook.Add("InitPostEntity", "VCityRP.VehiclesStart", function()
    timer.Simple(6, function() RP.VehiclesStarted = true end)
end)
hook.Add("PostCleanupMap", "VCityRP.VehiclesCleanup", function()
    runtime = {}
end)

-- ограничение «кто может сесть»
hook.Add("CanPlayerEnterVehicle", "VCityRP.VehicleSide", function(ply, pod)
    if not IsValid(ply) or not IsValid(pod) then return end
    -- Only the server's in-progress cuffed-passenger transfer gets this narrow exception.
    if RP.PrisonerSeatAuthorized and RP.PrisonerSeatAuthorized(ply,pod) then return end
    local host = pod:GetParent()
    if not IsValid(host) or not host.VCitySpawnerSide then host = pod end
    local side = host.VCitySpawnerSide
    if not side or side == "" then return end
    if ply:IsSuperAdmin() then return end
    if RP.SideOfPlayer and RP.SideOfPlayer(ply) == side then return end
    if (ply.VCityRPVehNotify or 0) < CurTime() then
        ply.VCityRPVehNotify = CurTime() + 3
        ply:ChatPrint("Эта техника закреплена за другой стороной.")
    end
    return false
end)

-- ================= админ-действия =================
local function Say(ply, msg)
    if IsValid(ply) then ply:ChatPrint("[V-City RP] " .. msg) else print("[V-City RP] " .. msg) end
end
local function Admin(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then Say(ply, "Только суперадмин.") return false end
    return true
end

local function AimPos(ply)
    local tr = util.TraceLine({ start = ply:EyePos(), endpos = ply:EyePos() + ply:GetAimVector() * 20000, filter = ply, mask = MASK_SOLID_BRUSHONLY })
    if tr.Hit then return tr.HitPos end
end

function RP.AddSpawner(ply, data)
    if #RP.Spawners >= RP.SpawnerMax then return false, "Лимит спавнеров: " .. RP.SpawnerMax end
    local pos = AimPos(ply)
    if not pos then return false, "Наведите прицел на землю." end
    data.x, data.y, data.z = pos.x, pos.y, pos.z
    data.yaw = ply:EyeAngles().y
    local s = RP.CleanSpawner(data)
    if not s then return false, "Некорректные данные (класс?)." end
    if not ClassOK(s.class) then return false, "Класс «" .. s.class .. "» не найден на сервере." end
    s.id = #RP.Spawners + 1
    markSession(s)
    RP.Spawners[s.id] = s
    Save()
    Spawn(s)
    if RP.Log then RP.Log("admin", RP.Who(ply) .. " спавнер #" .. s.id .. " " .. s.class) end
    return true, "Спавнер #" .. s.id .. " создан: " .. (s.label ~= "" and s.label or s.class)
end

local EDIT_FIELDS = { label = "string", delay = "number", abandon = "number", side = "string", enabled = "bool", onstart = "bool", yaw = "number" }

function RP.EditSpawner(id, field, value)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    local kind = EDIT_FIELDS[field]
    if not kind then return false, "Поле: label, delay, abandon, side, enabled, onstart, yaw" end
    local data = {}
    for k, v in pairs(s) do data[k] = v end
    if kind == "bool" then
        data[field] = (value == true or value == "1" or value == "true" or value == "on")
    else
        data[field] = value
    end
    local clean = RP.CleanSpawner(data)
    if not clean then return false, "Некорректное значение." end
    for k, v in pairs(clean) do s[k] = v end
    local rt = runtime[id]
    if rt and IsValid(rt.ent) then rt.ent.VCitySpawnerSide = s.side end
    Save()
    return true, "Спавнер #" .. id .. ": " .. field .. " = " .. tostring(s[field])
end

function RP.RemoveSpawner(id)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    Remove(id)
    table.remove(RP.Spawners, id)
    -- перенумерация вместе с рантаймом
    local newRuntime = {}
    for i, sp in ipairs(RP.Spawners) do
        local old = sp.id
        sp.id = i
        newRuntime[i] = runtime[old]
        if newRuntime[i] and IsValid(newRuntime[i].ent) then newRuntime[i].ent.VCitySpawnerID = i end
    end
    runtime = newRuntime
    Save()
    return true, "Спавнер удалён."
end

function RP.MoveSpawner(ply, id)
    local s = RP.Spawners[id]
    if not s then return false, "Нет спавнера #" .. tostring(id) end
    local pos = AimPos(ply)
    if not pos then return false, "Наведите прицел на землю." end
    s.x, s.y, s.z, s.yaw = pos.x, pos.y, pos.z, math.NormalizeAngle(ply:EyeAngles().y)
    Save()
    RP.RespawnSpawner(id, true)
    return true, "Спавнер #" .. id .. " перенесён, машина возрождена."
end

-- ---- меню ----
local function Payload()
    local list = {}
    for _, s in ipairs(RP.Spawners) do
        local rt = runtime[s.id]
        local state = "ждёт"
        if rt and IsValid(rt.ent) then state = Destroyed(rt.ent) and "уничтожена" or (Occupied(rt.ent) and "в деле" or "на месте") end
        list[#list + 1] = { id = s.id, class = s.class, label = s.label, delay = s.delay, abandon = s.abandon,
            side = s.side, enabled = s.enabled, onstart = s.onstart, state = state }
    end
    return { spawners = list }
end

local function OpenMenu(ply)
    net.Start("vcity_rp_veh_open")
    RP.WriteJSON(Payload())
    net.Send(ply)
end

local function propertiesPayload(id)
    local s = RP.Spawners[id]
    local rt = s and runtime[id]
    local ent = rt and rt.ent
    if not s then return {id=id, error="Спавнер не найден."} end
    if not IsValid(ent) then return {id=id, error="Машина сейчас отсутствует. Дождитесь появления или возродите её."} end
    local props = {}
    for key, edit in pairs(editing(ent)) do
        if isstring(key) and #key >= 1 and #key <= 64 and not key:find("[%c]") and istable(edit) and
            (edit.type == "Boolean" or edit.type == "Int" or edit.type == "Float" or edit.type == "Combo" or edit.type == "String" or edit.type == "Generic") then
            local ok, current = pcall(ent.GetNetworkKeyValue, ent, key)
            if ok and current ~= nil then
                local row = {key=key, title=string.sub(tostring(edit.title or key),1,64), category=string.sub(tostring(edit.category or "General"),1,64),
                    type=edit.type, value=tostring(current), saved=s.lvsProperties and s.lvsProperties[key] or nil,
                    min=tonumber(edit.min) or 0, max=tonumber(edit.max) or 1, order=tonumber(edit.order) or 1000}
                if edit.type == "Combo" then
                    row.options = {}
                    for label, value in pairs(edit.values or {}) do
                        if #row.options < 100 and (isstring(value) or type(value)=="number" or type(value)=="boolean") and #tostring(value)<=128 then
                            row.options[#row.options+1] = {label=string.sub(tostring(label),1,64), value=tostring(value)}
                        end
                    end
                    table.sort(row.options,function(a,b) return a.label < b.label end)
                end
                props[#props+1] = row
            end
        end
    end
    table.sort(props,function(a,b) if a.category ~= b.category then return a.category < b.category end if a.order ~= b.order then return a.order < b.order end return a.title < b.title end)
    while #props > MAX_PROPS do table.remove(props) end
    return {id=id, session=s.session, class=s.class, lvs=ent.LVS==true, properties=props, skin=s.skin,
        currentSkin=ent.GetSkin and ent:GetSkin() or 0, skinCount=skinLimit(ent)}
end
local function sendProperties(ply, id)
    net.Start("vcity_rp_veh_props")
    if RP.WriteJSON(propertiesPayload(id)) then net.Send(ply) return end
    net.Start("vcity_rp_veh_props")
    if RP.WriteJSON({id=id,error="Список свойств слишком велик для передачи."}) then net.Send(ply) end
end
function RP.SaveVehicleProperties(id, values, skin, session)
    local s = RP.Spawners[id]
    local rt = s and runtime[id]
    local ent = rt and rt.ent
    if not s or not IsValid(ent) then return false,"Машина отсутствует; дождитесь её появления." end
    if not isstring(session) or session ~= s.session then return false,"Спавнер изменился. Откройте свойства заново." end
    local clean = cleanSavedProperties(values)
    if not clean then return false,"Некорректный список свойств." end
    local available = editing(ent)
    local visible = {}
    for _, row in ipairs(propertiesPayload(id).properties or {}) do visible[row.key] = true end
    -- Keep old overrides that this version/class cannot currently display.
    for key, value in pairs(s.lvsProperties or {}) do
        if not visible[key] then clean[key] = value end
    end
    if not cleanSavedProperties(clean) then return false,"Слишком много сохранённых свойств." end
    for key, value in pairs(clean) do
        local canonical = visible[key] and cleanValue(available[key], value) or (not visible[key] and s.lvsProperties and s.lvsProperties[key] == value and value)
        if not canonical then return false,"Недоступное свойство или неверное значение: " .. key end
        clean[key] = canonical
    end
    if skin ~= nil then
        if type(skin) ~= "number" or skin ~= skin or skin ~= math.floor(skin) or skin < 0 or skin > 255 or (skin ~= 0 and skin >= skinLimit(ent)) then
            return false,"Такого скина у модели нет."
        end
    end
    local oldProps, oldSkin = s.lvsProperties, s.skin
    s.lvsProperties, s.skin = clean, skin
    if not Save() then s.lvsProperties, s.skin = oldProps, oldSkin; return false,"Не удалось сохранить файл спавнеров." end
    applySettings(ent, s)
    if RP.Log then RP.Log("admin", "свойства транспорта спавнера #" .. id .. " сохранены") end
    return true,"Свойства и скин сохранены. Снятые переопределения сбросятся при следующем возрождении."
end

net.Receive("vcity_rp_veh_act", function(bits, ply)
    if not RP.AdminGate(ply, bits, RP.MaxNetJSON*8+512, 0.2, "veh") then return end
    local act = net.ReadString()
    if #act > 16 then return end
    local data = RP.ReadJSON(nil) or {}

    local ok, msg
    if act == "properties" then
        sendProperties(ply, tonumber(data.id) or 0)
        return
    elseif act == "props_save" then
        local id = tonumber(data.id) or 0
        ok, msg = RP.SaveVehicleProperties(id, data.properties, data.skin, data.session)
        if msg then Say(ply, msg) end
        if ok then sendProperties(ply, id)
        else
            net.Start("vcity_rp_veh_props")
            if RP.WriteJSON({id=id,error=msg}) then net.Send(ply) end
        end
        return
    elseif act == "add" then
        ok, msg = RP.AddSpawner(ply, { class = data.class, label = data.label, delay = data.delay, abandon = data.abandon, side = data.side })
    elseif act == "remove" then
        ok, msg = RP.RemoveSpawner(tonumber(data.id) or 0)
    elseif act == "respawn" then
        ok = RP.RespawnSpawner(tonumber(data.id) or 0, true)
        msg = ok and "Возрождено." or "Не удалось (класс?)."
    elseif act == "move" then
        ok, msg = RP.MoveSpawner(ply, tonumber(data.id) or 0)
    elseif act == "update" then
        -- несколько полей за один запрос (меню): delay, abandon, label, side
        local id = tonumber(data.id) or 0
        ok, msg = true, "Спавнер #" .. id .. " обновлён."
        for _, f in ipairs({ "delay", "abandon", "label", "side" }) do
            if data[f] ~= nil then
                local fine, m = RP.EditSpawner(id, f, data[f])
                if not fine then ok, msg = false, m break end
            end
        end
    elseif act == "set" then
        ok, msg = RP.EditSpawner(tonumber(data.id) or 0, tostring(data.field), data.value)
    end
    if msg then Say(ply, msg) end
    OpenMenu(ply)
end)

concommand.Add("vcity_rp_veh_menu", function(ply)
    if IsValid(ply) and ply:IsSuperAdmin() then OpenMenu(ply) end
end)

concommand.Add("vcity_rp_veh_add", function(ply, _, args)
    if not Admin(ply) or not IsValid(ply) then return end
    local class = args[1]
    if not class then return Say(ply, "usage: vcity_rp_veh_add <класс> [delay] [abandon] [название…] (смотрите на место). Список: vcity_rp_veh_classes") end
    local label = {}
    for i = 4, #args do label[#label + 1] = args[i] end
    local _, msg = RP.AddSpawner(ply, { class = class, delay = args[2], abandon = args[3], label = table.concat(label, " ") })
    Say(ply, msg)
end)

concommand.Add("vcity_rp_veh_classes", function(ply, _, args)
    if not Admin(ply) then return end
    local filter = string.lower(args[1] or "")
    local out = {}
    for class, ent in pairs(scripted_ents.GetList()) do
        local t = ent.t or ent
        if (t.Spawnable or string.StartWith(class, "lvs_") or string.StartWith(class, "glide")) and (filter == "" or string.find(string.lower(class), filter, 1, true)) then
            out[#out + 1] = class
        end
    end
    table.sort(out)
    Say(ply, #out .. " классов" .. (filter ~= "" and (" по «" .. filter .. "»") or "") .. " (показаны первые 60):")
    for i = 1, math.min(#out, 60) do Say(ply, out[i]) end
end)

concommand.Add("vcity_rp_veh_list", function(ply)
    if not Admin(ply) then return end
    if #RP.Spawners == 0 then return Say(ply, "Спавнеров нет. Откройте vcity_rp_veh_menu.") end
    for _, s in ipairs(Payload().spawners) do
        Say(ply, string.format("#%d %s [%s] delay=%d abandon=%d side=%s %s — %s", s.id, s.label ~= "" and s.label or "-", s.class, s.delay, s.abandon, s.side ~= "" and s.side or "все", s.enabled and "" or "(выкл)", s.state))
    end
end)

concommand.Add("vcity_rp_veh_remove", function(ply, _, args) if Admin(ply) then local _, m = RP.RemoveSpawner(tonumber(args[1]) or 0) Say(ply, m) end end)
concommand.Add("vcity_rp_veh_respawn", function(ply, _, args)
    if Admin(ply) then Say(ply, RP.RespawnSpawner(tonumber(args[1]) or 0, true) and "Возрождено." or "Не удалось.") end
end)
concommand.Add("vcity_rp_veh_move", function(ply, _, args)
    if Admin(ply) and IsValid(ply) then local _, m = RP.MoveSpawner(ply, tonumber(args[1]) or 0) Say(ply, m) end
end)
concommand.Add("vcity_rp_veh_yaw", function(ply, _, args)
    if Admin(ply) then
        local id = tonumber(args[1]) or 0
        local _, m = RP.EditSpawner(id, "yaw", args[2])
        RP.RespawnSpawner(id, true)
        Say(ply, m)
    end
end)
concommand.Add("vcity_rp_veh_set", function(ply, _, args)
    if Admin(ply) then local _, m = RP.EditSpawner(tonumber(args[1]) or 0, tostring(args[2]), args[3]) Say(ply, m) end
end)
concommand.Add("vcity_rp_veh_reload", function(ply)
    if not Admin(ply) then return end
    for id in pairs(runtime) do Remove(id) end
    runtime = {}
    Load()
    Say(ply, "Спавнеров загружено: " .. #RP.Spawners)
end)

Load()
print("[V-City RP] Спавнеры транспорта: " .. #RP.Spawners)
