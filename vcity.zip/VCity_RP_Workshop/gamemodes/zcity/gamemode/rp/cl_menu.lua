-- V-City black/orange native F4. Gameplay, JSON settings and /rp are unchanged.
local RP=VCityRP
RP.UIVersion="1.0.0-beta.1"
RP.UI={
    bg=Color(9,10,12,250),row=Color(20,21,24),hover=Color(36,29,24),active=Color(37,27,19),
    text=Color(235,235,238),muted=Color(137,139,145),line=Color(42,43,47),
    accent=Color(255,128,40),accentHover=Color(255,151,70),accentText=Color(255,186,132),
    onAccent=Color(20,12,7),selection=Color(90,48,21)
}
RP.UI.HoverGrowth=0.028
RP.UI.HoverSpeed=16
surface.CreateFont("VCityRP.Title",{font="Bahnschrift",size=25,weight=500})
surface.CreateFont("VCityRP.Body",{font="Bahnschrift",size=15,weight=400})
surface.CreateFont("VCityRP.Small",{font="Bahnschrift",size=12,weight=400})
surface.CreateFont("VCityRP.Brand",{font="Bahnschrift",size=13,weight=600})
local fallbacks={press="buttons/button15.wav",release="buttons/button14.wav",hover="buttons/button9.wav"}
function RP.PlayUISound(kind)
    if kind=="hover" and (RP.NextHoverSound or 0)>RealTime() then return end
    if kind=="hover" then RP.NextHoverSound=RealTime()+0.06 end
    local path=RP.Sounds[kind]
    if not path or not file.Exists("sound/"..path,"GAME") then path=fallbacks[kind] end
    if path then surface.PlaySound(path) end
end
function RP.UIColor(a,b,amount)
    return Color(a.r+(b.r-a.r)*amount,a.g+(b.g-a.g)*amount,a.b+(b.b-a.b)*amount,(a.a or 255)+((b.a or 255)-(a.a or 255))*amount)
end
-- The visible surface grows by 2.8% within a reserved slot. The outer hitbox and
-- layout never move, avoiding clipping, neighbouring-button overlap and cursor jitter.
function RP.ButtonGeometry(w,h,amount)
    local scale=(1+RP.UI.HoverGrowth*math.Clamp(amount,0,1))/(1+RP.UI.HoverGrowth)
    local dw,dh=w*scale,h*scale
    return (w-dw)/2,(h-dh)/2,dw,dh
end
function RP.UIButton(parent,label,action)
    local button=vgui.Create("DButton",parent)
    button:SetText("")
    button.Paint=function(self,w,h)
        local enabled=self:IsEnabled()
        local target=enabled and self:IsHovered() and 1 or 0
        self.VCityHover=Lerp(math.Clamp(FrameTime()*RP.UI.HoverSpeed,0,1),self.VCityHover or 0,target)
        local amount=self.VCityHover
        local active=self.Active and self.Active()
        local primary=self.Primary and enabled
        local background=primary and RP.UIColor(RP.UI.accent,RP.UI.accentHover,amount)
            or RP.UIColor(active and RP.UI.active or RP.UI.row,RP.UI.hover,amount)
        local x,y,dw,dh=RP.ButtonGeometry(w,h,amount)
        draw.RoundedBox(3,x,y,dw,dh,background)
        local border=RP.UIColor(RP.UI.line,RP.UI.accent,active and 0.8 or amount*0.75)
        if primary then border=RP.UI.accent end
        surface.SetDrawColor(border);surface.DrawOutlinedRect(x,y,dw,dh,1)
        local value=type(label)=="function" and label() or label
        local color=not enabled and RP.UI.muted or (primary and RP.UI.onAccent or ((active or amount>0.15) and RP.UI.accentText or RP.UI.text))
        if self.RoleRow then
            if active then surface.SetDrawColor(RP.UI.accent);surface.DrawRect(x+1,y+5,2,dh-10) end
            draw.SimpleText(value,"VCityRP.Body",x+15,h/2,color,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            draw.SimpleText(active and ">" or "+","VCityRP.Small",x+dw-16,h/2,color,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(value,"VCityRP.Body",w/2,h/2,color,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        end
    end
    button.OnCursorEntered=function() if button:IsEnabled() then RP.PlayUISound("hover") end end
    local original=button.OnMousePressed
    button.OnMousePressed=function(self,code)
        if self:IsEnabled() then RP.PlayUISound("press") end
        if original then return original(self,code) end
    end
    button.DoClick=function() if not button:IsEnabled() then return end;RP.PlayUISound("release");action(button) end
    return button
end
-- Замок роли для клиента: строка из NW2 (сервер пересчитывает каждые 10 с)
function RP.LockFor(id)
    local ply=LocalPlayer()
    if not IsValid(ply) then return nil end
    local raw=ply:GetNW2String(RP.LockNWKey,"")
    for entry in string.gmatch(raw,"[^;]+") do
        local rid,after,done,need=string.match(entry,"^([^|]+)|([^|]+)|(%d+)|(%d+)$")
        if rid==id then return {after=after,done=tonumber(done),need=tonumber(need)} end
    end
    return nil
end
function RP.LockStatus(id)
    local lock=RP.LockFor(id)
    if not lock then return nil end
    return RP.LockMessage(lock.after,lock.done,lock.need)
end
function RP.SubclassCurrent()
    local ply=LocalPlayer()
    return IsValid(ply) and ply:GetNW2String(RP.SubNWKey,"") or ""
end
function RP.RequestSubclass(id)
    net.Start(RP.NetSubclass);net.WriteString(id or "");net.SendToServer()
end
net.Receive(RP.NetSubResult,function()
    local ok,message=net.ReadBool(),net.ReadString()
    RP.Status=message
    notification.AddLegacy(message,ok and NOTIFY_GENERIC or NOTIFY_ERROR,4)
end)
function RP.RequestRole(id,sub)
    if RP.Pending or not RP.Roles[id] then return end
    RP.Pending=true;RP.Status="Ожидание сервера..."
    RP.PendingSubclassOnly=(id==RP.GetRole(LocalPlayer()).ID)
    net.Start(RP.NetSelect);net.WriteString(id);net.WriteString(sub or "");net.SendToServer()
    timer.Create("VCityRP.RoleRequest",5,1,function() RP.Pending=false;RP.Status="Нет ответа сервера." end)
end
function RP.OpenMenu()
    if IsValid(RP.Frame) then RP.Frame:MakePopup() return end
    if not IsValid(LocalPlayer()) then return end
    local current=RP.GetRole(LocalPlayer())
    local faction=RP.FactionsByID[current.Faction] or RP.Factions[1]
    local selected=current.Faction==faction.ID and current.ID or faction.Roles[1].ID
    local w,h=math.min(800,ScrW()-32),math.min(550,ScrH()-32)
    local frame=vgui.Create("DFrame");RP.Frame=frame
    frame:SetSize(w,h);frame:Center();frame:SetTitle("");frame:ShowCloseButton(false);frame:SetDraggable(false);frame:MakePopup()
    frame.OnRemove=function(self) if RP.Frame==self then RP.Frame=nil end end
    frame.OnKeyCodePressed=function(self,key) if key==KEY_F4 or key==KEY_ESCAPE then RP.PlayUISound("release");self:Close() end end
    local selectedSubs={}
    selectedSubs[current.ID]=RP.SubclassCurrent()
    local currentPage="roles"
    frame.Paint=function(self,pw,ph)
        if hg and hg.DrawBlur then hg.DrawBlur(self,3) end
        draw.RoundedBox(3,0,0,pw,ph,RP.UI.bg)
        surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,pw,ph,1)
        surface.SetDrawColor(RP.UI.accent);surface.DrawRect(22,0,40,2)
        draw.SimpleText("V-CITY  /  ROLEPLAY","VCityRP.Brand",22,20,RP.UI.accent)
        draw.SimpleText(currentPage=="roles" and "Выбор роли" or RP.GuidePages[currentPage].title,"VCityRP.Title",22,44,RP.UI.text)
        draw.SimpleText("Сейчас: "..RP.GetRoleLabel(RP.GetRole(LocalPlayer())),"VCityRP.Small",22,78,RP.UI.muted)
        if currentPage=="roles" then
            surface.SetDrawColor(RP.UI.line);surface.DrawRect(22,ph-91,pw-44,1)
            draw.SimpleText(RP.Status or (RP.GetSettings().respawnOnRoleChange and "Смена роли переспавнит персонажа." or "Набор применяется при следующем спавне."),"VCityRP.Small",22,ph-23,RP.UI.muted)
        end
    end
    RP.Status=nil
    local close=RP.UIButton(frame,"X",function() frame:Close() end);close:SetPos(w-52,20);close:SetSize(30,28)
    if LocalPlayer():IsSuperAdmin() then
        local config=RP.UIButton(frame,"Конфиг",function() RP.OpenAdminEditor() end)
        config:SetPos(w-147,20);config:SetSize(86,28)
    end
    local discord=RP.UIButton(frame,"Discord",function() gui.OpenURL("https://discord.gg/DukD5fm4dQ") end)
    discord:SetPos(w-245,20);discord:SetSize(88,28)
    local rows={}
    local subButtons={}
    local listW=math.floor((w-54)*0.58)
    local bodyY=198
    local bodyH=math.max(h-bodyY-108,24)
    local list=vgui.Create("DScrollPanel",frame);list:SetPos(22,bodyY);list:SetSize(listW,bodyH)
    local listCanvas=list:GetCanvas()
    local infoScroll=vgui.Create("DScrollPanel",frame);infoScroll:SetPos(listW+40,bodyY);infoScroll:SetSize(w-listW-62,bodyH)
    local info=vgui.Create("DPanel",infoScroll);info:Dock(TOP);info:SetTall(210)
    info.Paint=function(self,pw,ph)
        local cfg=RP.GetRoleSettings(selected)
        surface.SetDrawColor(RP.UI.line);surface.DrawRect(0,4,1,math.max(ph-8,0))
        draw.SimpleText("НАБОР РОЛИ","VCityRP.Small",16,4,RP.UI.accent)
        draw.SimpleText(cfg.name,"VCityRP.Body",16,29,RP.UI.text)
        local model=cfg.model=="" and "Исходная внешность" or (cfg.model:match("[^/]+$") or cfg.model)
        local duty=""
        draw.DrawText("Модель: "..model.."\n\nОружие: "..tostring(cfg.weaponCount or 0).."\nОбвесы: "..tostring(cfg.attachmentCount or 0).."\nБроня: "..tostring(cfg.armor or 0).."\nПредметы брони: "..tostring(cfg.armorCount or 0).."\nМест: "..((cfg.maxPlayers or 0)==0 and "без лимита" or tostring(cfg.maxPlayers))..duty,"VCityRP.Small",16,63,RP.UI.muted)
    end
    -- Подклассы выезжают «лесенкой» под выбранным званием (только у военных фракций).
    -- Строки званий плавно раздвигаются, подклассы появляются ступенями со сдвигом вправо.
    local ROW_H,ROW_STEP,SUB_H,SUB_STEP=46,53,32,38
    local subs={}
    local ladder=0
    local function ladderOpen() return RP.SubclassAllowed(RP.Roles[selected]) end
    local function resetLadder()
        ladder=0
        for _,b in ipairs(subs) do b.curY=nil end
    end
    local rebuildSubs
    local function selectRole(id)
        if selected~=id then resetLadder() end
        selected=id
        rebuildSubs()
    end
    local function addSub(id,text)
        local b=RP.UIButton(listCanvas,text,function() selectedSubs[selected]=id;RP.Status="Подкласс выбран. Подтверди выбор ниже." end)
        b:SetSize(listW-30,SUB_H);b:SetVisible(false)
        b.SubID=id
        b.Active=function() return (selectedSubs[selected] or "")==id end
        subs[#subs+1]=b
    end
    rebuildSubs=function()
        for _,b in ipairs(subs) do b:Remove() end
        subs={}
        if not RP.SubclassAvailable(RP.Roles[selected],selectedSubs[selected] or "") then selectedSubs[selected]="" end
        addSub("","Без подкласса")
        for _,sub in ipairs(RP.Subclasses) do
            if RP.SubclassAvailable(RP.Roles[selected],sub.ID) then addSub(sub.ID,sub.Name) end
        end
    end
    local function selectedIndex()
        for index,base in ipairs(faction.Roles) do if base.ID==selected then return index end end
    end
    local function layout()
        local y,targets,subTop=0,{},nil
        local open=ladderOpen()
        for index,base in ipairs(faction.Roles) do
            targets[index]=y
            y=y+ROW_STEP
            if open and base.ID==selected then
                subTop=y
                y=y+#subs*SUB_STEP+4
            end
        end
        return targets,subTop,y
    end
    list.Think=function(self)
        local targets,subTop,total=layout()
        local open=subTop~=nil
        local dt=FrameTime()
        ladder=Lerp(math.Clamp(dt*8,0,1),ladder,open and 1 or 0)
        for index,row in ipairs(rows) do
            row.curY=Lerp(math.Clamp(dt*12,0,1),row.curY or targets[index] or 0,targets[index] or 0)
            row:SetPos(0,row.curY)
        end
        local si=selectedIndex()
        local originY=(si and rows[si] and rows[si].curY or 0)+ROW_H*0.6
        for k,b in ipairs(subs) do
            if open and ladder>0.03 then
                local indent=16+math.min(k-1,4)*14
                local ty=subTop+(k-1)*SUB_STEP
                b.curY=Lerp(math.Clamp(dt*12,0,1),b.curY or originY,ty)
                b:SetPos(Lerp(ladder,0,indent),b.curY)
                b:SetSize(listW-14-indent-6,SUB_H)
                b:SetAlpha(255*ladder)
                b:SetVisible(true)
            else
                b:SetVisible(false)
            end
        end
        listCanvas:SetTall(math.max(total-7,24))
    end
    -- Ветки лесенки: вертикаль от звания и горизонтальные «ступеньки» к каждому подклассу
    listCanvas.Paint=function(self,pw,ph)
        if ladder<0.03 or not ladderOpen() then return end
        local si=selectedIndex()
        local row=si and rows[si]
        if not row or not row.curY then return end
        local x0,top=14,row.curY+ROW_H
        local c=RP.UI.accent
        surface.SetDrawColor(c.r,c.g,c.b,150*ladder)
        local lastY=top
        for _,b in ipairs(subs) do
            if b:IsVisible() and b.curY then
                local cy=b.curY+SUB_H/2
                surface.DrawRect(x0,cy,math.max(b:GetX()-x0,0),1)
                lastY=cy
            end
        end
        surface.DrawRect(x0,top,1,math.max(lastY-top,0))
    end
    local function rebuildRows()
        if not RP.Roles[selected] then selected=faction.Roles[1] and faction.Roles[1].ID or RP.DefaultRole end
        rebuildSubs()
        for _,row in ipairs(rows) do row:Remove() end;rows={}
        for index,base in ipairs(faction.Roles) do
            local id=base.ID
            local row=RP.UIButton(listCanvas,function() return RP.GetRoleSettings(id).name..(RP.LockFor(id) and "  ·  закрыто" or "") end,function() selectRole(id);RP.Status=RP.LockStatus(id) end)
            row:SetPos(0,(index-1)*ROW_STEP);row:SetSize(listW-14,ROW_H);row.RoleRow=true
            row.Active=function() return selected==id end
            row:SetEnabled(RP.GetRoleSettings(id).enabled)
            rows[#rows+1]=row
        end
        for _,b in ipairs(subs) do b:MoveToFront() end
        listCanvas:SetTall(#faction.Roles*ROW_STEP-7)
    end
    local roleControls={list,infoScroll}
    local tabW=(w-44-21)/4
    for index,item in ipairs(RP.Factions) do
        local tabFaction=item
        local tab=RP.UIButton(frame,item.Name,function() faction=tabFaction;selected=faction.Roles[1].ID;resetLadder();rebuildRows() end)
        tab:SetPos(22+(index-1)*(tabW+7),151);tab:SetSize(tabW,34)
        roleControls[#roleControls+1]=tab
        tab.Active=function() return faction.ID==tabFaction.ID end
    end
    local civilian=RP.UIButton(frame,"Гражданский",function() RP.RequestRole(RP.DefaultRole) end)
    civilian:SetPos(22,h-74);civilian:SetSize(145,34)
    local confirm=RP.UIButton(frame,function()
        if RP.Pending then return "Ожидание..." end
        if selected==RP.GetRole(LocalPlayer()).ID then
            if (selectedSubs[selected] or "")~=RP.SubclassCurrent() then return "Подтвердить подкласс" end
            return "Текущая роль"
        end
        return RP.GetSettings().respawnOnRoleChange and "Выбрать и переспавниться" or "Выбрать роль"
    end,function() RP.RequestRole(selected,selectedSubs[selected] or "") end)
    confirm:SetPos(w-268,h-74);confirm:SetSize(246,34);confirm.Primary=true
    confirm.Think=function(self) self:SetEnabled(not RP.Pending and RP.GetRoleSettings(selected).enabled and (selected~=RP.GetRole(LocalPlayer()).ID or (selectedSubs[selected] or "")~=RP.SubclassCurrent())) end
    roleControls[#roleControls+1]=civilian
    roleControls[#roleControls+1]=confirm
    local guidePages=RP.BuildGuidePages(frame,22,151,w-44,h-173)
    local function setPage(id)
        currentPage=id
        for _,control in ipairs(roleControls) do control:SetVisible(id=="roles") end
        for key,panel in pairs(guidePages) do panel:SetVisible(key==id) end
    end
    local mainTabs={{"roles","Роли"},{"rules","Правила"},{"lore","Лор"},{"factions","Фракции"}}
    local navW=(w-44-21)/4
    for index,entry in ipairs(mainTabs) do
        local id=entry[1]
        local tab=RP.UIButton(frame,entry[2],function() setPage(id) end)
        tab:SetPos(22+(index-1)*(navW+7),106);tab:SetSize(navW,32)
        tab.Active=function() return currentPage==id end
    end
    setPage("roles")
    frame.RefreshConfig=rebuildRows
    rebuildRows()
    RP.PlayUISound("release")
end
function RP.CloseMenu() if IsValid(RP.Frame) then RP.Frame:Close() end end
function RP.ToggleMenu() if IsValid(RP.Frame) then RP.PlayUISound("release");RP.CloseMenu() else RP.OpenMenu() end end
net.Receive(RP.NetOpen,RP.ToggleMenu)
net.Receive(RP.NetPublic,function(bits)
    local data=RP.ReadJSON(bits)
    if not data or type(data.roles)~="table" or type(data.settings)~="table" then return end
    RP.PublicConfig=data
    RP.InstallRoleCatalog(data.roles)
    hook.Run("VCityRP.CatalogUpdated")
    if IsValid(RP.Frame) then RP.Frame.RefreshConfig() end
end)
net.Receive(RP.NetResult,function()
    timer.Remove("VCityRP.RoleRequest");RP.Pending=false
    local ok,payload=net.ReadBool(),net.ReadString()
    if ok and RP.Roles[payload] then
        notification.AddLegacy(RP.PendingSubclassOnly and "Подкласс выбран. Применится при следующем спавне." or ("Роль: "..RP.GetRoleLabel(RP.RoleByID(payload))),NOTIFY_GENERIC,4);RP.PendingSubclassOnly=nil;RP.CloseMenu()
    else
        RP.Status=payload;notification.AddLegacy(payload,NOTIFY_ERROR,4)
    end
end)
concommand.Add("vcity_f4",RP.ToggleMenu)
hook.Add("HUDPaint","VCityRP.RoleBadge",function()
    if not IsValid(LocalPlayer()) then return end
    local role=RP.GetRole(LocalPlayer())
    draw.SimpleText(RP.MoneyText(LocalPlayer():GetNW2Int(RP.MoneyNWKey,0)),"VCityRP.Body",ScrW()-22,ScrH()-68,RP.UI.accent,TEXT_ALIGN_RIGHT)
    draw.SimpleText("F4","VCityRP.Small",ScrW()-22,ScrH()-46,RP.UI.accent,TEXT_ALIGN_RIGHT)
    draw.SimpleText(RP.GetRoleLabel(role),"VCityRP.Small",ScrW()-22,ScrH()-29,RP.UI.text,TEXT_ALIGN_RIGHT)
end)
