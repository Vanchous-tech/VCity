-- Compatibility contract for retained Homigrad mechanics.
-- There is no round scheduler, mode rotation, victory check or automatic cleanup.
-- A neutral CurrentRound() table is retained because existing code reads its fields.
local RP = VCityRP
zb = zb or {}
hg = hg or {}

local mode = {
    name = "vcity_rp",
    PrintName = RP.Title,
    OverrideSpawn = true,
    randomSpawns = true,
    GuiltDisabled = true, -- round-karma auto-punishments are not RP rules
    LootSpawn = false, -- do not run round-driven random loot generation
    noBoxes = true,
    buymenu = false,
    BuyItems = {},
    saved = {},
    ROUND_TIME = 0,
    start_time = 0
}
function mode:CanSpawn() return true end
function mode:ShouldRoundEnd() return false end
function mode:CanLaunch() return false end
function mode:OverrideBalance() return true end
function mode:GetTeamSpawn() return {}, {} end
function mode:RoundStart() end
function mode:EndRound() end
function mode:RoundThink() end

RP.CompatibilityMode = mode
zb.modes = {vcity_rp = mode}
zb.modesHooks = {}
zb.ModesChances = {}
zb.QueuedModes = {}
zb.CROUND = "vcity_rp"
zb.CROUND_MAIN = "vcity_rp"
zb.LASTCROUND = "vcity_rp"
zb.ROUND_STATE = 1 -- compatibility: organism/HUD code treats this as 'playing'
zb.ROUND_TIME = 0
zb.ROUND_START = CurTime()
zb.ROUND_BEGIN = CurTime()

function CurrentRound() return mode, "vcity_rp" end
function NextRound() return false end
function zb:GetMode(id) if id == "vcity_rp" then return id end end
function zb.GetRoundName() return mode.PrintName end
function zb.GetModes() return {} end
function zb.GetAvailableModes() return {} end
function zb.GetModesInfo() return {} end
function zb.SetRoundList() return false end
function zb:PreRound() return false end
function zb:RoundStart() return false end
function zb:RoundThink() return false end
function zb:EndRoundThink() return false end
function zb:EndRound() return false end
function zb:ShouldRoundEnd() return false end
function zb:KillPlayers() return false end
function zb:Freeze() return false end

if SERVER then
    util.AddNetworkString("RoundInfo")
end

-- Text readability without any panel behind it: a hard offset shadow (old GMod trick).
-- Players who dislike it can switch it off with vcity_rp_textshadow 0.
if CLIENT then
    if not ConVarExists("vcity_rp_textshadow") then
        CreateClientConVar("vcity_rp_textshadow","1",true,false,"Тень под текстом интерфейса V-City для читаемости на ярком фоне",0,1)
    end
end
function RP.TextShadow()
    if not CLIENT then return Color(0,0,0,0) end
    local convar=GetConVar and GetConVar("vcity_rp_textshadow")
    if convar and convar.GetBool and not convar:GetBool() then return Color(0,0,0,0) end
    return Color(0,0,0,235)
end
function RP.ShadowText(text,font,x,y,color,shadow,alignX,alignY)
    local shade=shadow or RP.TextShadow()
    draw.SimpleText(text,font,x+1,y+1,shade,alignX,alignY)
    draw.SimpleText(text,font,x-1,y+1,shade,alignX,alignY)
    draw.SimpleText(text,font,x+1,y-1,shade,alignX,alignY)
    draw.SimpleText(text,font,x-1,y-1,shade,alignX,alignY)
    draw.SimpleText(text,font,x,y,color,alignX,alignY)
end
-- Exposed the way the addon expands the drawing API itself (compare hg.DrawBlur),
-- so any interface file can call draw.ShadowText without extra requires.
if CLIENT then draw.ShadowText = RP.ShadowText end
