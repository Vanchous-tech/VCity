local RP=VCityRP
local function frame(title,w,h)
    local f=vgui.Create("DFrame");f:SetSize(math.min(w,ScrW()-32),math.min(h,ScrH()-32));f:Center();f:SetTitle("");f:ShowCloseButton(false);f:MakePopup()
    f.Paint=function(self,pw,ph)
        draw.RoundedBox(3,0,0,pw,ph,RP.UI.bg)
        surface.SetDrawColor(RP.UI.line);surface.DrawOutlinedRect(0,0,pw,ph,1)
        draw.SimpleText("V-CITY / ROLEPLAY","VCityRP.Small",20,15,RP.UI.accent)
        draw.SimpleText(title,"VCityRP.Title",20,37,RP.UI.text)
    end
    local close=RP.UIButton(f,"X",function() f:Close() end);close:SetPos(f:GetWide()-50,15);close:SetSize(30,28)
    return f
end
local function label(parent,text,x,y,w)
    local l=vgui.Create("DLabel",parent);l:SetPos(x,y);l:SetSize(w or 300,20);l:SetFont("VCityRP.Small");l:SetTextColor(RP.UI.muted);l:SetText(text);return l
end
local function input(parent,value,x,y,w,h)
    local e=vgui.Create("DTextEntry",parent);e:SetPos(x,y);e:SetSize(w,h or 28);e:SetFont("VCityRP.Body");e:SetText(tostring(value or ""))
    if (h or 28)>35 then e:SetMultiline(true) end
    e.Paint=function(self,pw,ph) draw.RoundedBox(2,0,0,pw,ph,RP.UI.row);self:DrawTextEntryText(RP.UI.text,RP.UI.selection,RP.UI.text) end
    return e
end
local function send(name,data)
    net.Start(name);if RP.WriteJSON(data) then net.SendToServer() end
end
function RP.OpenRoleCreator()
    if not LocalPlayer():IsSuperAdmin() then return end
    local f=frame("Создать роль",460,260)
    label(f,"Название (до 32 символов)",20,83)
    local name=input(f,"",20,105,420)
    label(f,"Фракция",20,142)
    local combo=vgui.Create("DComboBox",f);combo:SetPos(20,164);combo:SetSize(420,28)
    local faction="usa"
    for _,item in ipairs(RP.Factions) do combo:AddChoice(item.Name,item.ID) end
    combo:SetValue("США");combo.OnSelect=function(self,index,title,id) faction=id end
    local create=RP.UIButton(f,"Создать и настроить",function()
        local value,err=RP.ValidateProfession(name:GetValue())
        if not value then notification.AddLegacy(err,NOTIFY_ERROR,4) return end
        send(RP.NetAdminCreate,{name=value,faction=faction,revision=RP.PublicConfig and RP.PublicConfig.revision or 0});f:Close()
    end);create:SetPos(240,210);create:SetSize(200,32);create.Primary=true
end
net.Receive(RP.NetInteraction,function(bits)
    local d=RP.ReadJSON(bits);if not d then return end
    if d.kind=="offer" then
        Derma_Query(d.from.." предлагает: "..d.label..". Принять?","Передача предмета","Принять",function() send(RP.NetInteractionAction,{action="accept",offer=d.offer}) end,"Отказаться",function() send(RP.NetInteractionAction,{action="decline",offer=d.offer}) end)
        return
    end
    if RP.OpenInteractionRadial then RP.OpenInteractionRadial(d) end
end)
hook.Add("HUDPaint","VCityRP.UseHint",function()
    local ply=LocalPlayer()
    if not IsValid(ply) or not ply:Alive() or IsValid(RP.InteractionFrame) then return end
    local entity=ply:GetEyeTrace().Entity
    if IsValid(entity) and entity:IsPlayer() and ply:GetPos():DistToSqr(entity:GetPos())<=120*120 then
        draw.SimpleText("E / Взаимодействие","VCityRP.Body",ScrW()/2,ScrH()/2+65,RP.UI.accent,TEXT_ALIGN_CENTER)
    end
end)
