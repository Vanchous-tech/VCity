-- Server-only: move a standing, restrained player into a nearby passenger seat.
-- The client supplies neither the target nor the seat; interaction session and all
-- vehicle/seat checks are repeated on the server at the moment of the request.
local RP=VCityRP
local SEARCH=200
local REACH=160
local MAX_SPEED=80

local function cuffed(ply)
    return IsValid(ply) and ply.GetNetVar and ply:GetNetVar("handcuffed",false)==true
end
local function hostKind(host)
    if not IsValid(host) then return nil end
    if host.IsGlideVehicle==true and istable(host.seats) then return "glide" end
    if host.LVS==true and isfunction(host.GetDriverSeat) and isfunction(host.GetPassengerSeats) then return "lvs" end
end
local function passenger(host,seat)
    if not IsValid(host) or not IsValid(seat) or not seat:IsVehicle() or seat:GetParent()~=host then return false end
    local kind=hostKind(host)
    if kind=="glide" then
        local i=seat.GlideSeatIndex
        return type(i)=="number" and i>1 and host.seats[i]==seat and host.seats[1]~=seat
    elseif kind=="lvs" then
        if host:GetDriverSeat()==seat then return false end
        local list=host:GetPassengerSeats()
        if not istable(list) then return false end
        local found=false
        for _,v in pairs(list) do if v==seat then found=true break end end
        if not found then return false end
        local index=seat.lvsGetPodIndex and seat:lvsGetPodIndex()
        if type(index)~="number" or index<=1 then return false end
        -- LVS can expose a gunner as a passenger pod; do not use a weapon station.
        if istable(host.WEAPONS) and istable(host.WEAPONS[index]) and next(host.WEAPONS[index]) then return false end
        return true
    end
    return false
end

-- Called only by the faction-seat restriction; it is scoped to a single synchronous
-- EnterVehicle call and does not waive vehicle locks or third-party entry hooks.
function RP.PrisonerSeatAuthorized(target,seat)
    local auth=IsValid(target) and target.VCityRPPrisonerSeat
    return istable(auth) and auth.seat==seat and cuffed(target) and passenger(auth.host,seat)
end
local function point(host,pos)
    return host:NearestPoint(pos)
end
local function nearbyHost(actor,target)
    local nearest,best
    for _,host in ipairs(ents.FindInSphere(target:GetPos(),SEARCH)) do
        if hostKind(host) then
            local targetDist=target:GetPos():DistToSqr(point(host,target:GetPos()))
            local actorDist=actor:GetPos():DistToSqr(point(host,actor:GetPos()))
            if targetDist<=REACH*REACH and actorDist<=REACH*REACH and (not best or targetDist<best) then
                nearest,best=host,targetDist
            end
        end
    end
    return nearest
end
local function accessible(actor,target,host)
    local tr=util.TraceLine({start=actor:EyePos(),endpos=point(host,actor:EyePos()),filter={actor,target},mask=MASK_SOLID})
    if not tr.Hit or tr.Entity==host then return true end
    return IsValid(tr.Entity) and tr.Entity:GetParent()==host
end
local function nearestPassenger(host,target)
    local list=hostKind(host)=="glide" and host.seats or host:GetPassengerSeats()
    local best,dist
    for _,seat in pairs(list or {}) do
        if passenger(host,seat) and not IsValid(seat:GetDriver()) then
            local d=target:GetPos():DistToSqr(seat:GetPos())
            if not dist or d<dist then best,dist=seat,d end
        end
    end
    return best
end
function RP.SeatCuffedPlayer(actor,target)
    if not RP.CanInteract(actor,target) then return false,"Игрок больше недоступен. Откройте меню заново." end
    if cuffed(actor) then return false,"Нельзя сажать другого игрока, когда вы сами в наручниках." end
    if actor.organism and (actor.organism.otrub or actor.organism.incapacitated) then return false,"Вы не можете действовать без сознания." end
    if not cuffed(target) then return false,"Игрок больше не в наручниках." end
    local host=nearbyHost(actor,target)
    if not IsValid(host) then return false,"Рядом нет подходящей машины Glide или LVS." end
    if host:GetVelocity():LengthSqr()>MAX_SPEED*MAX_SPEED then return false,"Сначала остановите машину." end
    if not accessible(actor,target,host) then return false,"Машина находится за препятствием." end
    local seat=nearestPassenger(host,target)
    if not IsValid(seat) then return false,"В ближайшей машине нет свободного пассажирского места." end
    if not passenger(host,seat) or IsValid(seat:GetDriver()) then return false,"Пассажирское место уже занято." end
    -- LVS normally checks locks/team in its Use handler, which EnterVehicle skips.
    if hostKind(host)=="lvs" then
        if host.GetlvsLockedStatus and host:GetlvsLockedStatus() then return false,"Машина заперта." end
        if host.IsUseAllowed and not host:IsUseAllowed(actor) then return false,"Нет доступа к машине." end
    end
    -- Glide's native lock rules apply to the passenger. Never override a locked vehicle.
    if host.IsGlideVehicle and host.GetIsLocked and host:GetIsLocked() then
        if not Glide or not Glide.CanEnterLockedVehicle or not Glide.CanEnterLockedVehicle(target,host) then
            return false,"Машина заперта для пассажира."
        end
    end
    target.VCityRPPrisonerSeat={host=host,seat=seat}
    local ok,err=pcall(target.EnterVehicle,target,seat)
    target.VCityRPPrisonerSeat=nil
    if not ok then
        ErrorNoHalt("[V-City RP] Prisoner seat failed: "..tostring(err).."\n")
        return false,"Не удалось посадить игрока. Проверьте консоль сервера."
    end
    if not target:InVehicle() or target:GetVehicle()~=seat then return false,"Не удалось сесть: место занято или вход запрещён." end
    if hostKind(host)=="lvs" then
        if host.AlignView then pcall(host.AlignView,host,target,true) end
        hook.Run("LVS.UpdateRelationship",host)
    end
    return true,"Игрок посажен на пассажирское место."
end
