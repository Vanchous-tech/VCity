-- V-City RP 1.0.0-beta.1 — SERVER ONLY. Деньги: выдача и награды за звания и подклассы.
-- RP.GrantMoney(ply, сумма, причина) / RP.GrantMoneyBatch({{ply=,amount=},…}, причина) — одна запись кошелька.
-- Награда выдаётся ОДИН раз на игрока за каждое звание и каждый подкласс (даже если сменил и вернулся).
-- Суммы: data/vcity_rp/rewards.json {"enabled":true,"roles":{"rf_corporal":250,…},"subclasses":{"sniper":300,…}}
-- Команды (суперадмин): vcity_rp_rewards_reload, vcity_rp_rewards_reset <steam64>
local RP = VCityRP

RP.RewardFile = "vcity_rp/rewards.json"
RP.RewardClaimFile = "vcity_rp/rewards_claimed.json"

RP.DefaultRewards = {
    enabled = true,
    roles = {
        delta_corporal = 250, delta_sergeant = 600, delta_leader = 1500,
        rf_corporal = 250, rf_sergeant = 600, rf_junior_lieutenant = 1500,
        drina_corporal = 250, drina_sergeant = 600, drina_junior_lieutenant = 1500,
    },
    subclasses = { sniper = 300, assault = 300, at = 300, machinegunner = 300, signaller = 300, crew = 500 },
}
RP.Rewards = table.Copy(RP.DefaultRewards)
RP.RewardClaims = {}

local function LoadRewards()
    RP.Rewards = table.Copy(RP.DefaultRewards)
    local raw = file.Read(RP.RewardFile, "DATA")
    if not raw or raw == "" then return end
    local parsed = util.JSONToTable(raw)
    if not istable(parsed) then print("[V-City RP] Ошибка чтения data/" .. RP.RewardFile .. " — награды по умолчанию.") return end
    if isbool(parsed.enabled) then RP.Rewards.enabled = parsed.enabled end
    for _, group in ipairs({ "roles", "subclasses" }) do
        if istable(parsed[group]) then
            RP.Rewards[group] = {}
            for id, amount in pairs(parsed[group]) do
                amount = tonumber(amount)
                if isstring(id) and amount and amount >= 0 and amount <= 1000000 then RP.Rewards[group][id] = math.floor(amount) end
            end
        end
    end
end

local function LoadClaims()
    local raw = file.Read(RP.RewardClaimFile, "DATA")
    -- ignoreConversions=true: SteamID64 keys must stay strings (otherwise they become lossy numbers)
    local parsed = raw and raw ~= "" and util.JSONToTable(raw, false, true) or nil
    RP.RewardClaims = istable(parsed) and parsed or {}
end

local function SaveClaims()
    file.CreateDir("vcity_rp")
    file.Write(RP.RewardClaimFile, util.TableToJSON(RP.RewardClaims, true))
end

-- ================= выдача денег =================
local function accountID(ply)
    if not IsValid(ply) or not ply:IsPlayer() or ply:IsBot() then return end
    local id = ply:SteamID64()
    if type(id) ~= "string" or not id:match("^%d+$") or #id > 20 or #id < 15 then return end
    return id
end

function RP.GrantMoneyBatch(list, reason)
    if not RP.MoneyReady then return false, "Экономика недоступна." end
    local copy = table.Copy(RP.Wallets)
    local applied = {}
    for _, entry in ipairs(list) do
        local id = accountID(entry.ply)
        local amount = math.floor(tonumber(entry.amount) or 0)
        local balance = id and copy.accounts[id]
        if balance and amount > 0 then
            local new = math.min(balance + amount, RP.MaxMoney)
            copy.accounts[id] = new
            applied[#applied + 1] = { ply = entry.ply, amount = new - balance }
        end
    end
    if #applied == 0 then return false, "Некому выдавать." end
    local ok, err = RP.PersistWallets(copy)
    if not ok then return false, tostring(err) end
    RP.Wallets = copy
    for _, a in ipairs(applied) do
        RP.SyncMoney(a.ply)
        if RP.Log then RP.Log("money", "выдано " .. a.amount .. " (" .. tostring(reason or "?") .. ") -> " .. RP.Who(a.ply)) end
    end
    return true, applied
end

function RP.GrantMoney(ply, amount, reason)
    return RP.GrantMoneyBatch({ { ply = ply, amount = amount } }, reason)
end

-- ================= награды =================
local function Claimed(steam, group, id)
    local c = RP.RewardClaims[steam]
    return istable(c) and istable(c[group]) and c[group][id] == true
end

local function Claim(ply, group, id, amount, title)
    if not RP.Rewards.enabled or amount <= 0 then return end
    local steam = accountID(ply)
    if not steam or Claimed(steam, group, id) then return end
    local ok = RP.GrantMoney(ply, amount, "награда: " .. group .. " " .. id)
    if not ok then return end -- не вышло записать кошелёк — попробуем в следующий раз
    RP.RewardClaims[steam] = RP.RewardClaims[steam] or {}
    RP.RewardClaims[steam][group] = RP.RewardClaims[steam][group] or {}
    RP.RewardClaims[steam][group][id] = true
    SaveClaims()
    ply:ChatPrint("Награда за " .. title .. ": +" .. RP.MoneyText(amount))
end

hook.Add("VCityRP.RoleChanged", "VCityRP.RewardRole", function(ply, role)
    if not IsValid(ply) or not role then return end
    local amount = RP.Rewards.roles[role.ID]
    if amount then Claim(ply, "roles", role.ID, amount, "звание «" .. tostring(role.Name) .. "»") end
end)

do
    local original = RP.SetSubclass
    if isfunction(original) and not RP.__rewardSubWrapped then
        RP.__rewardSubWrapped = true
        RP.SetSubclass = function(ply, id)
            local ok, msg = original(ply, id)
            if ok and id ~= "" then
                local amount = RP.Rewards.subclasses[id]
                local sub = RP.SubclassByID(id)
                if amount and sub then Claim(ply, "subclasses", id, amount, "подкласс «" .. sub.Name .. "»") end
            end
            return ok, msg
        end
    end
end

LoadRewards()
LoadClaims()

concommand.Add("vcity_rp_rewards_reload", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    LoadRewards()
    print("[V-City RP] Награды перечитаны.")
end)

concommand.Add("vcity_rp_rewards_reset", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local steam = args[1]
    if not steam or not RP.RewardClaims[steam] then print("usage: vcity_rp_rewards_reset <steam64> (записи нет)") return end
    RP.RewardClaims[steam] = nil
    SaveClaims()
    print("[V-City RP] Награды игрока " .. steam .. " сброшены (получит снова).")
end)
