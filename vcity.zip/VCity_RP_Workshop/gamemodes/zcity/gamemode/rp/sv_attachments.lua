-- SERVER ONLY. Applies configured attachments through the addon's own hg.AddAttachmentForce.
local RP=VCityRP
function RP.ApplyWeaponAttachments(ply,weapon,ids)
    local applied,skipped=0,{}
    if not IsValid(weapon) or type(weapon.attachments)~="table" or type(weapon.availableAttachments)~="table" then
        for _,id in ipairs(ids or {}) do skipped[#skipped+1]=id end
        return applied,skipped
    end
    for _,id in ipairs(ids or {}) do
        local placement=RP.AttachmentPlacementOf(id)
        -- Guard the original helper: it indexes both tables without checking placement support.
        if not placement or weapon.attachments[placement]==nil or weapon.availableAttachments[placement]==nil then
            skipped[#skipped+1]=id
        else
            local ok=pcall(hg.AddAttachmentForce,ply,weapon,id)
            local entry=weapon.attachments[placement]
            if ok and type(entry)=="table" and entry[1]==id then applied=applied+1 else skipped[#skipped+1]=id end
        end
    end
    if applied>0 then pcall(function() weapon:SyncAtts() end) end
    return applied,skipped
end
-- Restore the validated IDs from a ZCLP snapshot, similarly to ZCLP SetInfo.
-- The regular AddAttachmentForce path can reject a previously installed item
-- because its runtime mount checks differ from restoring a saved snapshot.
function RP.RestorePresetAttachments(weapon,ids)
    local failed={}
    if not IsValid(weapon) or type(weapon.attachments)~="table" then
        for _,id in ipairs(ids or {}) do failed[#failed+1]=id end
        return 0,failed
    end
    local applied=0
    for _,id in ipairs(ids or {}) do
        local slot=RP.AttachmentPlacementOf(id)
        if not slot or type(weapon.attachments[slot])~="table" then
            failed[#failed+1]=id
        else
            local template
            local choices=type(weapon.availableAttachments)=="table" and weapon.availableAttachments[slot] or nil
            if type(choices)=="table" then
                for _,choice in pairs(choices) do
                    if type(choice)=="table" and choice[1]==id then template=choice;break end
                end
            end
            -- Matches Z-City hg.SetAttachment's fallback; no arbitrary client SetInfo.
            weapon.attachments[slot]=template and table.Copy(template) or {id,{}}
            applied=applied+1
        end
    end
    if applied>0 then
        if type(weapon.SyncAtts)~="function" then
            ErrorNoHalt("[V-City RP] Нет SyncAtts у оружия; обвесы могут не отобразиться.\n")
        else
            local ok,err=pcall(weapon.SyncAtts,weapon)
            if not ok then ErrorNoHalt("[V-City RP] Ошибка синхронизации обвесов: "..tostring(err).."\n") end
        end
    end
    return applied,failed
end
function RP.ApplyAttachmentsToLoadout(ply,ids)
    if not IsValid(ply) or type(ids)~="table" or #ids==0 then return 0 end
    local total=0
    for _,weapon in ipairs(ply:GetWeapons()) do
        local applied=RP.ApplyWeaponAttachments(ply,weapon,ids)
        total=total+applied
    end
    return total
end
-- The admin editor receives a bounded preview of what actually exists on the server.
function RP.AttachmentOptionsJSON()
    local catalog=RP.AttachmentCatalog();local total=0
    for _,entry in pairs(catalog) do total=total+entry.count end
    return catalog,total
end
