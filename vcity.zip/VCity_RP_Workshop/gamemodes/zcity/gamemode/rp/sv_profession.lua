-- SERVER ONLY. /rp is a cosmetic profession title for the civilian role.
local RP=VCityRP
function RP.TrySetProfession(ply,value)
    if not IsValid(ply) or not ply:IsPlayer() then return false,"Некорректный игрок." end
    local role=RP.GetRole(ply)
    if role.Faction~=RP.CivilianFaction then return false,"Команда /rp доступна только гражданским." end
    local title,reason=RP.ValidateProfession(value)
    if not title then return false,reason end
    local previous=RP.GetProfession(ply)
    if previous==title then return true,title end
    if (ply.VCityRPNextProfessionChange or 0)>CurTime() then return false,"Подожди 2 секунды перед сменой профессии." end
    ply.VCityRPNextProfessionChange=CurTime()+RP.ProfessionChangeCooldown
    ply:SetNW2String(RP.ProfessionNWKey,title)
    -- Refresh only the scoreboard label for the CURRENT role. Calling RP.ApplyRole(ply,DefaultRole)
    -- here silently switched every civilian role to plain "civilian" and dropped trade/craft access.
    local current=RP.GetRole(ply)
    if zb and zb.GiveRole then zb.GiveRole(ply,RP.GetRoleLabel(current),current.Color) end
    hook.Run("VCityRP.ProfessionChanged",ply,title,previous)
    return true,title
end
function RP.PrintHelp(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    ply:ChatPrint("Использование: /rp <профессия> для гражданских (до 32 символов) · /rp help — эта справка.")
    ply:ChatPrint("Отыгрыш: /me <действие> — от третьего лица, /do <обстановка>, /try <действие> — попытка с броском.")
    ply:ChatPrint("Реплики /me, /do и /try видят только игроки рядом (512 юнитов), лимит "..tostring(RP.EmoteMaxLength or 160).." символов.")
    ply:ChatPrint("Рестарт: сервер круглосуточный, плановый рестарт каждый день в 05:00 — ночью напоминания, за час до него отсчёт.")
    ply:ChatPrint("F4 — роль и фракция. Гражданские: Гражданский, Медик, Автомеханик.")
    ply:ChatPrint("E — взаимодействие: информация, деньги, предметы, патроны.")
    ply:ChatPrint("Обвесы роли выдаются вместе с оружием; несовместимые с конкретным SWEP пропускаются.")
end
function RP.HandleProfessionChat(ply,text)
    if not RP.Enabled or type(text)~="string" then return false end
    local command,tail=text:match("^%s*(/[^%s]+)(.*)$")
    if not command or command:lower()~="/rp" then return false end
    if not IsValid(ply) or not ply:IsPlayer() then return true end
    -- Bound feedback as well as writes, including usage/error spam.
    if (ply.VCityRPNextProfessionPacket or 0)>CurTime() then return true end
    ply.VCityRPNextProfessionPacket=CurTime()+0.25
    local argument=tail:match("^%s*(.-)%s*$")
    if argument:lower()=="help" or argument=="?" then RP.PrintHelp(ply) return true end
    local ok,result=RP.TrySetProfession(ply,argument)
    ply:ChatPrint(ok and ("Профессия: "..result) or result)
    return true -- consumed; not broadcast as a roleplay chat message
end
-- Standard say/say_team fallback. The ZChat ingress also calls the same handler,
-- so PlayerSay hook ordering cannot swallow the command before our code sees it.
hook.Add("PlayerSay","VCityRP.CivilianProfession",function(ply,text)
    if RP.HandleProfessionChat(ply,text) then return "" end
end)
concommand.Add("vcity_rp_help",function(ply) if IsValid(ply) then RP.PrintHelp(ply) end end)
